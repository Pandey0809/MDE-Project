/**
 */
package smartFarming;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Temperature Sensosr</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.TemperatureSensosr#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}</li>
 *   <li>{@link smartFarming.TemperatureSensosr#getCrateTemperature <em>Crate Temperature</em>}</li>
 *   <li>{@link smartFarming.TemperatureSensosr#getPlantTemperature <em>Plant Temperature</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosr()
 * @model
 * @generated
 */
public interface TemperatureSensosr extends EObject {
	/**
	 * Returns the value of the '<em><b>Temperaturein Degree Celcius</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #setTemperatureinDegreeCelcius(boolean)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosr_TemperatureinDegreeCelcius()
	 * @model
	 * @generated
	 */
	boolean isTemperatureinDegreeCelcius();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosr#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 */
	void setTemperatureinDegreeCelcius(boolean value);

	/**
	 * Returns the value of the '<em><b>Crate Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crate Temperature</em>' attribute.
	 * @see #setCrateTemperature(float)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosr_CrateTemperature()
	 * @model
	 * @generated
	 */
	float getCrateTemperature();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosr#getCrateTemperature <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crate Temperature</em>' attribute.
	 * @see #getCrateTemperature()
	 * @generated
	 */
	void setCrateTemperature(float value);

	/**
	 * Returns the value of the '<em><b>Plant Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plant Temperature</em>' attribute.
	 * @see #setPlantTemperature(float)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosr_PlantTemperature()
	 * @model
	 * @generated
	 */
	float getPlantTemperature();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosr#getPlantTemperature <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Plant Temperature</em>' attribute.
	 * @see #getPlantTemperature()
	 * @generated
	 */
	void setPlantTemperature(float value);

} // TemperatureSensosr
