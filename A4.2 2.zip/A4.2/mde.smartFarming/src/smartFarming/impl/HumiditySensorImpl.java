/**
 */
package smartFarming.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.oclany.OclComparableGreaterThanEqualOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.RealValue;

import smartFarming.HumiditySensor;
import smartFarming.SmartFarmingPackage;
import smartFarming.SmartFarmingTables;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Humidity Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.HumiditySensorImpl#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}</li>
 *   <li>{@link smartFarming.impl.HumiditySensorImpl#isTurnOn <em>Turn On</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HumiditySensorImpl extends MinimalEObjectImpl.Container implements HumiditySensor {
	/**
	 * The default value of the '{@link #getHumidityValueInPercentage() <em>Humidity Value In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHumidityValueInPercentage()
	 * @generated
	 * @ordered
	 */
	protected static final float HUMIDITY_VALUE_IN_PERCENTAGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getHumidityValueInPercentage() <em>Humidity Value In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHumidityValueInPercentage()
	 * @generated
	 * @ordered
	 */
	protected float humidityValueInPercentage = HUMIDITY_VALUE_IN_PERCENTAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TURN_ON_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected boolean turnOn = TURN_ON_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HumiditySensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.HUMIDITY_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getHumidityValueInPercentage() {
		return humidityValueInPercentage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHumidityValueInPercentage(float newHumidityValueInPercentage) {
		float oldHumidityValueInPercentage = humidityValueInPercentage;
		humidityValueInPercentage = newHumidityValueInPercentage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE, oldHumidityValueInPercentage, humidityValueInPercentage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTurnOn() {
		return turnOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTurnOn(boolean newTurnOn) {
		boolean oldTurnOn = turnOn;
		turnOn = newTurnOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON, oldTurnOn, turnOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isHumiditytooless(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "HumiditySensor::isHumiditytooless";
		try {
			/**
			 *
			 * inv isHumiditytooless:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.HumidityValueInPercentage >= 50
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.HUMIDITY_SENSOR___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ float HumidityValueInPercentage = this.getHumidityValueInPercentage();
				final /*@NonInvalid*/ RealValue BOXED_HumidityValueInPercentage = ValueUtil.realValueOf(HumidityValueInPercentage);
				final /*@NonInvalid*/ boolean result = OclComparableGreaterThanEqualOperation.INSTANCE.evaluate(executor, BOXED_HumidityValueInPercentage, SmartFarmingTables.INT_50).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isHumiditytoomuch(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "HumiditySensor::isHumiditytoomuch";
		try {
			/**
			 *
			 * inv isHumiditytoomuch:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.HumidityValueInPercentage <= 90
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.HUMIDITY_SENSOR___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ float HumidityValueInPercentage = this.getHumidityValueInPercentage();
				final /*@NonInvalid*/ RealValue BOXED_HumidityValueInPercentage = ValueUtil.realValueOf(HumidityValueInPercentage);
				final /*@NonInvalid*/ boolean result = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, BOXED_HumidityValueInPercentage, SmartFarmingTables.INT_90).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE:
				return getHumidityValueInPercentage();
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				return isTurnOn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE:
				setHumidityValueInPercentage((Float)newValue);
				return;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				setTurnOn((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE:
				setHumidityValueInPercentage(HUMIDITY_VALUE_IN_PERCENTAGE_EDEFAULT);
				return;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				setTurnOn(TURN_ON_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE:
				return humidityValueInPercentage != HUMIDITY_VALUE_IN_PERCENTAGE_EDEFAULT;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				return turnOn != TURN_ON_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP:
				return isHumiditytooless((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case SmartFarmingPackage.HUMIDITY_SENSOR___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP:
				return isHumiditytoomuch((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (HumidityValueInPercentage: ");
		result.append(humidityValueInPercentage);
		result.append(", TurnOn: ");
		result.append(turnOn);
		result.append(')');
		return result.toString();
	}

} //HumiditySensorImpl
