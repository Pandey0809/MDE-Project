/**
 */
package smartFarming.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EGenericType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import smartFarming.Camera;
import smartFarming.Crate;
import smartFarming.Crateid;
import smartFarming.Crop;
import smartFarming.CropType;
import smartFarming.Drone;
import smartFarming.Farm;
import smartFarming.FocusArea;
import smartFarming.HumiditySensor;
import smartFarming.Light;
import smartFarming.Name;
import smartFarming.SmartFarmingFactory;
import smartFarming.SmartFarmingPackage;
import smartFarming.SoilSensor;
import smartFarming.TemperatureSensosor;
import smartFarming.typelight;

import smartFarming.util.SmartFarmingValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SmartFarmingPackageImpl extends EPackageImpl implements SmartFarmingPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass farmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass droneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aiEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass temperatureSensosorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass soilSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass humiditySensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lightEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cropEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crateidEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typelightEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum focusAreaEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum cropTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see smartFarming.SmartFarmingPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SmartFarmingPackageImpl() {
		super(eNS_URI, SmartFarmingFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link SmartFarmingPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SmartFarmingPackage init() {
		if (isInited) return (SmartFarmingPackage)EPackage.Registry.INSTANCE.getEPackage(SmartFarmingPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredSmartFarmingPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		SmartFarmingPackageImpl theSmartFarmingPackage = registeredSmartFarmingPackage instanceof SmartFarmingPackageImpl ? (SmartFarmingPackageImpl)registeredSmartFarmingPackage : new SmartFarmingPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theSmartFarmingPackage.createPackageContents();

		// Initialize created meta-data
		theSmartFarmingPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theSmartFarmingPackage,
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return SmartFarmingValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theSmartFarmingPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(SmartFarmingPackage.eNS_URI, theSmartFarmingPackage);
		return theSmartFarmingPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFarm() {
		return farmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Crate() {
		return (EReference)farmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Drone() {
		return (EReference)farmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Camera() {
		return (EReference)farmEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Ai() {
		return (EReference)farmEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFarm_MaxCrates() {
		return (EAttribute)farmEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFarm__IsSpaceaAvailable() {
		return farmEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFarm__SufficientSpace__DiagnosticChain_Map() {
		return farmEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrate() {
		return crateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Light() {
		return (EReference)crateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Humiditysensor() {
		return (EReference)crateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Temperaturesensor() {
		return (EReference)crateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Soilsenor() {
		return (EReference)crateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_CropType() {
		return (EReference)crateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingAI() {
		return (EReference)crateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingDrones() {
		return (EReference)crateEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingCameras() {
		return (EReference)crateEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDrone() {
		return droneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrone_TurnOn() {
		return (EAttribute)droneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrone_DroneMonitoring() {
		return (EAttribute)droneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCamera() {
		return cameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_CameraFocus() {
		return (EAttribute)cameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAI() {
		return aiEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAI_AIMonitoring() {
		return (EAttribute)aiEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTemperatureSensosor() {
		return temperatureSensosorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTemperatureSensosor_TemperatureinDegreeCelcius() {
		return (EAttribute)temperatureSensosorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTemperatureSensosor_CrateTemperature() {
		return (EAttribute)temperatureSensosorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTemperatureSensosor_PlantTemperature() {
		return (EAttribute)temperatureSensosorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTemperatureSensosor__ArePlantsAlive() {
		return temperatureSensosorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTemperatureSensosor__ArePlantsAlive__DiagnosticChain_Map() {
		return temperatureSensosorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSoilSensor() {
		return soilSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSoilSensor_Ph() {
		return (EAttribute)soilSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSoilSensor_SoilMoistureInPercentage() {
		return (EAttribute)soilSensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSoilSensor__IsSoiltooAcidic__DiagnosticChain_Map() {
		return soilSensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getSoilSensor__IsSoiltooBasic__DiagnosticChain_Map() {
		return soilSensorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHumiditySensor() {
		return humiditySensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHumiditySensor_HumidityValueInPercentage() {
		return (EAttribute)humiditySensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHumiditySensor_TurnOn() {
		return (EAttribute)humiditySensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHumiditySensor__IsHumiditytooless__DiagnosticChain_Map() {
		return humiditySensorEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getHumiditySensor__IsHumiditytoomuch__DiagnosticChain_Map() {
		return humiditySensorEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLight() {
		return lightEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLight_TypeLight() {
		return (EAttribute)lightEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLight_TurnOn() {
		return (EAttribute)lightEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getName_() {
		return nameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getName_Name() {
		return (EAttribute)nameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrop() {
		return cropEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrop_Crop() {
		return (EAttribute)cropEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrateid() {
		return crateidEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateid_Id() {
		return (EAttribute)crateidEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum gettypelight() {
		return typelightEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getFocusArea() {
		return focusAreaEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCropType() {
		return cropTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarmingFactory getSmartFarmingFactory() {
		return (SmartFarmingFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		farmEClass = createEClass(FARM);
		createEReference(farmEClass, FARM__CRATE);
		createEReference(farmEClass, FARM__DRONE);
		createEReference(farmEClass, FARM__CAMERA);
		createEReference(farmEClass, FARM__AI);
		createEAttribute(farmEClass, FARM__MAX_CRATES);
		createEOperation(farmEClass, FARM___IS_SPACEA_AVAILABLE);
		createEOperation(farmEClass, FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP);

		crateEClass = createEClass(CRATE);
		createEReference(crateEClass, CRATE__LIGHT);
		createEReference(crateEClass, CRATE__HUMIDITYSENSOR);
		createEReference(crateEClass, CRATE__TEMPERATURESENSOR);
		createEReference(crateEClass, CRATE__SOILSENOR);
		createEReference(crateEClass, CRATE__CROP_TYPE);
		createEReference(crateEClass, CRATE__WORKING_AI);
		createEReference(crateEClass, CRATE__WORKING_DRONES);
		createEReference(crateEClass, CRATE__WORKING_CAMERAS);

		droneEClass = createEClass(DRONE);
		createEAttribute(droneEClass, DRONE__TURN_ON);
		createEAttribute(droneEClass, DRONE__DRONE_MONITORING);

		cameraEClass = createEClass(CAMERA);
		createEAttribute(cameraEClass, CAMERA__CAMERA_FOCUS);

		aiEClass = createEClass(AI);
		createEAttribute(aiEClass, AI__AI_MONITORING);

		temperatureSensosorEClass = createEClass(TEMPERATURE_SENSOSOR);
		createEAttribute(temperatureSensosorEClass, TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS);
		createEAttribute(temperatureSensosorEClass, TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE);
		createEAttribute(temperatureSensosorEClass, TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE);
		createEOperation(temperatureSensosorEClass, TEMPERATURE_SENSOSOR___ARE_PLANTS_ALIVE);
		createEOperation(temperatureSensosorEClass, TEMPERATURE_SENSOSOR___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP);

		soilSensorEClass = createEClass(SOIL_SENSOR);
		createEAttribute(soilSensorEClass, SOIL_SENSOR__PH);
		createEAttribute(soilSensorEClass, SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE);
		createEOperation(soilSensorEClass, SOIL_SENSOR___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP);
		createEOperation(soilSensorEClass, SOIL_SENSOR___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP);

		humiditySensorEClass = createEClass(HUMIDITY_SENSOR);
		createEAttribute(humiditySensorEClass, HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE);
		createEAttribute(humiditySensorEClass, HUMIDITY_SENSOR__TURN_ON);
		createEOperation(humiditySensorEClass, HUMIDITY_SENSOR___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP);
		createEOperation(humiditySensorEClass, HUMIDITY_SENSOR___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP);

		lightEClass = createEClass(LIGHT);
		createEAttribute(lightEClass, LIGHT__TYPE_LIGHT);
		createEAttribute(lightEClass, LIGHT__TURN_ON);

		nameEClass = createEClass(NAME);
		createEAttribute(nameEClass, NAME__NAME);

		cropEClass = createEClass(CROP);
		createEAttribute(cropEClass, CROP__CROP);

		crateidEClass = createEClass(CRATEID);
		createEAttribute(crateidEClass, CRATEID__ID);

		// Create enums
		typelightEEnum = createEEnum(TYPELIGHT);
		focusAreaEEnum = createEEnum(FOCUS_AREA);
		cropTypeEEnum = createEEnum(CROP_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		farmEClass.getESuperTypes().add(this.getName_());
		crateEClass.getESuperTypes().add(this.getCrateid());
		droneEClass.getESuperTypes().add(this.getName_());
		cameraEClass.getESuperTypes().add(this.getName_());
		aiEClass.getESuperTypes().add(this.getName_());
		lightEClass.getESuperTypes().add(this.getName_());

		// Initialize classes, features, and operations; add parameters
		initEClass(farmEClass, Farm.class, "Farm", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFarm_Crate(), this.getCrate(), null, "crate", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Drone(), this.getDrone(), null, "drone", null, 1, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Camera(), this.getCamera(), null, "camera", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Ai(), this.getAI(), null, "ai", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFarm_MaxCrates(), ecorePackage.getEInt(), "MaxCrates", null, 1, 1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getFarm__IsSpaceaAvailable(), ecorePackage.getEBooleanObject(), "isSpaceaAvailable", 0, 1, IS_UNIQUE, IS_ORDERED);

		EOperation op = initEOperation(getFarm__SufficientSpace__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "SufficientSpace", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		EGenericType g1 = createEGenericType(ecorePackage.getEMap());
		EGenericType g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(crateEClass, Crate.class, "Crate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCrate_Light(), this.getLight(), null, "light", null, 1, -1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_Humiditysensor(), this.getHumiditySensor(), null, "humiditysensor", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_Temperaturesensor(), this.getTemperatureSensosor(), null, "temperaturesensor", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_Soilsenor(), this.getSoilSensor(), null, "soilsenor", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_CropType(), this.getCrop(), null, "cropType", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_WorkingAI(), this.getAI(), null, "workingAI", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);
		initEReference(getCrate_WorkingDrones(), this.getDrone(), null, "workingDrones", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);
		initEReference(getCrate_WorkingCameras(), this.getCamera(), null, "workingCameras", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);

		initEClass(droneEClass, Drone.class, "Drone", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDrone_TurnOn(), ecorePackage.getEBoolean(), "TurnOn", null, 1, 1, Drone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrone_DroneMonitoring(), this.getFocusArea(), "DroneMonitoring", null, 0, 1, Drone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cameraEClass, Camera.class, "Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCamera_CameraFocus(), this.getFocusArea(), "CameraFocus", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(aiEClass, smartFarming.AI.class, "AI", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAI_AIMonitoring(), this.getFocusArea(), "AIMonitoring", null, 0, 1, smartFarming.AI.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(temperatureSensosorEClass, TemperatureSensosor.class, "TemperatureSensosor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTemperatureSensosor_TemperatureinDegreeCelcius(), ecorePackage.getEBoolean(), "TemperatureinDegreeCelcius", null, 1, 1, TemperatureSensosor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTemperatureSensosor_CrateTemperature(), ecorePackage.getEFloat(), "CrateTemperature", null, 1, 1, TemperatureSensosor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTemperatureSensosor_PlantTemperature(), ecorePackage.getEFloat(), "PlantTemperature", null, 1, 1, TemperatureSensosor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getTemperatureSensosor__ArePlantsAlive(), ecorePackage.getEBooleanObject(), "arePlantsAlive", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTemperatureSensosor__ArePlantsAlive__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "arePlantsAlive", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(soilSensorEClass, SoilSensor.class, "SoilSensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSoilSensor_Ph(), ecorePackage.getEInt(), "ph", null, 1, 1, SoilSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSoilSensor_SoilMoistureInPercentage(), ecorePackage.getEInt(), "SoilMoistureInPercentage", null, 1, 1, SoilSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getSoilSensor__IsSoiltooAcidic__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isSoiltooAcidic", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getSoilSensor__IsSoiltooBasic__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isSoiltooBasic", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(humiditySensorEClass, HumiditySensor.class, "HumiditySensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHumiditySensor_HumidityValueInPercentage(), ecorePackage.getEFloat(), "HumidityValueInPercentage", null, 1, 1, HumiditySensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHumiditySensor_TurnOn(), ecorePackage.getEBoolean(), "TurnOn", null, 1, 1, HumiditySensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getHumiditySensor__IsHumiditytooless__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isHumiditytooless", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getHumiditySensor__IsHumiditytoomuch__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isHumiditytoomuch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(lightEClass, Light.class, "Light", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLight_TypeLight(), this.gettypelight(), "TypeLight", null, 0, 1, Light.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLight_TurnOn(), ecorePackage.getEBoolean(), "TurnOn", null, 1, 1, Light.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(nameEClass, Name.class, "Name", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getName_Name(), ecorePackage.getEString(), "name", null, 1, 1, Name.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cropEClass, Crop.class, "Crop", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCrop_Crop(), this.getCropType(), "Crop", null, 0, 1, Crop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(crateidEClass, Crateid.class, "Crateid", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCrateid_Id(), ecorePackage.getEString(), "id", null, 0, 1, Crateid.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(typelightEEnum, typelight.class, "typelight");
		addEEnumLiteral(typelightEEnum, typelight.UVLIGHT);
		addEEnumLiteral(typelightEEnum, typelight.BLUE_LIGHT);
		addEEnumLiteral(typelightEEnum, typelight.RED_LIGHT);
		addEEnumLiteral(typelightEEnum, typelight.GREEN_LIGHT);

		initEEnum(focusAreaEEnum, FocusArea.class, "FocusArea");
		addEEnumLiteral(focusAreaEEnum, FocusArea.CRATES);
		addEEnumLiteral(focusAreaEEnum, FocusArea.PLANTS);
		addEEnumLiteral(focusAreaEEnum, FocusArea.CAMERAS);
		addEEnumLiteral(focusAreaEEnum, FocusArea.DRONES);
		addEEnumLiteral(focusAreaEEnum, FocusArea.SENSORS);

		initEEnum(cropTypeEEnum, CropType.class, "CropType");
		addEEnumLiteral(cropTypeEEnum, CropType.TOMATO);
		addEEnumLiteral(cropTypeEEnum, CropType.CABBAGE);
		addEEnumLiteral(cropTypeEEnum, CropType.POTATO);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// http://www.eclipse.org/OCL/Collection
		createCollectionAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation
		  (this,
		   source,
		   new String[] {
		   });
		addAnnotation
		  (farmEClass,
		   source,
		   new String[] {
			   "constraints", "SufficientSpace"
		   });
		addAnnotation
		  (temperatureSensosorEClass,
		   source,
		   new String[] {
			   "constraints", "arePlantsAlive"
		   });
		addAnnotation
		  (soilSensorEClass,
		   source,
		   new String[] {
			   "constraints", "isSoiltooBasic"
		   });
		addAnnotation
		  (humiditySensorEClass,
		   source,
		   new String[] {
			   "constraints", "isHumiditytoomuch"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation
		  (getFarm__IsSpaceaAvailable(),
		   source,
		   new String[] {
			   "body", " self.MaxCrates>=crate->size()"
		   });
		addAnnotation
		  (getFarm__SufficientSpace__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.MaxCrates>=crate->size()"
		   });
		addAnnotation
		  (getTemperatureSensosor__ArePlantsAlive(),
		   source,
		   new String[] {
			   "body", "self.PlantTemperature<=26"
		   });
		addAnnotation
		  (getTemperatureSensosor__ArePlantsAlive__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.CrateTemperature>=self.PlantTemperature"
		   });
		addAnnotation
		  (getSoilSensor__IsSoiltooAcidic__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.ph>=4"
		   });
		addAnnotation
		  (getSoilSensor__IsSoiltooBasic__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.ph<=10"
		   });
		addAnnotation
		  (getHumiditySensor__IsHumiditytooless__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.HumidityValueInPercentage>=50"
		   });
		addAnnotation
		  (getHumiditySensor__IsHumiditytoomuch__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.HumidityValueInPercentage<=90"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Collection</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createCollectionAnnotations() {
		String source = "http://www.eclipse.org/OCL/Collection";
		addAnnotation
		  (getCrate_WorkingAI(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
		addAnnotation
		  (getCrate_WorkingDrones(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
		addAnnotation
		  (getCrate_WorkingCameras(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
	}

} //SmartFarmingPackageImpl
