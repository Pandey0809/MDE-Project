/**
 */
package smartFarming.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.oclany.OclComparableGreaterThanEqualOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.RealValue;

import smartFarming.SmartFarmingPackage;
import smartFarming.SmartFarmingTables;
import smartFarming.TemperatureSensosor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Temperature Sensosor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.TemperatureSensosorImpl#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}</li>
 *   <li>{@link smartFarming.impl.TemperatureSensosorImpl#getCrateTemperature <em>Crate Temperature</em>}</li>
 *   <li>{@link smartFarming.impl.TemperatureSensosorImpl#getPlantTemperature <em>Plant Temperature</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TemperatureSensosorImpl extends MinimalEObjectImpl.Container implements TemperatureSensosor {
	/**
	 * The default value of the '{@link #isTemperatureinDegreeCelcius() <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTemperatureinDegreeCelcius() <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 * @ordered
	 */
	protected boolean temperatureinDegreeCelcius = TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getCrateTemperature() <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrateTemperature()
	 * @generated
	 * @ordered
	 */
	protected static final float CRATE_TEMPERATURE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getCrateTemperature() <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrateTemperature()
	 * @generated
	 * @ordered
	 */
	protected float crateTemperature = CRATE_TEMPERATURE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPlantTemperature() <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlantTemperature()
	 * @generated
	 * @ordered
	 */
	protected static final float PLANT_TEMPERATURE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPlantTemperature() <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlantTemperature()
	 * @generated
	 * @ordered
	 */
	protected float plantTemperature = PLANT_TEMPERATURE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TemperatureSensosorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTemperatureinDegreeCelcius() {
		return temperatureinDegreeCelcius;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemperatureinDegreeCelcius(boolean newTemperatureinDegreeCelcius) {
		boolean oldTemperatureinDegreeCelcius = temperatureinDegreeCelcius;
		temperatureinDegreeCelcius = newTemperatureinDegreeCelcius;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS, oldTemperatureinDegreeCelcius, temperatureinDegreeCelcius));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getCrateTemperature() {
		return crateTemperature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCrateTemperature(float newCrateTemperature) {
		float oldCrateTemperature = crateTemperature;
		crateTemperature = newCrateTemperature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE, oldCrateTemperature, crateTemperature));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getPlantTemperature() {
		return plantTemperature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlantTemperature(float newPlantTemperature) {
		float oldPlantTemperature = plantTemperature;
		plantTemperature = newPlantTemperature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE, oldPlantTemperature, plantTemperature));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean arePlantsAlive() {
		/**
		 * self.PlantTemperature <= 26
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ float PlantTemperature = this.getPlantTemperature();
		final /*@NonInvalid*/ RealValue BOXED_PlantTemperature = ValueUtil.realValueOf(PlantTemperature);
		final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, BOXED_PlantTemperature, SmartFarmingTables.INT_26).booleanValue();
		return le;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean arePlantsAlive(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "TemperatureSensosor::arePlantsAlive";
		try {
			/**
			 *
			 * inv arePlantsAlive:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.CrateTemperature >= self.PlantTemperature
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ float CrateTemperature = this.getCrateTemperature();
				final /*@NonInvalid*/ RealValue BOXED_CrateTemperature = ValueUtil.realValueOf(CrateTemperature);
				final /*@NonInvalid*/ float PlantTemperature = this.getPlantTemperature();
				final /*@NonInvalid*/ RealValue BOXED_PlantTemperature = ValueUtil.realValueOf(PlantTemperature);
				final /*@NonInvalid*/ boolean result = OclComparableGreaterThanEqualOperation.INSTANCE.evaluate(executor, BOXED_CrateTemperature, BOXED_PlantTemperature).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS:
				return isTemperatureinDegreeCelcius();
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE:
				return getCrateTemperature();
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE:
				return getPlantTemperature();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS:
				setTemperatureinDegreeCelcius((Boolean)newValue);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE:
				setCrateTemperature((Float)newValue);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE:
				setPlantTemperature((Float)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS:
				setTemperatureinDegreeCelcius(TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE:
				setCrateTemperature(CRATE_TEMPERATURE_EDEFAULT);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE:
				setPlantTemperature(PLANT_TEMPERATURE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS:
				return temperatureinDegreeCelcius != TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE:
				return crateTemperature != CRATE_TEMPERATURE_EDEFAULT;
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE:
				return plantTemperature != PLANT_TEMPERATURE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR___ARE_PLANTS_ALIVE:
				return arePlantsAlive();
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP:
				return arePlantsAlive((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TemperatureinDegreeCelcius: ");
		result.append(temperatureinDegreeCelcius);
		result.append(", CrateTemperature: ");
		result.append(crateTemperature);
		result.append(", PlantTemperature: ");
		result.append(plantTemperature);
		result.append(')');
		return result.toString();
	}

} //TemperatureSensosorImpl
