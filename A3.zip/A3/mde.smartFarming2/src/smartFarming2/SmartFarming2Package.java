/**
 */
package smartFarming2;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see smartFarming2.SmartFarming2Factory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore"
 * @generated
 */
public interface SmartFarming2Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "smartFarming2";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/mdt/ocl/oclinecore/tutorial";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "SmartFarmingv2";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SmartFarming2Package eINSTANCE = smartFarming2.impl.SmartFarming2PackageImpl.init();

	/**
	 * The meta object id for the '{@link smartFarming2.impl.NameImpl <em>Name</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.NameImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getName_()
	 * @generated
	 */
	int NAME = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME__NAME = 0;

	/**
	 * The number of structural features of the '<em>Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.FarmImpl <em>Farm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.FarmImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getFarm()
	 * @generated
	 */
	int FARM = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Crate</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__CRATE = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Drone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__DRONE = NAME_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__CAMERA = NAME_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Os</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__OS = NAME_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Max Crates</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__MAX_CRATES = NAME_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Farm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM_FEATURE_COUNT = NAME_FEATURE_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Spacea Available</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM___IS_SPACEA_AVAILABLE = NAME_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Sufficient Space</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP = NAME_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Farm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM_OPERATION_COUNT = NAME_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.CrateidImpl <em>Crateid</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.CrateidImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrateid()
	 * @generated
	 */
	int CRATEID = 9;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID__ID = 0;

	/**
	 * The number of structural features of the '<em>Crateid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Crateid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.CrateImpl <em>Crate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.CrateImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrate()
	 * @generated
	 */
	int CRATE = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__ID = CRATEID__ID;

	/**
	 * The feature id for the '<em><b>Light</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__LIGHT = CRATEID_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Sensors</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__SENSORS = CRATEID_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Crop Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__CROP_TYPE = CRATEID_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Working OS</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__WORKING_OS = CRATEID_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Working Drones</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__WORKING_DRONES = CRATEID_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Working Cameras</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__WORKING_CAMERAS = CRATEID_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Crate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_FEATURE_COUNT = CRATEID_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Crate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_OPERATION_COUNT = CRATEID_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.DroneImpl <em>Drone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.DroneImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getDrone()
	 * @generated
	 */
	int DRONE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__TURN_ON = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Drone Monitoring</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__DRONE_MONITORING = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Drone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE_FEATURE_COUNT = NAME_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Drone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.CameraImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Camera Focus</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__CAMERA_FOCUS = NAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.MonitoringOSImpl <em>Monitoring OS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.MonitoringOSImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getMonitoringOS()
	 * @generated
	 */
	int MONITORING_OS = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_OS__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>OSfocus Area</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_OS__OSFOCUS_AREA = NAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Monitoring OS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_OS_FEATURE_COUNT = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Monitoring OS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MONITORING_OS_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.CrateSensorsImpl <em>Crate Sensors</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.CrateSensorsImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrateSensors()
	 * @generated
	 */
	int CRATE_SENSORS = 5;

	/**
	 * The feature id for the '<em><b>Temperaturein Degree Celcius</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__TEMPERATUREIN_DEGREE_CELCIUS = 0;

	/**
	 * The feature id for the '<em><b>Crate Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__CRATE_TEMPERATURE = 1;

	/**
	 * The feature id for the '<em><b>Plant Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__PLANT_TEMPERATURE = 2;

	/**
	 * The feature id for the '<em><b>Ph</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__PH = 3;

	/**
	 * The feature id for the '<em><b>Soil Moisture In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__SOIL_MOISTURE_IN_PERCENTAGE = 4;

	/**
	 * The feature id for the '<em><b>Humidity Value In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS__HUMIDITY_VALUE_IN_PERCENTAGE = 5;

	/**
	 * The number of structural features of the '<em>Crate Sensors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS_FEATURE_COUNT = 6;

	/**
	 * The operation id for the '<em>Are Plants Alive</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___ARE_PLANTS_ALIVE = 0;

	/**
	 * The operation id for the '<em>Is Soiltoo Basic</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP = 1;

	/**
	 * The operation id for the '<em>Is Humiditytooless</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP = 2;

	/**
	 * The operation id for the '<em>Is Humiditytoomuch</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP = 3;

	/**
	 * The operation id for the '<em>Is Soiltoo Acidic</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP = 4;

	/**
	 * The operation id for the '<em>Are Plants Alive</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP = 5;

	/**
	 * The number of operations of the '<em>Crate Sensors</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_SENSORS_OPERATION_COUNT = 6;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.LightImpl <em>Light</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.LightImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getLight()
	 * @generated
	 */
	int LIGHT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Type Light</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__TYPE_LIGHT = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__TURN_ON = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_FEATURE_COUNT = NAME_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming2.impl.CropImpl <em>Crop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.impl.CropImpl
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrop()
	 * @generated
	 */
	int CROP = 8;

	/**
	 * The feature id for the '<em><b>Crop</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP__CROP = 0;

	/**
	 * The number of structural features of the '<em>Crop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Crop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming2.typelight <em>typelight</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.typelight
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#gettypelight()
	 * @generated
	 */
	int TYPELIGHT = 10;

	/**
	 * The meta object id for the '{@link smartFarming2.FocusArea <em>Focus Area</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.FocusArea
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getFocusArea()
	 * @generated
	 */
	int FOCUS_AREA = 11;

	/**
	 * The meta object id for the '{@link smartFarming2.CropType <em>Crop Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming2.CropType
	 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCropType()
	 * @generated
	 */
	int CROP_TYPE = 12;


	/**
	 * Returns the meta object for class '{@link smartFarming2.Farm <em>Farm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Farm</em>'.
	 * @see smartFarming2.Farm
	 * @generated
	 */
	EClass getFarm();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming2.Farm#getCrate <em>Crate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Crate</em>'.
	 * @see smartFarming2.Farm#getCrate()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Crate();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming2.Farm#getDrone <em>Drone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Drone</em>'.
	 * @see smartFarming2.Farm#getDrone()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Drone();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming2.Farm#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Camera</em>'.
	 * @see smartFarming2.Farm#getCamera()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Camera();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming2.Farm#getOs <em>Os</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Os</em>'.
	 * @see smartFarming2.Farm#getOs()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Os();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Farm#getMaxCrates <em>Max Crates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Crates</em>'.
	 * @see smartFarming2.Farm#getMaxCrates()
	 * @see #getFarm()
	 * @generated
	 */
	EAttribute getFarm_MaxCrates();

	/**
	 * Returns the meta object for the '{@link smartFarming2.Farm#isSpaceaAvailable() <em>Is Spacea Available</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Spacea Available</em>' operation.
	 * @see smartFarming2.Farm#isSpaceaAvailable()
	 * @generated
	 */
	EOperation getFarm__IsSpaceaAvailable();

	/**
	 * Returns the meta object for the '{@link smartFarming2.Farm#SufficientSpace(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Sufficient Space</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Sufficient Space</em>' operation.
	 * @see smartFarming2.Farm#SufficientSpace(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getFarm__SufficientSpace__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Crate <em>Crate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crate</em>'.
	 * @see smartFarming2.Crate
	 * @generated
	 */
	EClass getCrate();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming2.Crate#getLight <em>Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Light</em>'.
	 * @see smartFarming2.Crate#getLight()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Light();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming2.Crate#getSensors <em>Sensors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Sensors</em>'.
	 * @see smartFarming2.Crate#getSensors()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Sensors();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming2.Crate#getCropType <em>Crop Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Crop Type</em>'.
	 * @see smartFarming2.Crate#getCropType()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_CropType();

	/**
	 * Returns the meta object for the reference list '{@link smartFarming2.Crate#getWorkingOS <em>Working OS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Working OS</em>'.
	 * @see smartFarming2.Crate#getWorkingOS()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_WorkingOS();

	/**
	 * Returns the meta object for the reference list '{@link smartFarming2.Crate#getWorkingDrones <em>Working Drones</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Working Drones</em>'.
	 * @see smartFarming2.Crate#getWorkingDrones()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_WorkingDrones();

	/**
	 * Returns the meta object for the reference list '{@link smartFarming2.Crate#getWorkingCameras <em>Working Cameras</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Working Cameras</em>'.
	 * @see smartFarming2.Crate#getWorkingCameras()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_WorkingCameras();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Drone <em>Drone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Drone</em>'.
	 * @see smartFarming2.Drone
	 * @generated
	 */
	EClass getDrone();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Drone#isTurnOn <em>Turn On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn On</em>'.
	 * @see smartFarming2.Drone#isTurnOn()
	 * @see #getDrone()
	 * @generated
	 */
	EAttribute getDrone_TurnOn();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Drone#getDroneMonitoring <em>Drone Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Drone Monitoring</em>'.
	 * @see smartFarming2.Drone#getDroneMonitoring()
	 * @see #getDrone()
	 * @generated
	 */
	EAttribute getDrone_DroneMonitoring();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see smartFarming2.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Camera#getCameraFocus <em>Camera Focus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Camera Focus</em>'.
	 * @see smartFarming2.Camera#getCameraFocus()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_CameraFocus();

	/**
	 * Returns the meta object for class '{@link smartFarming2.MonitoringOS <em>Monitoring OS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Monitoring OS</em>'.
	 * @see smartFarming2.MonitoringOS
	 * @generated
	 */
	EClass getMonitoringOS();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.MonitoringOS#getOSfocusArea <em>OSfocus Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>OSfocus Area</em>'.
	 * @see smartFarming2.MonitoringOS#getOSfocusArea()
	 * @see #getMonitoringOS()
	 * @generated
	 */
	EAttribute getMonitoringOS_OSfocusArea();

	/**
	 * Returns the meta object for class '{@link smartFarming2.CrateSensors <em>Crate Sensors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crate Sensors</em>'.
	 * @see smartFarming2.CrateSensors
	 * @generated
	 */
	EClass getCrateSensors();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temperaturein Degree Celcius</em>'.
	 * @see smartFarming2.CrateSensors#isTemperatureinDegreeCelcius()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_TemperatureinDegreeCelcius();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#getCrateTemperature <em>Crate Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Crate Temperature</em>'.
	 * @see smartFarming2.CrateSensors#getCrateTemperature()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_CrateTemperature();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#getPlantTemperature <em>Plant Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Plant Temperature</em>'.
	 * @see smartFarming2.CrateSensors#getPlantTemperature()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_PlantTemperature();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#getPh <em>Ph</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ph</em>'.
	 * @see smartFarming2.CrateSensors#getPh()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_Ph();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Soil Moisture In Percentage</em>'.
	 * @see smartFarming2.CrateSensors#getSoilMoistureInPercentage()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_SoilMoistureInPercentage();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.CrateSensors#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Humidity Value In Percentage</em>'.
	 * @see smartFarming2.CrateSensors#getHumidityValueInPercentage()
	 * @see #getCrateSensors()
	 * @generated
	 */
	EAttribute getCrateSensors_HumidityValueInPercentage();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#arePlantsAlive() <em>Are Plants Alive</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Are Plants Alive</em>' operation.
	 * @see smartFarming2.CrateSensors#arePlantsAlive()
	 * @generated
	 */
	EOperation getCrateSensors__ArePlantsAlive();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#isSoiltooBasic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Basic</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Soiltoo Basic</em>' operation.
	 * @see smartFarming2.CrateSensors#isSoiltooBasic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCrateSensors__IsSoiltooBasic__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#isHumiditytooless(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytooless</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Humiditytooless</em>' operation.
	 * @see smartFarming2.CrateSensors#isHumiditytooless(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCrateSensors__IsHumiditytooless__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#isHumiditytoomuch(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytoomuch</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Humiditytoomuch</em>' operation.
	 * @see smartFarming2.CrateSensors#isHumiditytoomuch(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCrateSensors__IsHumiditytoomuch__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#isSoiltooAcidic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Acidic</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Soiltoo Acidic</em>' operation.
	 * @see smartFarming2.CrateSensors#isSoiltooAcidic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCrateSensors__IsSoiltooAcidic__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link smartFarming2.CrateSensors#arePlantsAlive(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Are Plants Alive</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Are Plants Alive</em>' operation.
	 * @see smartFarming2.CrateSensors#arePlantsAlive(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getCrateSensors__ArePlantsAlive__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Light <em>Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Light</em>'.
	 * @see smartFarming2.Light
	 * @generated
	 */
	EClass getLight();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Light#getTypeLight <em>Type Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Light</em>'.
	 * @see smartFarming2.Light#getTypeLight()
	 * @see #getLight()
	 * @generated
	 */
	EAttribute getLight_TypeLight();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Light#isTurnOn <em>Turn On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn On</em>'.
	 * @see smartFarming2.Light#isTurnOn()
	 * @see #getLight()
	 * @generated
	 */
	EAttribute getLight_TurnOn();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Name <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Name</em>'.
	 * @see smartFarming2.Name
	 * @generated
	 */
	EClass getName_();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Name#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see smartFarming2.Name#getName()
	 * @see #getName_()
	 * @generated
	 */
	EAttribute getName_Name();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Crop <em>Crop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crop</em>'.
	 * @see smartFarming2.Crop
	 * @generated
	 */
	EClass getCrop();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Crop#getCrop <em>Crop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Crop</em>'.
	 * @see smartFarming2.Crop#getCrop()
	 * @see #getCrop()
	 * @generated
	 */
	EAttribute getCrop_Crop();

	/**
	 * Returns the meta object for class '{@link smartFarming2.Crateid <em>Crateid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crateid</em>'.
	 * @see smartFarming2.Crateid
	 * @generated
	 */
	EClass getCrateid();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming2.Crateid#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see smartFarming2.Crateid#getId()
	 * @see #getCrateid()
	 * @generated
	 */
	EAttribute getCrateid_Id();

	/**
	 * Returns the meta object for enum '{@link smartFarming2.typelight <em>typelight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>typelight</em>'.
	 * @see smartFarming2.typelight
	 * @generated
	 */
	EEnum gettypelight();

	/**
	 * Returns the meta object for enum '{@link smartFarming2.FocusArea <em>Focus Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Focus Area</em>'.
	 * @see smartFarming2.FocusArea
	 * @generated
	 */
	EEnum getFocusArea();

	/**
	 * Returns the meta object for enum '{@link smartFarming2.CropType <em>Crop Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Crop Type</em>'.
	 * @see smartFarming2.CropType
	 * @generated
	 */
	EEnum getCropType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SmartFarming2Factory getSmartFarming2Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link smartFarming2.impl.FarmImpl <em>Farm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.FarmImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getFarm()
		 * @generated
		 */
		EClass FARM = eINSTANCE.getFarm();

		/**
		 * The meta object literal for the '<em><b>Crate</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__CRATE = eINSTANCE.getFarm_Crate();

		/**
		 * The meta object literal for the '<em><b>Drone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__DRONE = eINSTANCE.getFarm_Drone();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__CAMERA = eINSTANCE.getFarm_Camera();

		/**
		 * The meta object literal for the '<em><b>Os</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__OS = eINSTANCE.getFarm_Os();

		/**
		 * The meta object literal for the '<em><b>Max Crates</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARM__MAX_CRATES = eINSTANCE.getFarm_MaxCrates();

		/**
		 * The meta object literal for the '<em><b>Is Spacea Available</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FARM___IS_SPACEA_AVAILABLE = eINSTANCE.getFarm__IsSpaceaAvailable();

		/**
		 * The meta object literal for the '<em><b>Sufficient Space</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getFarm__SufficientSpace__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.CrateImpl <em>Crate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.CrateImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrate()
		 * @generated
		 */
		EClass CRATE = eINSTANCE.getCrate();

		/**
		 * The meta object literal for the '<em><b>Light</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__LIGHT = eINSTANCE.getCrate_Light();

		/**
		 * The meta object literal for the '<em><b>Sensors</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__SENSORS = eINSTANCE.getCrate_Sensors();

		/**
		 * The meta object literal for the '<em><b>Crop Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__CROP_TYPE = eINSTANCE.getCrate_CropType();

		/**
		 * The meta object literal for the '<em><b>Working OS</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__WORKING_OS = eINSTANCE.getCrate_WorkingOS();

		/**
		 * The meta object literal for the '<em><b>Working Drones</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__WORKING_DRONES = eINSTANCE.getCrate_WorkingDrones();

		/**
		 * The meta object literal for the '<em><b>Working Cameras</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__WORKING_CAMERAS = eINSTANCE.getCrate_WorkingCameras();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.DroneImpl <em>Drone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.DroneImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getDrone()
		 * @generated
		 */
		EClass DRONE = eINSTANCE.getDrone();

		/**
		 * The meta object literal for the '<em><b>Turn On</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRONE__TURN_ON = eINSTANCE.getDrone_TurnOn();

		/**
		 * The meta object literal for the '<em><b>Drone Monitoring</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRONE__DRONE_MONITORING = eINSTANCE.getDrone_DroneMonitoring();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.CameraImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Camera Focus</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__CAMERA_FOCUS = eINSTANCE.getCamera_CameraFocus();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.MonitoringOSImpl <em>Monitoring OS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.MonitoringOSImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getMonitoringOS()
		 * @generated
		 */
		EClass MONITORING_OS = eINSTANCE.getMonitoringOS();

		/**
		 * The meta object literal for the '<em><b>OSfocus Area</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MONITORING_OS__OSFOCUS_AREA = eINSTANCE.getMonitoringOS_OSfocusArea();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.CrateSensorsImpl <em>Crate Sensors</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.CrateSensorsImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrateSensors()
		 * @generated
		 */
		EClass CRATE_SENSORS = eINSTANCE.getCrateSensors();

		/**
		 * The meta object literal for the '<em><b>Temperaturein Degree Celcius</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__TEMPERATUREIN_DEGREE_CELCIUS = eINSTANCE.getCrateSensors_TemperatureinDegreeCelcius();

		/**
		 * The meta object literal for the '<em><b>Crate Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__CRATE_TEMPERATURE = eINSTANCE.getCrateSensors_CrateTemperature();

		/**
		 * The meta object literal for the '<em><b>Plant Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__PLANT_TEMPERATURE = eINSTANCE.getCrateSensors_PlantTemperature();

		/**
		 * The meta object literal for the '<em><b>Ph</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__PH = eINSTANCE.getCrateSensors_Ph();

		/**
		 * The meta object literal for the '<em><b>Soil Moisture In Percentage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__SOIL_MOISTURE_IN_PERCENTAGE = eINSTANCE.getCrateSensors_SoilMoistureInPercentage();

		/**
		 * The meta object literal for the '<em><b>Humidity Value In Percentage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATE_SENSORS__HUMIDITY_VALUE_IN_PERCENTAGE = eINSTANCE.getCrateSensors_HumidityValueInPercentage();

		/**
		 * The meta object literal for the '<em><b>Are Plants Alive</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___ARE_PLANTS_ALIVE = eINSTANCE.getCrateSensors__ArePlantsAlive();

		/**
		 * The meta object literal for the '<em><b>Is Soiltoo Basic</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCrateSensors__IsSoiltooBasic__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Is Humiditytooless</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCrateSensors__IsHumiditytooless__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Is Humiditytoomuch</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCrateSensors__IsHumiditytoomuch__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Is Soiltoo Acidic</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCrateSensors__IsSoiltooAcidic__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Are Plants Alive</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CRATE_SENSORS___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP = eINSTANCE.getCrateSensors__ArePlantsAlive__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.LightImpl <em>Light</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.LightImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getLight()
		 * @generated
		 */
		EClass LIGHT = eINSTANCE.getLight();

		/**
		 * The meta object literal for the '<em><b>Type Light</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT__TYPE_LIGHT = eINSTANCE.getLight_TypeLight();

		/**
		 * The meta object literal for the '<em><b>Turn On</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT__TURN_ON = eINSTANCE.getLight_TurnOn();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.NameImpl <em>Name</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.NameImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getName_()
		 * @generated
		 */
		EClass NAME = eINSTANCE.getName_();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAME__NAME = eINSTANCE.getName_Name();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.CropImpl <em>Crop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.CropImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrop()
		 * @generated
		 */
		EClass CROP = eINSTANCE.getCrop();

		/**
		 * The meta object literal for the '<em><b>Crop</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CROP__CROP = eINSTANCE.getCrop_Crop();

		/**
		 * The meta object literal for the '{@link smartFarming2.impl.CrateidImpl <em>Crateid</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.impl.CrateidImpl
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCrateid()
		 * @generated
		 */
		EClass CRATEID = eINSTANCE.getCrateid();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATEID__ID = eINSTANCE.getCrateid_Id();

		/**
		 * The meta object literal for the '{@link smartFarming2.typelight <em>typelight</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.typelight
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#gettypelight()
		 * @generated
		 */
		EEnum TYPELIGHT = eINSTANCE.gettypelight();

		/**
		 * The meta object literal for the '{@link smartFarming2.FocusArea <em>Focus Area</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.FocusArea
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getFocusArea()
		 * @generated
		 */
		EEnum FOCUS_AREA = eINSTANCE.getFocusArea();

		/**
		 * The meta object literal for the '{@link smartFarming2.CropType <em>Crop Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming2.CropType
		 * @see smartFarming2.impl.SmartFarming2PackageImpl#getCropType()
		 * @generated
		 */
		EEnum CROP_TYPE = eINSTANCE.getCropType();

	}

} //SmartFarming2Package
