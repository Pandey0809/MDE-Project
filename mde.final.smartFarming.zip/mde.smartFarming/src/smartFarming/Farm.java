/**
 */
package smartFarming;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Farm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Farm#getCrate <em>Crate</em>}</li>
 *   <li>{@link smartFarming.Farm#getDrone <em>Drone</em>}</li>
 *   <li>{@link smartFarming.Farm#getCamera <em>Camera</em>}</li>
 *   <li>{@link smartFarming.Farm#getAi <em>Ai</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getFarm()
 * @model
 * @generated
 */
public interface Farm extends Name {
	/**
	 * Returns the value of the '<em><b>Crate</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Crate}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crate</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Crate()
	 * @model containment="true"
	 * @generated
	 */
	EList<Crate> getCrate();

	/**
	 * Returns the value of the '<em><b>Drone</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Drone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drone</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Drone()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Drone> getDrone();

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Camera}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Camera()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Camera> getCamera();

	/**
	 * Returns the value of the '<em><b>Ai</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ai</em>' containment reference.
	 * @see #setAi(AI)
	 * @see smartFarming.SmartFarmingPackage#getFarm_Ai()
	 * @model containment="true"
	 * @generated
	 */
	AI getAi();

	/**
	 * Sets the value of the '{@link smartFarming.Farm#getAi <em>Ai</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ai</em>' containment reference.
	 * @see #getAi()
	 * @generated
	 */
	void setAi(AI value);

} // Farm
