/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import smartFarming.HumiditySensor;
import smartFarming.SmartFarmingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Humidity Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.HumiditySensorImpl#getHumidityValue <em>Humidity Value</em>}</li>
 *   <li>{@link smartFarming.impl.HumiditySensorImpl#isTurnOn <em>Turn On</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HumiditySensorImpl extends MinimalEObjectImpl.Container implements HumiditySensor {
	/**
	 * The default value of the '{@link #getHumidityValue() <em>Humidity Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHumidityValue()
	 * @generated
	 * @ordered
	 */
	protected static final float HUMIDITY_VALUE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getHumidityValue() <em>Humidity Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHumidityValue()
	 * @generated
	 * @ordered
	 */
	protected float humidityValue = HUMIDITY_VALUE_EDEFAULT;

	/**
	 * The default value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TURN_ON_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected boolean turnOn = TURN_ON_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HumiditySensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.HUMIDITY_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getHumidityValue() {
		return humidityValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHumidityValue(float newHumidityValue) {
		float oldHumidityValue = humidityValue;
		humidityValue = newHumidityValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE, oldHumidityValue, humidityValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTurnOn() {
		return turnOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTurnOn(boolean newTurnOn) {
		boolean oldTurnOn = turnOn;
		turnOn = newTurnOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON, oldTurnOn, turnOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE:
				return getHumidityValue();
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				return isTurnOn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE:
				setHumidityValue((Float)newValue);
				return;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				setTurnOn((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE:
				setHumidityValue(HUMIDITY_VALUE_EDEFAULT);
				return;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				setTurnOn(TURN_ON_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.HUMIDITY_SENSOR__HUMIDITY_VALUE:
				return humidityValue != HUMIDITY_VALUE_EDEFAULT;
			case SmartFarmingPackage.HUMIDITY_SENSOR__TURN_ON:
				return turnOn != TURN_ON_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (HumidityValue: ");
		result.append(humidityValue);
		result.append(", TurnOn: ");
		result.append(turnOn);
		result.append(')');
		return result.toString();
	}

} //HumiditySensorImpl
