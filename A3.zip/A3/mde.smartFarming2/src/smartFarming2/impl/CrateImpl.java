/**
 */
package smartFarming2.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.IdResolver;

import org.eclipse.ocl.pivot.ids.IdResolver.IdResolverExtension;

import org.eclipse.ocl.pivot.library.classifier.ClassifierAllInstancesOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;

import org.eclipse.ocl.pivot.values.SetValue;

import smartFarming2.Camera;
import smartFarming2.Crate;
import smartFarming2.CrateSensors;
import smartFarming2.Crop;
import smartFarming2.Drone;
import smartFarming2.Light;
import smartFarming2.MonitoringOS;
import smartFarming2.SmartFarming2Package;
import smartFarming2.SmartFarming2Tables;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.impl.CrateImpl#getLight <em>Light</em>}</li>
 *   <li>{@link smartFarming2.impl.CrateImpl#getSensors <em>Sensors</em>}</li>
 *   <li>{@link smartFarming2.impl.CrateImpl#getCropType <em>Crop Type</em>}</li>
 *   <li>{@link smartFarming2.impl.CrateImpl#getWorkingOS <em>Working OS</em>}</li>
 *   <li>{@link smartFarming2.impl.CrateImpl#getWorkingDrones <em>Working Drones</em>}</li>
 *   <li>{@link smartFarming2.impl.CrateImpl#getWorkingCameras <em>Working Cameras</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CrateImpl extends CrateidImpl implements Crate {
	/**
	 * The cached value of the '{@link #getLight() <em>Light</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLight()
	 * @generated
	 * @ordered
	 */
	protected EList<Light> light;

	/**
	 * The cached value of the '{@link #getSensors() <em>Sensors</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSensors()
	 * @generated
	 * @ordered
	 */
	protected CrateSensors sensors;

	/**
	 * The cached value of the '{@link #getCropType() <em>Crop Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCropType()
	 * @generated
	 * @ordered
	 */
	protected Crop cropType;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CrateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarming2Package.Literals.CRATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Light> getLight() {
		if (light == null) {
			light = new EObjectContainmentEList<Light>(Light.class, this, SmartFarming2Package.CRATE__LIGHT);
		}
		return light;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CrateSensors getSensors() {
		return sensors;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSensors(CrateSensors newSensors, NotificationChain msgs) {
		CrateSensors oldSensors = sensors;
		sensors = newSensors;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarming2Package.CRATE__SENSORS, oldSensors, newSensors);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSensors(CrateSensors newSensors) {
		if (newSensors != sensors) {
			NotificationChain msgs = null;
			if (sensors != null)
				msgs = ((InternalEObject)sensors).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarming2Package.CRATE__SENSORS, null, msgs);
			if (newSensors != null)
				msgs = ((InternalEObject)newSensors).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarming2Package.CRATE__SENSORS, null, msgs);
			msgs = basicSetSensors(newSensors, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.CRATE__SENSORS, newSensors, newSensors));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Crop getCropType() {
		return cropType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCropType(Crop newCropType, NotificationChain msgs) {
		Crop oldCropType = cropType;
		cropType = newCropType;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarming2Package.CRATE__CROP_TYPE, oldCropType, newCropType);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCropType(Crop newCropType) {
		if (newCropType != cropType) {
			NotificationChain msgs = null;
			if (cropType != null)
				msgs = ((InternalEObject)cropType).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarming2Package.CRATE__CROP_TYPE, null, msgs);
			if (newCropType != null)
				msgs = ((InternalEObject)newCropType).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarming2Package.CRATE__CROP_TYPE, null, msgs);
			msgs = basicSetCropType(newCropType, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.CRATE__CROP_TYPE, newCropType, newCropType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MonitoringOS> getWorkingOS() {
		/**
		 * MonitoringOS.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming2_c_c_MonitoringOS_0 = idResolver.getClass(SmartFarming2Tables.CLSSid_MonitoringOS, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarming2Tables.SET_CLSSid_MonitoringOS, TYP_smartFarming2_c_c_MonitoringOS_0);
		final /*@NonInvalid*/ List<MonitoringOS> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(MonitoringOS.class, allInstances);
		return (EList<MonitoringOS>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drone> getWorkingDrones() {
		/**
		 * Drone.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming2_c_c_Drone_0 = idResolver.getClass(SmartFarming2Tables.CLSSid_Drone, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarming2Tables.SET_CLSSid_Drone, TYP_smartFarming2_c_c_Drone_0);
		final /*@NonInvalid*/ List<Drone> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(Drone.class, allInstances);
		return (EList<Drone>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Camera> getWorkingCameras() {
		/**
		 * Camera.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming2_c_c_Camera_0 = idResolver.getClass(SmartFarming2Tables.CLSSid_Camera, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarming2Tables.SET_CLSSid_Camera, TYP_smartFarming2_c_c_Camera_0);
		final /*@NonInvalid*/ List<Camera> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(Camera.class, allInstances);
		return (EList<Camera>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmartFarming2Package.CRATE__LIGHT:
				return ((InternalEList<?>)getLight()).basicRemove(otherEnd, msgs);
			case SmartFarming2Package.CRATE__SENSORS:
				return basicSetSensors(null, msgs);
			case SmartFarming2Package.CRATE__CROP_TYPE:
				return basicSetCropType(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarming2Package.CRATE__LIGHT:
				return getLight();
			case SmartFarming2Package.CRATE__SENSORS:
				return getSensors();
			case SmartFarming2Package.CRATE__CROP_TYPE:
				return getCropType();
			case SmartFarming2Package.CRATE__WORKING_OS:
				return getWorkingOS();
			case SmartFarming2Package.CRATE__WORKING_DRONES:
				return getWorkingDrones();
			case SmartFarming2Package.CRATE__WORKING_CAMERAS:
				return getWorkingCameras();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarming2Package.CRATE__LIGHT:
				getLight().clear();
				getLight().addAll((Collection<? extends Light>)newValue);
				return;
			case SmartFarming2Package.CRATE__SENSORS:
				setSensors((CrateSensors)newValue);
				return;
			case SmartFarming2Package.CRATE__CROP_TYPE:
				setCropType((Crop)newValue);
				return;
			case SmartFarming2Package.CRATE__WORKING_OS:
				getWorkingOS().clear();
				getWorkingOS().addAll((Collection<? extends MonitoringOS>)newValue);
				return;
			case SmartFarming2Package.CRATE__WORKING_DRONES:
				getWorkingDrones().clear();
				getWorkingDrones().addAll((Collection<? extends Drone>)newValue);
				return;
			case SmartFarming2Package.CRATE__WORKING_CAMERAS:
				getWorkingCameras().clear();
				getWorkingCameras().addAll((Collection<? extends Camera>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.CRATE__LIGHT:
				getLight().clear();
				return;
			case SmartFarming2Package.CRATE__SENSORS:
				setSensors((CrateSensors)null);
				return;
			case SmartFarming2Package.CRATE__CROP_TYPE:
				setCropType((Crop)null);
				return;
			case SmartFarming2Package.CRATE__WORKING_OS:
				getWorkingOS().clear();
				return;
			case SmartFarming2Package.CRATE__WORKING_DRONES:
				getWorkingDrones().clear();
				return;
			case SmartFarming2Package.CRATE__WORKING_CAMERAS:
				getWorkingCameras().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.CRATE__LIGHT:
				return light != null && !light.isEmpty();
			case SmartFarming2Package.CRATE__SENSORS:
				return sensors != null;
			case SmartFarming2Package.CRATE__CROP_TYPE:
				return cropType != null;
			case SmartFarming2Package.CRATE__WORKING_OS:
				return !getWorkingOS().isEmpty();
			case SmartFarming2Package.CRATE__WORKING_DRONES:
				return !getWorkingDrones().isEmpty();
			case SmartFarming2Package.CRATE__WORKING_CAMERAS:
				return !getWorkingCameras().isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CrateImpl
