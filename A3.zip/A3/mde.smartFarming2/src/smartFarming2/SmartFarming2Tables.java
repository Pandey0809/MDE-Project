/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /mde.smartFarming2/model/smartFarming2.ecore
 * using:
 *   /mde.smartFarming2/model/smartFarming2.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package smartFarming2;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.TemplateParameters;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.TypeUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;
// import smartFarming2.SmartFarming2Package;
// import smartFarming2.SmartFarming2Tables;

/**
 * SmartFarming2Tables provides the dispatch tables for the smartFarming2 for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class SmartFarming2Tables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(SmartFarming2Package.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ RootPackageId PACKid_$metamodel$ = IdManager.getRootPackageId("$metamodel$");
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial = IdManager.getNsURIPackageId("http://www.eclipse.org/mdt/ocl/oclinecore/tutorial", null, SmartFarming2Package.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_Camera = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Camera", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Class = SmartFarming2Tables.PACKid_$metamodel$.getClassId("Class", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Crate = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Crate", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_CrateSensors = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("CrateSensors", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Crop = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Crop", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Drone = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Drone", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Farm = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Farm", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Light = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("Light", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_MonitoringOS = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getClassId("MonitoringOS", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EFloat = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EFloat", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_CropType = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getEnumerationId("CropType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_FocusArea = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getEnumerationId("FocusArea");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_typelight = SmartFarming2Tables.PACKid_http_c_s_s_www_eclipse_org_s_mdt_s_ocl_s_oclinecore_s_tutorial.getEnumerationId("typelight");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_10 = ValueUtil.integerValueOf("10");
	public static final /*@NonInvalid*/ IntegerValue INT_26 = ValueUtil.integerValueOf("26");
	public static final /*@NonInvalid*/ IntegerValue INT_4 = ValueUtil.integerValueOf("4");
	public static final /*@NonInvalid*/ IntegerValue INT_50 = ValueUtil.integerValueOf("50");
	public static final /*@NonInvalid*/ IntegerValue INT_90 = ValueUtil.integerValueOf("90");
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Crate = TypeId.BAG.getSpecializedId(SmartFarming2Tables.CLSSid_Crate);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Camera = TypeId.ORDERED_SET.getSpecializedId(SmartFarming2Tables.CLSSid_Camera);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Crate = TypeId.ORDERED_SET.getSpecializedId(SmartFarming2Tables.CLSSid_Crate);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Drone = TypeId.ORDERED_SET.getSpecializedId(SmartFarming2Tables.CLSSid_Drone);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Light = TypeId.ORDERED_SET.getSpecializedId(SmartFarming2Tables.CLSSid_Light);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_MonitoringOS = TypeId.ORDERED_SET.getSpecializedId(SmartFarming2Tables.CLSSid_MonitoringOS);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Camera = TypeId.SET.getSpecializedId(SmartFarming2Tables.CLSSid_Camera);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Drone = TypeId.SET.getSpecializedId(SmartFarming2Tables.CLSSid_Drone);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_MonitoringOS = TypeId.SET.getSpecializedId(SmartFarming2Tables.CLSSid_MonitoringOS);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			SmartFarming2Tables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _Camera = new EcoreExecutorType(SmartFarming2Package.Literals.CAMERA, PACKAGE, 0);
		public static final EcoreExecutorType _Crate = new EcoreExecutorType(SmartFarming2Package.Literals.CRATE, PACKAGE, 0);
		public static final EcoreExecutorType _CrateSensors = new EcoreExecutorType(SmartFarming2Package.Literals.CRATE_SENSORS, PACKAGE, 0);
		public static final EcoreExecutorType _Crateid = new EcoreExecutorType(SmartFarming2Package.Literals.CRATEID, PACKAGE, 0);
		public static final EcoreExecutorType _Crop = new EcoreExecutorType(SmartFarming2Package.Literals.CROP, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _CropType = new EcoreExecutorEnumeration(SmartFarming2Package.Literals.CROP_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _Drone = new EcoreExecutorType(SmartFarming2Package.Literals.DRONE, PACKAGE, 0);
		public static final EcoreExecutorType _Farm = new EcoreExecutorType(SmartFarming2Package.Literals.FARM, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _FocusArea = new EcoreExecutorEnumeration(SmartFarming2Package.Literals.FOCUS_AREA, PACKAGE, 0);
		public static final EcoreExecutorType _Light = new EcoreExecutorType(SmartFarming2Package.Literals.LIGHT, PACKAGE, 0);
		public static final EcoreExecutorType _MonitoringOS = new EcoreExecutorType(SmartFarming2Package.Literals.MONITORING_OS, PACKAGE, 0);
		public static final EcoreExecutorType _Name = new EcoreExecutorType(SmartFarming2Package.Literals.NAME, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _typelight = new EcoreExecutorEnumeration(SmartFarming2Package.Literals.TYPELIGHT, PACKAGE, 0);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_Camera,
			_Crate,
			_CrateSensors,
			_Crateid,
			_Crop,
			_CropType,
			_Drone,
			_Farm,
			_FocusArea,
			_Light,
			_MonitoringOS,
			_Name,
			_typelight
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _Camera__Camera = new ExecutorFragment(Types._Camera, SmartFarming2Tables.Types._Camera);
		private static final ExecutorFragment _Camera__Name = new ExecutorFragment(Types._Camera, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _Camera__OclAny = new ExecutorFragment(Types._Camera, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Camera__OclElement = new ExecutorFragment(Types._Camera, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crate__Crate = new ExecutorFragment(Types._Crate, SmartFarming2Tables.Types._Crate);
		private static final ExecutorFragment _Crate__Crateid = new ExecutorFragment(Types._Crate, SmartFarming2Tables.Types._Crateid);
		private static final ExecutorFragment _Crate__OclAny = new ExecutorFragment(Types._Crate, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crate__OclElement = new ExecutorFragment(Types._Crate, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _CrateSensors__CrateSensors = new ExecutorFragment(Types._CrateSensors, SmartFarming2Tables.Types._CrateSensors);
		private static final ExecutorFragment _CrateSensors__OclAny = new ExecutorFragment(Types._CrateSensors, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _CrateSensors__OclElement = new ExecutorFragment(Types._CrateSensors, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crateid__Crateid = new ExecutorFragment(Types._Crateid, SmartFarming2Tables.Types._Crateid);
		private static final ExecutorFragment _Crateid__OclAny = new ExecutorFragment(Types._Crateid, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crateid__OclElement = new ExecutorFragment(Types._Crateid, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crop__Crop = new ExecutorFragment(Types._Crop, SmartFarming2Tables.Types._Crop);
		private static final ExecutorFragment _Crop__OclAny = new ExecutorFragment(Types._Crop, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crop__OclElement = new ExecutorFragment(Types._Crop, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _CropType__CropType = new ExecutorFragment(Types._CropType, SmartFarming2Tables.Types._CropType);
		private static final ExecutorFragment _CropType__OclAny = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _CropType__OclElement = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _CropType__OclEnumeration = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _CropType__OclType = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Drone__Drone = new ExecutorFragment(Types._Drone, SmartFarming2Tables.Types._Drone);
		private static final ExecutorFragment _Drone__Name = new ExecutorFragment(Types._Drone, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _Drone__OclAny = new ExecutorFragment(Types._Drone, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Drone__OclElement = new ExecutorFragment(Types._Drone, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Farm__Farm = new ExecutorFragment(Types._Farm, SmartFarming2Tables.Types._Farm);
		private static final ExecutorFragment _Farm__Name = new ExecutorFragment(Types._Farm, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _Farm__OclAny = new ExecutorFragment(Types._Farm, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Farm__OclElement = new ExecutorFragment(Types._Farm, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _FocusArea__FocusArea = new ExecutorFragment(Types._FocusArea, SmartFarming2Tables.Types._FocusArea);
		private static final ExecutorFragment _FocusArea__OclAny = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _FocusArea__OclElement = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _FocusArea__OclEnumeration = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _FocusArea__OclType = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Light__Light = new ExecutorFragment(Types._Light, SmartFarming2Tables.Types._Light);
		private static final ExecutorFragment _Light__Name = new ExecutorFragment(Types._Light, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _Light__OclAny = new ExecutorFragment(Types._Light, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Light__OclElement = new ExecutorFragment(Types._Light, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _MonitoringOS__MonitoringOS = new ExecutorFragment(Types._MonitoringOS, SmartFarming2Tables.Types._MonitoringOS);
		private static final ExecutorFragment _MonitoringOS__Name = new ExecutorFragment(Types._MonitoringOS, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _MonitoringOS__OclAny = new ExecutorFragment(Types._MonitoringOS, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _MonitoringOS__OclElement = new ExecutorFragment(Types._MonitoringOS, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Name__Name = new ExecutorFragment(Types._Name, SmartFarming2Tables.Types._Name);
		private static final ExecutorFragment _Name__OclAny = new ExecutorFragment(Types._Name, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Name__OclElement = new ExecutorFragment(Types._Name, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _typelight__OclAny = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _typelight__OclElement = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _typelight__OclEnumeration = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _typelight__OclType = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _typelight__typelight = new ExecutorFragment(Types._typelight, SmartFarming2Tables.Types._typelight);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}


		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		public static final ExecutorOperation _CrateSensors__arePlantsAlive = new ExecutorOperation("arePlantsAlive", TypeUtil.EMPTY_PARAMETER_TYPES, Types._CrateSensors,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Farm__isSpaceaAvailable = new ExecutorOperation("isSpaceaAvailable", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Farm,
			0, TemplateParameters.EMPTY_LIST, null);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _Camera__CameraFocus = new EcoreExecutorProperty(SmartFarming2Package.Literals.CAMERA__CAMERA_FOCUS, Types._Camera, 0);
		public static final ExecutorProperty _Camera__Crate__workingCameras = new ExecutorPropertyWithImplementation("Crate", Types._Camera, 1, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__WORKING_CAMERAS));
		public static final ExecutorProperty _Camera__Farm__camera = new ExecutorPropertyWithImplementation("Farm", Types._Camera, 2, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.FARM__CAMERA));

		public static final ExecutorProperty _Crate__CropType = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__CROP_TYPE, Types._Crate, 0);
		public static final ExecutorProperty _Crate__light = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__LIGHT, Types._Crate, 1);
		public static final ExecutorProperty _Crate__sensors = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__SENSORS, Types._Crate, 2);
		public static final ExecutorProperty _Crate__workingCameras = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__WORKING_CAMERAS, Types._Crate, 3);
		public static final ExecutorProperty _Crate__workingDrones = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__WORKING_DRONES, Types._Crate, 4);
		public static final ExecutorProperty _Crate__workingOS = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE__WORKING_OS, Types._Crate, 5);
		public static final ExecutorProperty _Crate__Farm__crate = new ExecutorPropertyWithImplementation("Farm", Types._Crate, 6, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.FARM__CRATE));

		public static final ExecutorProperty _CrateSensors__CrateTemperature = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__CRATE_TEMPERATURE, Types._CrateSensors, 0);
		public static final ExecutorProperty _CrateSensors__HumidityValueInPercentage = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__HUMIDITY_VALUE_IN_PERCENTAGE, Types._CrateSensors, 1);
		public static final ExecutorProperty _CrateSensors__PlantTemperature = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__PLANT_TEMPERATURE, Types._CrateSensors, 2);
		public static final ExecutorProperty _CrateSensors__SoilMoistureInPercentage = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__SOIL_MOISTURE_IN_PERCENTAGE, Types._CrateSensors, 3);
		public static final ExecutorProperty _CrateSensors__TemperatureinDegreeCelcius = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__TEMPERATUREIN_DEGREE_CELCIUS, Types._CrateSensors, 4);
		public static final ExecutorProperty _CrateSensors__ph = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATE_SENSORS__PH, Types._CrateSensors, 5);
		public static final ExecutorProperty _CrateSensors__Crate__sensors = new ExecutorPropertyWithImplementation("Crate", Types._CrateSensors, 6, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__SENSORS));

		public static final ExecutorProperty _Crateid__id = new EcoreExecutorProperty(SmartFarming2Package.Literals.CRATEID__ID, Types._Crateid, 0);

		public static final ExecutorProperty _Crop__Crop = new EcoreExecutorProperty(SmartFarming2Package.Literals.CROP__CROP, Types._Crop, 0);
		public static final ExecutorProperty _Crop__Crate__CropType = new ExecutorPropertyWithImplementation("Crate", Types._Crop, 1, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__CROP_TYPE));

		public static final ExecutorProperty _Drone__DroneMonitoring = new EcoreExecutorProperty(SmartFarming2Package.Literals.DRONE__DRONE_MONITORING, Types._Drone, 0);
		public static final ExecutorProperty _Drone__TurnOn = new EcoreExecutorProperty(SmartFarming2Package.Literals.DRONE__TURN_ON, Types._Drone, 1);
		public static final ExecutorProperty _Drone__Crate__workingDrones = new ExecutorPropertyWithImplementation("Crate", Types._Drone, 2, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__WORKING_DRONES));
		public static final ExecutorProperty _Drone__Farm__drone = new ExecutorPropertyWithImplementation("Farm", Types._Drone, 3, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.FARM__DRONE));

		public static final ExecutorProperty _Farm__MaxCrates = new EcoreExecutorProperty(SmartFarming2Package.Literals.FARM__MAX_CRATES, Types._Farm, 0);
		public static final ExecutorProperty _Farm__camera = new EcoreExecutorProperty(SmartFarming2Package.Literals.FARM__CAMERA, Types._Farm, 1);
		public static final ExecutorProperty _Farm__crate = new EcoreExecutorProperty(SmartFarming2Package.Literals.FARM__CRATE, Types._Farm, 2);
		public static final ExecutorProperty _Farm__drone = new EcoreExecutorProperty(SmartFarming2Package.Literals.FARM__DRONE, Types._Farm, 3);
		public static final ExecutorProperty _Farm__os = new EcoreExecutorProperty(SmartFarming2Package.Literals.FARM__OS, Types._Farm, 4);

		public static final ExecutorProperty _Light__TurnOn = new EcoreExecutorProperty(SmartFarming2Package.Literals.LIGHT__TURN_ON, Types._Light, 0);
		public static final ExecutorProperty _Light__TypeLight = new EcoreExecutorProperty(SmartFarming2Package.Literals.LIGHT__TYPE_LIGHT, Types._Light, 1);
		public static final ExecutorProperty _Light__Crate__light = new ExecutorPropertyWithImplementation("Crate", Types._Light, 2, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__LIGHT));

		public static final ExecutorProperty _MonitoringOS__OSfocusArea = new EcoreExecutorProperty(SmartFarming2Package.Literals.MONITORING_OS__OSFOCUS_AREA, Types._MonitoringOS, 0);
		public static final ExecutorProperty _MonitoringOS__Crate__workingOS = new ExecutorPropertyWithImplementation("Crate", Types._MonitoringOS, 1, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.CRATE__WORKING_OS));
		public static final ExecutorProperty _MonitoringOS__Farm__os = new ExecutorPropertyWithImplementation("Farm", Types._MonitoringOS, 2, new EcoreLibraryOppositeProperty(SmartFarming2Package.Literals.FARM__OS));

		public static final ExecutorProperty _Name__name = new EcoreExecutorProperty(SmartFarming2Package.Literals.NAME__NAME, Types._Name, 0);
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _Camera =
			{
				Fragments._Camera__OclAny /* 0 */,
				Fragments._Camera__OclElement /* 1 */,
				Fragments._Camera__Name /* 2 */,
				Fragments._Camera__Camera /* 3 */
			};
		private static final int /*@NonNull*/ [] __Camera = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crate =
			{
				Fragments._Crate__OclAny /* 0 */,
				Fragments._Crate__OclElement /* 1 */,
				Fragments._Crate__Crateid /* 2 */,
				Fragments._Crate__Crate /* 3 */
			};
		private static final int /*@NonNull*/ [] __Crate = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _CrateSensors =
			{
				Fragments._CrateSensors__OclAny /* 0 */,
				Fragments._CrateSensors__OclElement /* 1 */,
				Fragments._CrateSensors__CrateSensors /* 2 */
			};
		private static final int /*@NonNull*/ [] __CrateSensors = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crateid =
			{
				Fragments._Crateid__OclAny /* 0 */,
				Fragments._Crateid__OclElement /* 1 */,
				Fragments._Crateid__Crateid /* 2 */
			};
		private static final int /*@NonNull*/ [] __Crateid = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crop =
			{
				Fragments._Crop__OclAny /* 0 */,
				Fragments._Crop__OclElement /* 1 */,
				Fragments._Crop__Crop /* 2 */
			};
		private static final int /*@NonNull*/ [] __Crop = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _CropType =
			{
				Fragments._CropType__OclAny /* 0 */,
				Fragments._CropType__OclElement /* 1 */,
				Fragments._CropType__OclType /* 2 */,
				Fragments._CropType__OclEnumeration /* 3 */,
				Fragments._CropType__CropType /* 4 */
			};
		private static final int /*@NonNull*/ [] __CropType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Drone =
			{
				Fragments._Drone__OclAny /* 0 */,
				Fragments._Drone__OclElement /* 1 */,
				Fragments._Drone__Name /* 2 */,
				Fragments._Drone__Drone /* 3 */
			};
		private static final int /*@NonNull*/ [] __Drone = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Farm =
			{
				Fragments._Farm__OclAny /* 0 */,
				Fragments._Farm__OclElement /* 1 */,
				Fragments._Farm__Name /* 2 */,
				Fragments._Farm__Farm /* 3 */
			};
		private static final int /*@NonNull*/ [] __Farm = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _FocusArea =
			{
				Fragments._FocusArea__OclAny /* 0 */,
				Fragments._FocusArea__OclElement /* 1 */,
				Fragments._FocusArea__OclType /* 2 */,
				Fragments._FocusArea__OclEnumeration /* 3 */,
				Fragments._FocusArea__FocusArea /* 4 */
			};
		private static final int /*@NonNull*/ [] __FocusArea = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Light =
			{
				Fragments._Light__OclAny /* 0 */,
				Fragments._Light__OclElement /* 1 */,
				Fragments._Light__Name /* 2 */,
				Fragments._Light__Light /* 3 */
			};
		private static final int /*@NonNull*/ [] __Light = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _MonitoringOS =
			{
				Fragments._MonitoringOS__OclAny /* 0 */,
				Fragments._MonitoringOS__OclElement /* 1 */,
				Fragments._MonitoringOS__Name /* 2 */,
				Fragments._MonitoringOS__MonitoringOS /* 3 */
			};
		private static final int /*@NonNull*/ [] __MonitoringOS = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Name =
			{
				Fragments._Name__OclAny /* 0 */,
				Fragments._Name__OclElement /* 1 */,
				Fragments._Name__Name /* 2 */
			};
		private static final int /*@NonNull*/ [] __Name = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _typelight =
			{
				Fragments._typelight__OclAny /* 0 */,
				Fragments._typelight__OclElement /* 1 */,
				Fragments._typelight__OclType /* 2 */,
				Fragments._typelight__OclEnumeration /* 3 */,
				Fragments._typelight__typelight /* 4 */
			};
		private static final int /*@NonNull*/ [] __typelight = { 1,1,1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._Camera.initFragments(_Camera, __Camera);
			Types._Crate.initFragments(_Crate, __Crate);
			Types._CrateSensors.initFragments(_CrateSensors, __CrateSensors);
			Types._Crateid.initFragments(_Crateid, __Crateid);
			Types._Crop.initFragments(_Crop, __Crop);
			Types._CropType.initFragments(_CropType, __CropType);
			Types._Drone.initFragments(_Drone, __Drone);
			Types._Farm.initFragments(_Farm, __Farm);
			Types._FocusArea.initFragments(_FocusArea, __FocusArea);
			Types._Light.initFragments(_Light, __Light);
			Types._MonitoringOS.initFragments(_MonitoringOS, __MonitoringOS);
			Types._Name.initFragments(_Name, __Name);
			Types._typelight.initFragments(_typelight, __typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _Camera__Camera = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crate__Crate = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__Crateid = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _CrateSensors__CrateSensors = {
			SmartFarming2Tables.Operations._CrateSensors__arePlantsAlive /* arePlantsAlive() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CrateSensors__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CrateSensors__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__Crateid = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crop__Crop = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crop__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crop__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _CropType__CropType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Drone__Drone = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Farm__Farm = {
			SmartFarming2Tables.Operations._Farm__isSpaceaAvailable /* isSpaceaAvailable() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__FocusArea = {};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Light__Light = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _MonitoringOS__MonitoringOS = {};
		private static final ExecutorOperation /*@NonNull*/ [] _MonitoringOS__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _MonitoringOS__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MonitoringOS__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Name__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Name__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Name__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _typelight__typelight = {};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Camera__Camera.initOperations(_Camera__Camera);
			Fragments._Camera__Name.initOperations(_Camera__Name);
			Fragments._Camera__OclAny.initOperations(_Camera__OclAny);
			Fragments._Camera__OclElement.initOperations(_Camera__OclElement);

			Fragments._Crate__Crate.initOperations(_Crate__Crate);
			Fragments._Crate__Crateid.initOperations(_Crate__Crateid);
			Fragments._Crate__OclAny.initOperations(_Crate__OclAny);
			Fragments._Crate__OclElement.initOperations(_Crate__OclElement);

			Fragments._CrateSensors__CrateSensors.initOperations(_CrateSensors__CrateSensors);
			Fragments._CrateSensors__OclAny.initOperations(_CrateSensors__OclAny);
			Fragments._CrateSensors__OclElement.initOperations(_CrateSensors__OclElement);

			Fragments._Crateid__Crateid.initOperations(_Crateid__Crateid);
			Fragments._Crateid__OclAny.initOperations(_Crateid__OclAny);
			Fragments._Crateid__OclElement.initOperations(_Crateid__OclElement);

			Fragments._Crop__Crop.initOperations(_Crop__Crop);
			Fragments._Crop__OclAny.initOperations(_Crop__OclAny);
			Fragments._Crop__OclElement.initOperations(_Crop__OclElement);

			Fragments._CropType__CropType.initOperations(_CropType__CropType);
			Fragments._CropType__OclAny.initOperations(_CropType__OclAny);
			Fragments._CropType__OclElement.initOperations(_CropType__OclElement);
			Fragments._CropType__OclEnumeration.initOperations(_CropType__OclEnumeration);
			Fragments._CropType__OclType.initOperations(_CropType__OclType);

			Fragments._Drone__Drone.initOperations(_Drone__Drone);
			Fragments._Drone__Name.initOperations(_Drone__Name);
			Fragments._Drone__OclAny.initOperations(_Drone__OclAny);
			Fragments._Drone__OclElement.initOperations(_Drone__OclElement);

			Fragments._Farm__Farm.initOperations(_Farm__Farm);
			Fragments._Farm__Name.initOperations(_Farm__Name);
			Fragments._Farm__OclAny.initOperations(_Farm__OclAny);
			Fragments._Farm__OclElement.initOperations(_Farm__OclElement);

			Fragments._FocusArea__FocusArea.initOperations(_FocusArea__FocusArea);
			Fragments._FocusArea__OclAny.initOperations(_FocusArea__OclAny);
			Fragments._FocusArea__OclElement.initOperations(_FocusArea__OclElement);
			Fragments._FocusArea__OclEnumeration.initOperations(_FocusArea__OclEnumeration);
			Fragments._FocusArea__OclType.initOperations(_FocusArea__OclType);

			Fragments._Light__Light.initOperations(_Light__Light);
			Fragments._Light__Name.initOperations(_Light__Name);
			Fragments._Light__OclAny.initOperations(_Light__OclAny);
			Fragments._Light__OclElement.initOperations(_Light__OclElement);

			Fragments._MonitoringOS__MonitoringOS.initOperations(_MonitoringOS__MonitoringOS);
			Fragments._MonitoringOS__Name.initOperations(_MonitoringOS__Name);
			Fragments._MonitoringOS__OclAny.initOperations(_MonitoringOS__OclAny);
			Fragments._MonitoringOS__OclElement.initOperations(_MonitoringOS__OclElement);

			Fragments._Name__Name.initOperations(_Name__Name);
			Fragments._Name__OclAny.initOperations(_Name__OclAny);
			Fragments._Name__OclElement.initOperations(_Name__OclElement);

			Fragments._typelight__OclAny.initOperations(_typelight__OclAny);
			Fragments._typelight__OclElement.initOperations(_typelight__OclElement);
			Fragments._typelight__OclEnumeration.initOperations(_typelight__OclEnumeration);
			Fragments._typelight__OclType.initOperations(_typelight__OclType);
			Fragments._typelight__typelight.initOperations(_typelight__typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _Camera = {
			SmartFarming2Tables.Properties._Camera__CameraFocus,
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crate = {
			SmartFarming2Tables.Properties._Crate__CropType,
			SmartFarming2Tables.Properties._Crateid__id,
			SmartFarming2Tables.Properties._Crate__light,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			SmartFarming2Tables.Properties._Crate__sensors,
			SmartFarming2Tables.Properties._Crate__workingCameras,
			SmartFarming2Tables.Properties._Crate__workingDrones,
			SmartFarming2Tables.Properties._Crate__workingOS
		};

		private static final ExecutorProperty /*@NonNull*/ [] _CrateSensors = {
			SmartFarming2Tables.Properties._CrateSensors__CrateTemperature,
			SmartFarming2Tables.Properties._CrateSensors__HumidityValueInPercentage,
			SmartFarming2Tables.Properties._CrateSensors__PlantTemperature,
			SmartFarming2Tables.Properties._CrateSensors__SoilMoistureInPercentage,
			SmartFarming2Tables.Properties._CrateSensors__TemperatureinDegreeCelcius,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			SmartFarming2Tables.Properties._CrateSensors__ph
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crateid = {
			SmartFarming2Tables.Properties._Crateid__id,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crop = {
			SmartFarming2Tables.Properties._Crop__Crop,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _CropType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Drone = {
			SmartFarming2Tables.Properties._Drone__DroneMonitoring,
			SmartFarming2Tables.Properties._Drone__TurnOn,
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Farm = {
			SmartFarming2Tables.Properties._Farm__MaxCrates,
			SmartFarming2Tables.Properties._Farm__camera,
			SmartFarming2Tables.Properties._Farm__crate,
			SmartFarming2Tables.Properties._Farm__drone,
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			SmartFarming2Tables.Properties._Farm__os
		};

		private static final ExecutorProperty /*@NonNull*/ [] _FocusArea = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Light = {
			SmartFarming2Tables.Properties._Light__TurnOn,
			SmartFarming2Tables.Properties._Light__TypeLight,
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _MonitoringOS = {
			SmartFarming2Tables.Properties._MonitoringOS__OSfocusArea,
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Name = {
			SmartFarming2Tables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _typelight = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Camera__Camera.initProperties(_Camera);
			Fragments._Crate__Crate.initProperties(_Crate);
			Fragments._CrateSensors__CrateSensors.initProperties(_CrateSensors);
			Fragments._Crateid__Crateid.initProperties(_Crateid);
			Fragments._Crop__Crop.initProperties(_Crop);
			Fragments._CropType__CropType.initProperties(_CropType);
			Fragments._Drone__Drone.initProperties(_Drone);
			Fragments._Farm__Farm.initProperties(_Farm);
			Fragments._FocusArea__FocusArea.initProperties(_FocusArea);
			Fragments._Light__Light.initProperties(_Light);
			Fragments._MonitoringOS__MonitoringOS.initProperties(_MonitoringOS);
			Fragments._Name__Name.initProperties(_Name);
			Fragments._typelight__typelight.initProperties(_typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _CropType__Tomato = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.CROP_TYPE.getEEnumLiteral("Tomato"), Types._CropType, 0);
		public static final EcoreExecutorEnumerationLiteral _CropType__Cabbage = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.CROP_TYPE.getEEnumLiteral("Cabbage"), Types._CropType, 1);
		public static final EcoreExecutorEnumerationLiteral _CropType__Potato = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.CROP_TYPE.getEEnumLiteral("Potato"), Types._CropType, 2);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _CropType = {
			_CropType__Tomato,
			_CropType__Cabbage,
			_CropType__Potato
		};

		public static final EcoreExecutorEnumerationLiteral _FocusArea__Crates = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.FOCUS_AREA.getEEnumLiteral("Crates"), Types._FocusArea, 0);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Plants = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.FOCUS_AREA.getEEnumLiteral("Plants"), Types._FocusArea, 1);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Cameras = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.FOCUS_AREA.getEEnumLiteral("Cameras"), Types._FocusArea, 2);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Drones = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.FOCUS_AREA.getEEnumLiteral("Drones"), Types._FocusArea, 3);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Sensors = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.FOCUS_AREA.getEEnumLiteral("Sensors"), Types._FocusArea, 4);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _FocusArea = {
			_FocusArea__Crates,
			_FocusArea__Plants,
			_FocusArea__Cameras,
			_FocusArea__Drones,
			_FocusArea__Sensors
		};

		public static final EcoreExecutorEnumerationLiteral _typelight__UVlight = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.TYPELIGHT.getEEnumLiteral("UVlight"), Types._typelight, 0);
		public static final EcoreExecutorEnumerationLiteral _typelight__BlueLight = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.TYPELIGHT.getEEnumLiteral("BlueLight"), Types._typelight, 1);
		public static final EcoreExecutorEnumerationLiteral _typelight__RedLight = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.TYPELIGHT.getEEnumLiteral("RedLight"), Types._typelight, 2);
		public static final EcoreExecutorEnumerationLiteral _typelight__GreenLight = new EcoreExecutorEnumerationLiteral(SmartFarming2Package.Literals.TYPELIGHT.getEEnumLiteral("GreenLight"), Types._typelight, 3);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _typelight = {
			_typelight__UVlight,
			_typelight__BlueLight,
			_typelight__RedLight,
			_typelight__GreenLight
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._CropType.initLiterals(_CropType);
			Types._FocusArea.initLiterals(_FocusArea);
			Types._typelight.initLiterals(_typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarming2Tables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new SmartFarming2Tables();
	}

	private SmartFarming2Tables() {
		super(SmartFarming2Package.eNS_URI);
	}

	/*
	 * The EClasses whose instances should be cached to support allInstances().
	 */
	private static final EClass allInstancesEClasses /*@NonNull*/ [] = {
		SmartFarming2Package.Literals.CAMERA,
		SmartFarming2Package.Literals.DRONE,
		SmartFarming2Package.Literals.MONITORING_OS
	};

	@Override
	public EClass /*@NonNull*/ [] basicGetAllInstancesClasses() {
		return allInstancesEClasses;
	}
}
