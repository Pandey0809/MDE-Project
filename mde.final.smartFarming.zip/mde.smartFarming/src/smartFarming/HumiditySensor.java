/**
 */
package smartFarming;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Humidity Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.HumiditySensor#getHumidityValue <em>Humidity Value</em>}</li>
 *   <li>{@link smartFarming.HumiditySensor#isTurnOn <em>Turn On</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getHumiditySensor()
 * @model
 * @generated
 */
public interface HumiditySensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Humidity Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Humidity Value</em>' attribute.
	 * @see #setHumidityValue(float)
	 * @see smartFarming.SmartFarmingPackage#getHumiditySensor_HumidityValue()
	 * @model
	 * @generated
	 */
	float getHumidityValue();

	/**
	 * Sets the value of the '{@link smartFarming.HumiditySensor#getHumidityValue <em>Humidity Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Humidity Value</em>' attribute.
	 * @see #getHumidityValue()
	 * @generated
	 */
	void setHumidityValue(float value);

	/**
	 * Returns the value of the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Turn On</em>' attribute.
	 * @see #setTurnOn(boolean)
	 * @see smartFarming.SmartFarmingPackage#getHumiditySensor_TurnOn()
	 * @model
	 * @generated
	 */
	boolean isTurnOn();

	/**
	 * Sets the value of the '{@link smartFarming.HumiditySensor#isTurnOn <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Turn On</em>' attribute.
	 * @see #isTurnOn()
	 * @generated
	 */
	void setTurnOn(boolean value);

} // HumiditySensor
