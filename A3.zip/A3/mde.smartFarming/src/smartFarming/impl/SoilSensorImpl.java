/**
 */
package smartFarming.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Map;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.oclany.OclComparableGreaterThanEqualOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;

import smartFarming.SmartFarmingPackage;
import smartFarming.SmartFarmingTables;
import smartFarming.SoilSensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Soil Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.SoilSensorImpl#getPh <em>Ph</em>}</li>
 *   <li>{@link smartFarming.impl.SoilSensorImpl#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SoilSensorImpl extends MinimalEObjectImpl.Container implements SoilSensor {
	/**
	 * The default value of the '{@link #getPh() <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPh()
	 * @generated
	 * @ordered
	 */
	protected static final int PH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPh() <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPh()
	 * @generated
	 * @ordered
	 */
	protected int ph = PH_EDEFAULT;

	/**
	 * The default value of the '{@link #getSoilMoistureInPercentage() <em>Soil Moisture In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoilMoistureInPercentage()
	 * @generated
	 * @ordered
	 */
	protected static final int SOIL_MOISTURE_IN_PERCENTAGE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSoilMoistureInPercentage() <em>Soil Moisture In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoilMoistureInPercentage()
	 * @generated
	 * @ordered
	 */
	protected int soilMoistureInPercentage = SOIL_MOISTURE_IN_PERCENTAGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SoilSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.SOIL_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPh() {
		return ph;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPh(int newPh) {
		int oldPh = ph;
		ph = newPh;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.SOIL_SENSOR__PH, oldPh, ph));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSoilMoistureInPercentage() {
		return soilMoistureInPercentage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSoilMoistureInPercentage(int newSoilMoistureInPercentage) {
		int oldSoilMoistureInPercentage = soilMoistureInPercentage;
		soilMoistureInPercentage = newSoilMoistureInPercentage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE, oldSoilMoistureInPercentage, soilMoistureInPercentage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSoiltooAcidic(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "SoilSensor::isSoiltooAcidic";
		try {
			/**
			 *
			 * inv isSoiltooAcidic:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.ph >= 4
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.SOIL_SENSOR___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ int ph = this.getPh();
				final /*@NonInvalid*/ IntegerValue BOXED_ph = ValueUtil.integerValueOf(ph);
				final /*@NonInvalid*/ boolean result = OclComparableGreaterThanEqualOperation.INSTANCE.evaluate(executor, BOXED_ph, SmartFarmingTables.INT_4).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSoiltooBasic(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "SoilSensor::isSoiltooBasic";
		try {
			/**
			 *
			 * inv isSoiltooBasic:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.ph <= 10
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.SOIL_SENSOR___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ int ph = this.getPh();
				final /*@NonInvalid*/ IntegerValue BOXED_ph = ValueUtil.integerValueOf(ph);
				final /*@NonInvalid*/ boolean result = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, BOXED_ph, SmartFarmingTables.INT_10).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				return getPh();
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE:
				return getSoilMoistureInPercentage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				setPh((Integer)newValue);
				return;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE:
				setSoilMoistureInPercentage((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				setPh(PH_EDEFAULT);
				return;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE:
				setSoilMoistureInPercentage(SOIL_MOISTURE_IN_PERCENTAGE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				return ph != PH_EDEFAULT;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE:
				return soilMoistureInPercentage != SOIL_MOISTURE_IN_PERCENTAGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SmartFarmingPackage.SOIL_SENSOR___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP:
				return isSoiltooAcidic((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
			case SmartFarmingPackage.SOIL_SENSOR___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP:
				return isSoiltooBasic((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ph: ");
		result.append(ph);
		result.append(", SoilMoistureInPercentage: ");
		result.append(soilMoistureInPercentage);
		result.append(')');
		return result.toString();
	}

} //SoilSensorImpl
