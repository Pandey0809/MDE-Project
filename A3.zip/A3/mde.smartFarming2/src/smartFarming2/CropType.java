/**
 */
package smartFarming2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Crop Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see smartFarming2.SmartFarming2Package#getCropType()
 * @model
 * @generated
 */
public enum CropType implements Enumerator {
	/**
	 * The '<em><b>Tomato</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TOMATO_VALUE
	 * @generated
	 * @ordered
	 */
	TOMATO(1, "Tomato", "Tomato"),

	/**
	 * The '<em><b>Cabbage</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CABBAGE_VALUE
	 * @generated
	 * @ordered
	 */
	CABBAGE(2, "Cabbage", "Cabbage"),

	/**
	 * The '<em><b>Potato</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #POTATO_VALUE
	 * @generated
	 * @ordered
	 */
	POTATO(3, "Potato", "Potato");

	/**
	 * The '<em><b>Tomato</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TOMATO
	 * @model name="Tomato"
	 * @generated
	 * @ordered
	 */
	public static final int TOMATO_VALUE = 1;

	/**
	 * The '<em><b>Cabbage</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CABBAGE
	 * @model name="Cabbage"
	 * @generated
	 * @ordered
	 */
	public static final int CABBAGE_VALUE = 2;

	/**
	 * The '<em><b>Potato</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #POTATO
	 * @model name="Potato"
	 * @generated
	 * @ordered
	 */
	public static final int POTATO_VALUE = 3;

	/**
	 * An array of all the '<em><b>Crop Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final CropType[] VALUES_ARRAY =
		new CropType[] {
			TOMATO,
			CABBAGE,
			POTATO,
		};

	/**
	 * A public read-only list of all the '<em><b>Crop Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<CropType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Crop Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CropType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CropType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Crop Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CropType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CropType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Crop Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static CropType get(int value) {
		switch (value) {
			case TOMATO_VALUE: return TOMATO;
			case CABBAGE_VALUE: return CABBAGE;
			case POTATO_VALUE: return POTATO;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private CropType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //CropType
