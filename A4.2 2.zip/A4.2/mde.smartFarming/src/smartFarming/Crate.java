/**
 */
package smartFarming;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Crate#getLight <em>Light</em>}</li>
 *   <li>{@link smartFarming.Crate#getHumiditysensor <em>Humiditysensor</em>}</li>
 *   <li>{@link smartFarming.Crate#getTemperaturesensor <em>Temperaturesensor</em>}</li>
 *   <li>{@link smartFarming.Crate#getSoilsenor <em>Soilsenor</em>}</li>
 *   <li>{@link smartFarming.Crate#getSelectcrop <em>Selectcrop</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getCrate()
 * @model
 * @generated
 */
public interface Crate extends Crateid {
	/**
	 * Returns the value of the '<em><b>Light</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Light}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Light</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getCrate_Light()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Light> getLight();

	/**
	 * Returns the value of the '<em><b>Humiditysensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Humiditysensor</em>' containment reference.
	 * @see #setHumiditysensor(HumiditySensor)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Humiditysensor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	HumiditySensor getHumiditysensor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getHumiditysensor <em>Humiditysensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Humiditysensor</em>' containment reference.
	 * @see #getHumiditysensor()
	 * @generated
	 */
	void setHumiditysensor(HumiditySensor value);

	/**
	 * Returns the value of the '<em><b>Temperaturesensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperaturesensor</em>' containment reference.
	 * @see #setTemperaturesensor(TemperatureSensosor)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Temperaturesensor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	TemperatureSensosor getTemperaturesensor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getTemperaturesensor <em>Temperaturesensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperaturesensor</em>' containment reference.
	 * @see #getTemperaturesensor()
	 * @generated
	 */
	void setTemperaturesensor(TemperatureSensosor value);

	/**
	 * Returns the value of the '<em><b>Soilsenor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soilsenor</em>' containment reference.
	 * @see #setSoilsenor(SoilSensor)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Soilsenor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	SoilSensor getSoilsenor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getSoilsenor <em>Soilsenor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Soilsenor</em>' containment reference.
	 * @see #getSoilsenor()
	 * @generated
	 */
	void setSoilsenor(SoilSensor value);

	/**
	 * Returns the value of the '<em><b>Selectcrop</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Selectcrop</em>' containment reference.
	 * @see #setSelectcrop(Crop)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Selectcrop()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Crop getSelectcrop();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getSelectcrop <em>Selectcrop</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Selectcrop</em>' containment reference.
	 * @see #getSelectcrop()
	 * @generated
	 */
	void setSelectcrop(Crop value);

} // Crate
