/**
 */
package smartFarming;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Temperature Sensosor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.TemperatureSensosor#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}</li>
 *   <li>{@link smartFarming.TemperatureSensosor#getCrateTemperature <em>Crate Temperature</em>}</li>
 *   <li>{@link smartFarming.TemperatureSensosor#getPlantTemperature <em>Plant Temperature</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosor()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='arePlantsAlive'"
 * @generated
 */
public interface TemperatureSensosor extends EObject {
	/**
	 * Returns the value of the '<em><b>Temperaturein Degree Celcius</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #setTemperatureinDegreeCelcius(boolean)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosor_TemperatureinDegreeCelcius()
	 * @model required="true"
	 * @generated
	 */
	boolean isTemperatureinDegreeCelcius();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosor#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 */
	void setTemperatureinDegreeCelcius(boolean value);

	/**
	 * Returns the value of the '<em><b>Crate Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crate Temperature</em>' attribute.
	 * @see #setCrateTemperature(float)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosor_CrateTemperature()
	 * @model required="true"
	 * @generated
	 */
	float getCrateTemperature();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosor#getCrateTemperature <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crate Temperature</em>' attribute.
	 * @see #getCrateTemperature()
	 * @generated
	 */
	void setCrateTemperature(float value);

	/**
	 * Returns the value of the '<em><b>Plant Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plant Temperature</em>' attribute.
	 * @see #setPlantTemperature(float)
	 * @see smartFarming.SmartFarmingPackage#getTemperatureSensosor_PlantTemperature()
	 * @model required="true"
	 * @generated
	 */
	float getPlantTemperature();

	/**
	 * Sets the value of the '{@link smartFarming.TemperatureSensosor#getPlantTemperature <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Plant Temperature</em>' attribute.
	 * @see #getPlantTemperature()
	 * @generated
	 */
	void setPlantTemperature(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='self.PlantTemperature&lt;=26'"
	 * @generated
	 */
	Boolean arePlantsAlive();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.CrateTemperature&gt;=self.PlantTemperature'"
	 * @generated
	 */
	boolean arePlantsAlive(DiagnosticChain diagnostics, Map<Object, Object> context);

} // TemperatureSensosor
