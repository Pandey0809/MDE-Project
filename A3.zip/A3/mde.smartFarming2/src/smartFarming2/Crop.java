/**
 */
package smartFarming2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crop</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.Crop#getCrop <em>Crop</em>}</li>
 * </ul>
 *
 * @see smartFarming2.SmartFarming2Package#getCrop()
 * @model
 * @generated
 */
public interface Crop extends EObject {
	/**
	 * Returns the value of the '<em><b>Crop</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming2.CropType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crop</em>' attribute.
	 * @see smartFarming2.CropType
	 * @see #setCrop(CropType)
	 * @see smartFarming2.SmartFarming2Package#getCrop_Crop()
	 * @model
	 * @generated
	 */
	CropType getCrop();

	/**
	 * Sets the value of the '{@link smartFarming2.Crop#getCrop <em>Crop</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crop</em>' attribute.
	 * @see smartFarming2.CropType
	 * @see #getCrop()
	 * @generated
	 */
	void setCrop(CropType value);

} // Crop
