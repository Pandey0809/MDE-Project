/**
 */
package smartFarming;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AI</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.AI#getAIfocus <em>AIfocus</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getAI()
 * @model
 * @generated
 */
public interface AI extends Name {
	/**
	 * Returns the value of the '<em><b>AIfocus</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming.FocusArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>AIfocus</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #setAIfocus(FocusArea)
	 * @see smartFarming.SmartFarmingPackage#getAI_AIfocus()
	 * @model
	 * @generated
	 */
	FocusArea getAIfocus();

	/**
	 * Sets the value of the '{@link smartFarming.AI#getAIfocus <em>AIfocus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>AIfocus</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #getAIfocus()
	 * @generated
	 */
	void setAIfocus(FocusArea value);

} // AI
