/**
 */
package smartFarming2;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crate Sensors</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.CrateSensors#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}</li>
 *   <li>{@link smartFarming2.CrateSensors#getCrateTemperature <em>Crate Temperature</em>}</li>
 *   <li>{@link smartFarming2.CrateSensors#getPlantTemperature <em>Plant Temperature</em>}</li>
 *   <li>{@link smartFarming2.CrateSensors#getPh <em>Ph</em>}</li>
 *   <li>{@link smartFarming2.CrateSensors#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}</li>
 *   <li>{@link smartFarming2.CrateSensors#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}</li>
 * </ul>
 *
 * @see smartFarming2.SmartFarming2Package#getCrateSensors()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='arePlantsAlive'"
 * @generated
 */
public interface CrateSensors extends EObject {
	/**
	 * Returns the value of the '<em><b>Temperaturein Degree Celcius</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #setTemperatureinDegreeCelcius(boolean)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_TemperatureinDegreeCelcius()
	 * @model required="true"
	 * @generated
	 */
	boolean isTemperatureinDegreeCelcius();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperaturein Degree Celcius</em>' attribute.
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 */
	void setTemperatureinDegreeCelcius(boolean value);

	/**
	 * Returns the value of the '<em><b>Crate Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crate Temperature</em>' attribute.
	 * @see #setCrateTemperature(float)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_CrateTemperature()
	 * @model required="true"
	 * @generated
	 */
	float getCrateTemperature();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#getCrateTemperature <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crate Temperature</em>' attribute.
	 * @see #getCrateTemperature()
	 * @generated
	 */
	void setCrateTemperature(float value);

	/**
	 * Returns the value of the '<em><b>Plant Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plant Temperature</em>' attribute.
	 * @see #setPlantTemperature(float)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_PlantTemperature()
	 * @model required="true"
	 * @generated
	 */
	float getPlantTemperature();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#getPlantTemperature <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Plant Temperature</em>' attribute.
	 * @see #getPlantTemperature()
	 * @generated
	 */
	void setPlantTemperature(float value);

	/**
	 * Returns the value of the '<em><b>Ph</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ph</em>' attribute.
	 * @see #setPh(int)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_Ph()
	 * @model required="true"
	 * @generated
	 */
	int getPh();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#getPh <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ph</em>' attribute.
	 * @see #getPh()
	 * @generated
	 */
	void setPh(int value);

	/**
	 * Returns the value of the '<em><b>Soil Moisture In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soil Moisture In Percentage</em>' attribute.
	 * @see #setSoilMoistureInPercentage(int)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_SoilMoistureInPercentage()
	 * @model required="true"
	 * @generated
	 */
	int getSoilMoistureInPercentage();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Soil Moisture In Percentage</em>' attribute.
	 * @see #getSoilMoistureInPercentage()
	 * @generated
	 */
	void setSoilMoistureInPercentage(int value);

	/**
	 * Returns the value of the '<em><b>Humidity Value In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Humidity Value In Percentage</em>' attribute.
	 * @see #setHumidityValueInPercentage(float)
	 * @see smartFarming2.SmartFarming2Package#getCrateSensors_HumidityValueInPercentage()
	 * @model
	 * @generated
	 */
	float getHumidityValueInPercentage();

	/**
	 * Sets the value of the '{@link smartFarming2.CrateSensors#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Humidity Value In Percentage</em>' attribute.
	 * @see #getHumidityValueInPercentage()
	 * @generated
	 */
	void setHumidityValueInPercentage(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='self.PlantTemperature&lt;=26'"
	 * @generated
	 */
	Boolean arePlantsAlive();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.ph&lt;=10'"
	 * @generated
	 */
	boolean isSoiltooBasic(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.HumidityValueInPercentage&gt;=50'"
	 * @generated
	 */
	boolean isHumiditytooless(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.HumidityValueInPercentage&lt;=90'"
	 * @generated
	 */
	boolean isHumiditytoomuch(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.ph&gt;=4'"
	 * @generated
	 */
	boolean isSoiltooAcidic(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.CrateTemperature&gt;=self.PlantTemperature'"
	 * @generated
	 */
	boolean arePlantsAlive(DiagnosticChain diagnostics, Map<Object, Object> context);

} // CrateSensors
