/**
 */
package smartFarming.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import smartFarming.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SmartFarmingFactoryImpl extends EFactoryImpl implements SmartFarmingFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SmartFarmingFactory init() {
		try {
			SmartFarmingFactory theSmartFarmingFactory = (SmartFarmingFactory)EPackage.Registry.INSTANCE.getEFactory(SmartFarmingPackage.eNS_URI);
			if (theSmartFarmingFactory != null) {
				return theSmartFarmingFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SmartFarmingFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarmingFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case SmartFarmingPackage.FARM: return createFarm();
			case SmartFarmingPackage.CRATE: return createCrate();
			case SmartFarmingPackage.DRONE: return createDrone();
			case SmartFarmingPackage.CAMERA: return createCamera();
			case SmartFarmingPackage.AI: return createAI();
			case SmartFarmingPackage.TEMPERATURE_SENSOSR: return createTemperatureSensosr();
			case SmartFarmingPackage.SOIL_SENSOR: return createSoilSensor();
			case SmartFarmingPackage.HUMIDITY_SENSOR: return createHumiditySensor();
			case SmartFarmingPackage.LIGHT: return createLight();
			case SmartFarmingPackage.NAME: return createName();
			case SmartFarmingPackage.CROP: return createCrop();
			case SmartFarmingPackage.CRATEID: return createCrateid();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case SmartFarmingPackage.TYPELIGHT:
				return createtypelightFromString(eDataType, initialValue);
			case SmartFarmingPackage.FOCUS_AREA:
				return createFocusAreaFromString(eDataType, initialValue);
			case SmartFarmingPackage.CROP_TYPE:
				return createCropTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case SmartFarmingPackage.TYPELIGHT:
				return converttypelightToString(eDataType, instanceValue);
			case SmartFarmingPackage.FOCUS_AREA:
				return convertFocusAreaToString(eDataType, instanceValue);
			case SmartFarmingPackage.CROP_TYPE:
				return convertCropTypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Farm createFarm() {
		FarmImpl farm = new FarmImpl();
		return farm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Crate createCrate() {
		CrateImpl crate = new CrateImpl();
		return crate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Drone createDrone() {
		DroneImpl drone = new DroneImpl();
		return drone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Camera createCamera() {
		CameraImpl camera = new CameraImpl();
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AI createAI() {
		AIImpl ai = new AIImpl();
		return ai;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TemperatureSensosr createTemperatureSensosr() {
		TemperatureSensosrImpl temperatureSensosr = new TemperatureSensosrImpl();
		return temperatureSensosr;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SoilSensor createSoilSensor() {
		SoilSensorImpl soilSensor = new SoilSensorImpl();
		return soilSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HumiditySensor createHumiditySensor() {
		HumiditySensorImpl humiditySensor = new HumiditySensorImpl();
		return humiditySensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Light createLight() {
		LightImpl light = new LightImpl();
		return light;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Name createName() {
		NameImpl name = new NameImpl();
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Crop createCrop() {
		CropImpl crop = new CropImpl();
		return crop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Crateid createCrateid() {
		CrateidImpl crateid = new CrateidImpl();
		return crateid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public typelight createtypelightFromString(EDataType eDataType, String initialValue) {
		typelight result = typelight.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String converttypelightToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea createFocusAreaFromString(EDataType eDataType, String initialValue) {
		FocusArea result = FocusArea.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertFocusAreaToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CropType createCropTypeFromString(EDataType eDataType, String initialValue) {
		CropType result = CropType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCropTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarmingPackage getSmartFarmingPackage() {
		return (SmartFarmingPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SmartFarmingPackage getPackage() {
		return SmartFarmingPackage.eINSTANCE;
	}

} //SmartFarmingFactoryImpl
