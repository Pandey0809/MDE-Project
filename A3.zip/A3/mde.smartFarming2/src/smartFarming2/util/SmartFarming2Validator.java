/**
 */
package smartFarming2.util;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import smartFarming2.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see smartFarming2.SmartFarming2Package
 * @generated
 */
public class SmartFarming2Validator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final SmartFarming2Validator INSTANCE = new SmartFarming2Validator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "smartFarming2";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Sufficient Space' of 'Farm'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int FARM__SUFFICIENT_SPACE = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Soiltoo Basic' of 'Crate Sensors'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CRATE_SENSORS__IS_SOILTOO_BASIC = 2;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Humiditytooless' of 'Crate Sensors'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CRATE_SENSORS__IS_HUMIDITYTOOLESS = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Humiditytoomuch' of 'Crate Sensors'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CRATE_SENSORS__IS_HUMIDITYTOOMUCH = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Soiltoo Acidic' of 'Crate Sensors'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CRATE_SENSORS__IS_SOILTOO_ACIDIC = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Are Plants Alive' of 'Crate Sensors'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int CRATE_SENSORS__ARE_PLANTS_ALIVE = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarming2Validator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return SmartFarming2Package.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case SmartFarming2Package.FARM:
				return validateFarm((Farm)value, diagnostics, context);
			case SmartFarming2Package.CRATE:
				return validateCrate((Crate)value, diagnostics, context);
			case SmartFarming2Package.DRONE:
				return validateDrone((Drone)value, diagnostics, context);
			case SmartFarming2Package.CAMERA:
				return validateCamera((Camera)value, diagnostics, context);
			case SmartFarming2Package.MONITORING_OS:
				return validateMonitoringOS((MonitoringOS)value, diagnostics, context);
			case SmartFarming2Package.CRATE_SENSORS:
				return validateCrateSensors((CrateSensors)value, diagnostics, context);
			case SmartFarming2Package.LIGHT:
				return validateLight((Light)value, diagnostics, context);
			case SmartFarming2Package.NAME:
				return validateName((Name)value, diagnostics, context);
			case SmartFarming2Package.CROP:
				return validateCrop((Crop)value, diagnostics, context);
			case SmartFarming2Package.CRATEID:
				return validateCrateid((Crateid)value, diagnostics, context);
			case SmartFarming2Package.TYPELIGHT:
				return validatetypelight((typelight)value, diagnostics, context);
			case SmartFarming2Package.FOCUS_AREA:
				return validateFocusArea((FocusArea)value, diagnostics, context);
			case SmartFarming2Package.CROP_TYPE:
				return validateCropType((CropType)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFarm(Farm farm, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(farm, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validateFarm_SufficientSpace(farm, diagnostics, context);
		return result;
	}

	/**
	 * Validates the SufficientSpace constraint of '<em>Farm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFarm_SufficientSpace(Farm farm, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return farm.SufficientSpace(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrate(Crate crate, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crate, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDrone(Drone drone, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(drone, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCamera(Camera camera, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(camera, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMonitoringOS(MonitoringOS monitoringOS, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(monitoringOS, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(crateSensors, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validateCrateSensors_arePlantsAlive(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validateCrateSensors_isSoiltooBasic(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validateCrateSensors_isHumiditytooless(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validateCrateSensors_isHumiditytoomuch(crateSensors, diagnostics, context);
		if (result || diagnostics != null) result &= validateCrateSensors_isSoiltooAcidic(crateSensors, diagnostics, context);
		return result;
	}

	/**
	 * Validates the arePlantsAlive constraint of '<em>Crate Sensors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors_arePlantsAlive(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return crateSensors.arePlantsAlive(diagnostics, context);
	}

	/**
	 * Validates the isSoiltooBasic constraint of '<em>Crate Sensors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors_isSoiltooBasic(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return crateSensors.isSoiltooBasic(diagnostics, context);
	}

	/**
	 * Validates the isHumiditytooless constraint of '<em>Crate Sensors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors_isHumiditytooless(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return crateSensors.isHumiditytooless(diagnostics, context);
	}

	/**
	 * Validates the isHumiditytoomuch constraint of '<em>Crate Sensors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors_isHumiditytoomuch(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return crateSensors.isHumiditytoomuch(diagnostics, context);
	}

	/**
	 * Validates the isSoiltooAcidic constraint of '<em>Crate Sensors</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateSensors_isSoiltooAcidic(CrateSensors crateSensors, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return crateSensors.isSoiltooAcidic(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLight(Light light, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(light, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateName(Name name, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(name, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrop(Crop crop, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crop, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateid(Crateid crateid, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crateid, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetypelight(typelight typelight, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFocusArea(FocusArea focusArea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCropType(CropType cropType, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //SmartFarming2Validator
