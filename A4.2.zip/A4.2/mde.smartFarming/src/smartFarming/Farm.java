/**
 */
package smartFarming;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Farm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Farm#getCrate <em>Crate</em>}</li>
 *   <li>{@link smartFarming.Farm#getDrone <em>Drone</em>}</li>
 *   <li>{@link smartFarming.Farm#getCamera <em>Camera</em>}</li>
 *   <li>{@link smartFarming.Farm#getAi <em>Ai</em>}</li>
 *   <li>{@link smartFarming.Farm#getMaxCrates <em>Max Crates</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getFarm()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='SufficientSpace'"
 * @generated
 */
public interface Farm extends Name {
	/**
	 * Returns the value of the '<em><b>Crate</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Crate}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crate</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Crate()
	 * @model containment="true"
	 * @generated
	 */
	EList<Crate> getCrate();

	/**
	 * Returns the value of the '<em><b>Drone</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Drone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drone</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Drone()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Drone> getDrone();

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Camera}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Camera()
	 * @model containment="true"
	 * @generated
	 */
	EList<Camera> getCamera();

	/**
	 * Returns the value of the '<em><b>Ai</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.AI}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ai</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getFarm_Ai()
	 * @model containment="true"
	 * @generated
	 */
	EList<AI> getAi();

	/**
	 * Returns the value of the '<em><b>Max Crates</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Crates</em>' attribute.
	 * @see #setMaxCrates(int)
	 * @see smartFarming.SmartFarmingPackage#getFarm_MaxCrates()
	 * @model required="true"
	 * @generated
	 */
	int getMaxCrates();

	/**
	 * Sets the value of the '{@link smartFarming.Farm#getMaxCrates <em>Max Crates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Crates</em>' attribute.
	 * @see #getMaxCrates()
	 * @generated
	 */
	void setMaxCrates(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body=' self.MaxCrates&gt;=crate-&gt;size()'"
	 * @generated
	 */
	Boolean isSpaceaAvailable();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.MaxCrates&gt;=crate-&gt;size()'"
	 * @generated
	 */
	boolean SufficientSpace(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Farm
