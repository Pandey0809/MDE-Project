package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'E'", "'e'", "'UVlight'", "'BlueLight'", "'RedLight'", "'GreenLight'", "'Tomato'", "'Cabbage'", "'Potato'", "'Crates'", "'Plants'", "'Cameras'", "'Drones'", "'Sensors'", "'Farm'", "'{'", "'MaxCrates'", "'drone'", "'}'", "'crate'", "','", "'camera'", "'ai'", "'Crate'", "'light'", "'humiditysensor'", "'temperaturesensor'", "'soilsenor'", "'cropType'", "'id'", "'Drone'", "'DroneMonitoring'", "'Camera'", "'CameraFocus'", "'AI'", "'AIMonitoring'", "'-'", "'Light'", "'TypeLight'", "'HumiditySensor'", "'HumidityValueInPercentage'", "'TemperatureSensosor'", "'CrateTemperature'", "'PlantTemperature'", "'SoilSensor'", "'ph'", "'SoilMoistureInPercentage'", "'Crop'", "'.'", "'TurnOn'", "'TemperatureinDegreeCelcius'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }


    	private MyDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleFarm"
    // InternalMyDsl.g:53:1: entryRuleFarm : ruleFarm EOF ;
    public final void entryRuleFarm() throws RecognitionException {
        try {
            // InternalMyDsl.g:54:1: ( ruleFarm EOF )
            // InternalMyDsl.g:55:1: ruleFarm EOF
            {
             before(grammarAccess.getFarmRule()); 
            pushFollow(FOLLOW_1);
            ruleFarm();

            state._fsp--;

             after(grammarAccess.getFarmRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFarm"


    // $ANTLR start "ruleFarm"
    // InternalMyDsl.g:62:1: ruleFarm : ( ( rule__Farm__Group__0 ) ) ;
    public final void ruleFarm() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:66:2: ( ( ( rule__Farm__Group__0 ) ) )
            // InternalMyDsl.g:67:2: ( ( rule__Farm__Group__0 ) )
            {
            // InternalMyDsl.g:67:2: ( ( rule__Farm__Group__0 ) )
            // InternalMyDsl.g:68:3: ( rule__Farm__Group__0 )
            {
             before(grammarAccess.getFarmAccess().getGroup()); 
            // InternalMyDsl.g:69:3: ( rule__Farm__Group__0 )
            // InternalMyDsl.g:69:4: rule__Farm__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFarm"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:78:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalMyDsl.g:79:1: ( ruleEString EOF )
            // InternalMyDsl.g:80:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:87:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:91:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalMyDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalMyDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            // InternalMyDsl.g:93:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalMyDsl.g:94:3: ( rule__EString__Alternatives )
            // InternalMyDsl.g:94:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleCrate"
    // InternalMyDsl.g:103:1: entryRuleCrate : ruleCrate EOF ;
    public final void entryRuleCrate() throws RecognitionException {
        try {
            // InternalMyDsl.g:104:1: ( ruleCrate EOF )
            // InternalMyDsl.g:105:1: ruleCrate EOF
            {
             before(grammarAccess.getCrateRule()); 
            pushFollow(FOLLOW_1);
            ruleCrate();

            state._fsp--;

             after(grammarAccess.getCrateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCrate"


    // $ANTLR start "ruleCrate"
    // InternalMyDsl.g:112:1: ruleCrate : ( ( rule__Crate__Group__0 ) ) ;
    public final void ruleCrate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:116:2: ( ( ( rule__Crate__Group__0 ) ) )
            // InternalMyDsl.g:117:2: ( ( rule__Crate__Group__0 ) )
            {
            // InternalMyDsl.g:117:2: ( ( rule__Crate__Group__0 ) )
            // InternalMyDsl.g:118:3: ( rule__Crate__Group__0 )
            {
             before(grammarAccess.getCrateAccess().getGroup()); 
            // InternalMyDsl.g:119:3: ( rule__Crate__Group__0 )
            // InternalMyDsl.g:119:4: rule__Crate__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Crate__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCrate"


    // $ANTLR start "entryRuleDrone"
    // InternalMyDsl.g:128:1: entryRuleDrone : ruleDrone EOF ;
    public final void entryRuleDrone() throws RecognitionException {
        try {
            // InternalMyDsl.g:129:1: ( ruleDrone EOF )
            // InternalMyDsl.g:130:1: ruleDrone EOF
            {
             before(grammarAccess.getDroneRule()); 
            pushFollow(FOLLOW_1);
            ruleDrone();

            state._fsp--;

             after(grammarAccess.getDroneRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDrone"


    // $ANTLR start "ruleDrone"
    // InternalMyDsl.g:137:1: ruleDrone : ( ( rule__Drone__Group__0 ) ) ;
    public final void ruleDrone() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:141:2: ( ( ( rule__Drone__Group__0 ) ) )
            // InternalMyDsl.g:142:2: ( ( rule__Drone__Group__0 ) )
            {
            // InternalMyDsl.g:142:2: ( ( rule__Drone__Group__0 ) )
            // InternalMyDsl.g:143:3: ( rule__Drone__Group__0 )
            {
             before(grammarAccess.getDroneAccess().getGroup()); 
            // InternalMyDsl.g:144:3: ( rule__Drone__Group__0 )
            // InternalMyDsl.g:144:4: rule__Drone__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Drone__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getDroneAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDrone"


    // $ANTLR start "entryRuleCamera"
    // InternalMyDsl.g:153:1: entryRuleCamera : ruleCamera EOF ;
    public final void entryRuleCamera() throws RecognitionException {
        try {
            // InternalMyDsl.g:154:1: ( ruleCamera EOF )
            // InternalMyDsl.g:155:1: ruleCamera EOF
            {
             before(grammarAccess.getCameraRule()); 
            pushFollow(FOLLOW_1);
            ruleCamera();

            state._fsp--;

             after(grammarAccess.getCameraRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCamera"


    // $ANTLR start "ruleCamera"
    // InternalMyDsl.g:162:1: ruleCamera : ( ( rule__Camera__Group__0 ) ) ;
    public final void ruleCamera() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:166:2: ( ( ( rule__Camera__Group__0 ) ) )
            // InternalMyDsl.g:167:2: ( ( rule__Camera__Group__0 ) )
            {
            // InternalMyDsl.g:167:2: ( ( rule__Camera__Group__0 ) )
            // InternalMyDsl.g:168:3: ( rule__Camera__Group__0 )
            {
             before(grammarAccess.getCameraAccess().getGroup()); 
            // InternalMyDsl.g:169:3: ( rule__Camera__Group__0 )
            // InternalMyDsl.g:169:4: rule__Camera__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Camera__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCameraAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCamera"


    // $ANTLR start "entryRuleAI"
    // InternalMyDsl.g:178:1: entryRuleAI : ruleAI EOF ;
    public final void entryRuleAI() throws RecognitionException {
        try {
            // InternalMyDsl.g:179:1: ( ruleAI EOF )
            // InternalMyDsl.g:180:1: ruleAI EOF
            {
             before(grammarAccess.getAIRule()); 
            pushFollow(FOLLOW_1);
            ruleAI();

            state._fsp--;

             after(grammarAccess.getAIRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAI"


    // $ANTLR start "ruleAI"
    // InternalMyDsl.g:187:1: ruleAI : ( ( rule__AI__Group__0 ) ) ;
    public final void ruleAI() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:191:2: ( ( ( rule__AI__Group__0 ) ) )
            // InternalMyDsl.g:192:2: ( ( rule__AI__Group__0 ) )
            {
            // InternalMyDsl.g:192:2: ( ( rule__AI__Group__0 ) )
            // InternalMyDsl.g:193:3: ( rule__AI__Group__0 )
            {
             before(grammarAccess.getAIAccess().getGroup()); 
            // InternalMyDsl.g:194:3: ( rule__AI__Group__0 )
            // InternalMyDsl.g:194:4: rule__AI__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__AI__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAIAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAI"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:203:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalMyDsl.g:204:1: ( ruleEInt EOF )
            // InternalMyDsl.g:205:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:212:1: ruleEInt : ( ( rule__EInt__Group__0 ) ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:216:2: ( ( ( rule__EInt__Group__0 ) ) )
            // InternalMyDsl.g:217:2: ( ( rule__EInt__Group__0 ) )
            {
            // InternalMyDsl.g:217:2: ( ( rule__EInt__Group__0 ) )
            // InternalMyDsl.g:218:3: ( rule__EInt__Group__0 )
            {
             before(grammarAccess.getEIntAccess().getGroup()); 
            // InternalMyDsl.g:219:3: ( rule__EInt__Group__0 )
            // InternalMyDsl.g:219:4: rule__EInt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEIntAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleLight"
    // InternalMyDsl.g:228:1: entryRuleLight : ruleLight EOF ;
    public final void entryRuleLight() throws RecognitionException {
        try {
            // InternalMyDsl.g:229:1: ( ruleLight EOF )
            // InternalMyDsl.g:230:1: ruleLight EOF
            {
             before(grammarAccess.getLightRule()); 
            pushFollow(FOLLOW_1);
            ruleLight();

            state._fsp--;

             after(grammarAccess.getLightRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLight"


    // $ANTLR start "ruleLight"
    // InternalMyDsl.g:237:1: ruleLight : ( ( rule__Light__Group__0 ) ) ;
    public final void ruleLight() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:241:2: ( ( ( rule__Light__Group__0 ) ) )
            // InternalMyDsl.g:242:2: ( ( rule__Light__Group__0 ) )
            {
            // InternalMyDsl.g:242:2: ( ( rule__Light__Group__0 ) )
            // InternalMyDsl.g:243:3: ( rule__Light__Group__0 )
            {
             before(grammarAccess.getLightAccess().getGroup()); 
            // InternalMyDsl.g:244:3: ( rule__Light__Group__0 )
            // InternalMyDsl.g:244:4: rule__Light__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Light__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLight"


    // $ANTLR start "entryRuleHumiditySensor"
    // InternalMyDsl.g:253:1: entryRuleHumiditySensor : ruleHumiditySensor EOF ;
    public final void entryRuleHumiditySensor() throws RecognitionException {
        try {
            // InternalMyDsl.g:254:1: ( ruleHumiditySensor EOF )
            // InternalMyDsl.g:255:1: ruleHumiditySensor EOF
            {
             before(grammarAccess.getHumiditySensorRule()); 
            pushFollow(FOLLOW_1);
            ruleHumiditySensor();

            state._fsp--;

             after(grammarAccess.getHumiditySensorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleHumiditySensor"


    // $ANTLR start "ruleHumiditySensor"
    // InternalMyDsl.g:262:1: ruleHumiditySensor : ( ( rule__HumiditySensor__Group__0 ) ) ;
    public final void ruleHumiditySensor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:266:2: ( ( ( rule__HumiditySensor__Group__0 ) ) )
            // InternalMyDsl.g:267:2: ( ( rule__HumiditySensor__Group__0 ) )
            {
            // InternalMyDsl.g:267:2: ( ( rule__HumiditySensor__Group__0 ) )
            // InternalMyDsl.g:268:3: ( rule__HumiditySensor__Group__0 )
            {
             before(grammarAccess.getHumiditySensorAccess().getGroup()); 
            // InternalMyDsl.g:269:3: ( rule__HumiditySensor__Group__0 )
            // InternalMyDsl.g:269:4: rule__HumiditySensor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getHumiditySensorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleHumiditySensor"


    // $ANTLR start "entryRuleTemperatureSensosor"
    // InternalMyDsl.g:278:1: entryRuleTemperatureSensosor : ruleTemperatureSensosor EOF ;
    public final void entryRuleTemperatureSensosor() throws RecognitionException {
        try {
            // InternalMyDsl.g:279:1: ( ruleTemperatureSensosor EOF )
            // InternalMyDsl.g:280:1: ruleTemperatureSensosor EOF
            {
             before(grammarAccess.getTemperatureSensosorRule()); 
            pushFollow(FOLLOW_1);
            ruleTemperatureSensosor();

            state._fsp--;

             after(grammarAccess.getTemperatureSensosorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTemperatureSensosor"


    // $ANTLR start "ruleTemperatureSensosor"
    // InternalMyDsl.g:287:1: ruleTemperatureSensosor : ( ( rule__TemperatureSensosor__Group__0 ) ) ;
    public final void ruleTemperatureSensosor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:291:2: ( ( ( rule__TemperatureSensosor__Group__0 ) ) )
            // InternalMyDsl.g:292:2: ( ( rule__TemperatureSensosor__Group__0 ) )
            {
            // InternalMyDsl.g:292:2: ( ( rule__TemperatureSensosor__Group__0 ) )
            // InternalMyDsl.g:293:3: ( rule__TemperatureSensosor__Group__0 )
            {
             before(grammarAccess.getTemperatureSensosorAccess().getGroup()); 
            // InternalMyDsl.g:294:3: ( rule__TemperatureSensosor__Group__0 )
            // InternalMyDsl.g:294:4: rule__TemperatureSensosor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTemperatureSensosorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTemperatureSensosor"


    // $ANTLR start "entryRuleSoilSensor"
    // InternalMyDsl.g:303:1: entryRuleSoilSensor : ruleSoilSensor EOF ;
    public final void entryRuleSoilSensor() throws RecognitionException {
        try {
            // InternalMyDsl.g:304:1: ( ruleSoilSensor EOF )
            // InternalMyDsl.g:305:1: ruleSoilSensor EOF
            {
             before(grammarAccess.getSoilSensorRule()); 
            pushFollow(FOLLOW_1);
            ruleSoilSensor();

            state._fsp--;

             after(grammarAccess.getSoilSensorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSoilSensor"


    // $ANTLR start "ruleSoilSensor"
    // InternalMyDsl.g:312:1: ruleSoilSensor : ( ( rule__SoilSensor__Group__0 ) ) ;
    public final void ruleSoilSensor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:316:2: ( ( ( rule__SoilSensor__Group__0 ) ) )
            // InternalMyDsl.g:317:2: ( ( rule__SoilSensor__Group__0 ) )
            {
            // InternalMyDsl.g:317:2: ( ( rule__SoilSensor__Group__0 ) )
            // InternalMyDsl.g:318:3: ( rule__SoilSensor__Group__0 )
            {
             before(grammarAccess.getSoilSensorAccess().getGroup()); 
            // InternalMyDsl.g:319:3: ( rule__SoilSensor__Group__0 )
            // InternalMyDsl.g:319:4: rule__SoilSensor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSoilSensorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSoilSensor"


    // $ANTLR start "entryRuleCrop"
    // InternalMyDsl.g:328:1: entryRuleCrop : ruleCrop EOF ;
    public final void entryRuleCrop() throws RecognitionException {
        try {
            // InternalMyDsl.g:329:1: ( ruleCrop EOF )
            // InternalMyDsl.g:330:1: ruleCrop EOF
            {
             before(grammarAccess.getCropRule()); 
            pushFollow(FOLLOW_1);
            ruleCrop();

            state._fsp--;

             after(grammarAccess.getCropRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCrop"


    // $ANTLR start "ruleCrop"
    // InternalMyDsl.g:337:1: ruleCrop : ( ( rule__Crop__Group__0 ) ) ;
    public final void ruleCrop() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:341:2: ( ( ( rule__Crop__Group__0 ) ) )
            // InternalMyDsl.g:342:2: ( ( rule__Crop__Group__0 ) )
            {
            // InternalMyDsl.g:342:2: ( ( rule__Crop__Group__0 ) )
            // InternalMyDsl.g:343:3: ( rule__Crop__Group__0 )
            {
             before(grammarAccess.getCropAccess().getGroup()); 
            // InternalMyDsl.g:344:3: ( rule__Crop__Group__0 )
            // InternalMyDsl.g:344:4: rule__Crop__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Crop__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCropAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCrop"


    // $ANTLR start "entryRuleEFloat"
    // InternalMyDsl.g:353:1: entryRuleEFloat : ruleEFloat EOF ;
    public final void entryRuleEFloat() throws RecognitionException {
        try {
            // InternalMyDsl.g:354:1: ( ruleEFloat EOF )
            // InternalMyDsl.g:355:1: ruleEFloat EOF
            {
             before(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getEFloatRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalMyDsl.g:362:1: ruleEFloat : ( ( rule__EFloat__Group__0 ) ) ;
    public final void ruleEFloat() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:366:2: ( ( ( rule__EFloat__Group__0 ) ) )
            // InternalMyDsl.g:367:2: ( ( rule__EFloat__Group__0 ) )
            {
            // InternalMyDsl.g:367:2: ( ( rule__EFloat__Group__0 ) )
            // InternalMyDsl.g:368:3: ( rule__EFloat__Group__0 )
            {
             before(grammarAccess.getEFloatAccess().getGroup()); 
            // InternalMyDsl.g:369:3: ( rule__EFloat__Group__0 )
            // InternalMyDsl.g:369:4: rule__EFloat__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEFloatAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "ruletypelight"
    // InternalMyDsl.g:378:1: ruletypelight : ( ( rule__Typelight__Alternatives ) ) ;
    public final void ruletypelight() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:382:1: ( ( ( rule__Typelight__Alternatives ) ) )
            // InternalMyDsl.g:383:2: ( ( rule__Typelight__Alternatives ) )
            {
            // InternalMyDsl.g:383:2: ( ( rule__Typelight__Alternatives ) )
            // InternalMyDsl.g:384:3: ( rule__Typelight__Alternatives )
            {
             before(grammarAccess.getTypelightAccess().getAlternatives()); 
            // InternalMyDsl.g:385:3: ( rule__Typelight__Alternatives )
            // InternalMyDsl.g:385:4: rule__Typelight__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Typelight__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTypelightAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruletypelight"


    // $ANTLR start "ruleCropType"
    // InternalMyDsl.g:394:1: ruleCropType : ( ( rule__CropType__Alternatives ) ) ;
    public final void ruleCropType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:398:1: ( ( ( rule__CropType__Alternatives ) ) )
            // InternalMyDsl.g:399:2: ( ( rule__CropType__Alternatives ) )
            {
            // InternalMyDsl.g:399:2: ( ( rule__CropType__Alternatives ) )
            // InternalMyDsl.g:400:3: ( rule__CropType__Alternatives )
            {
             before(grammarAccess.getCropTypeAccess().getAlternatives()); 
            // InternalMyDsl.g:401:3: ( rule__CropType__Alternatives )
            // InternalMyDsl.g:401:4: rule__CropType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CropType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCropTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCropType"


    // $ANTLR start "ruleFocusArea"
    // InternalMyDsl.g:410:1: ruleFocusArea : ( ( rule__FocusArea__Alternatives ) ) ;
    public final void ruleFocusArea() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:414:1: ( ( ( rule__FocusArea__Alternatives ) ) )
            // InternalMyDsl.g:415:2: ( ( rule__FocusArea__Alternatives ) )
            {
            // InternalMyDsl.g:415:2: ( ( rule__FocusArea__Alternatives ) )
            // InternalMyDsl.g:416:3: ( rule__FocusArea__Alternatives )
            {
             before(grammarAccess.getFocusAreaAccess().getAlternatives()); 
            // InternalMyDsl.g:417:3: ( rule__FocusArea__Alternatives )
            // InternalMyDsl.g:417:4: rule__FocusArea__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__FocusArea__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getFocusAreaAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFocusArea"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalMyDsl.g:425:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:429:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:430:2: ( RULE_STRING )
                    {
                    // InternalMyDsl.g:430:2: ( RULE_STRING )
                    // InternalMyDsl.g:431:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:436:2: ( RULE_ID )
                    {
                    // InternalMyDsl.g:436:2: ( RULE_ID )
                    // InternalMyDsl.g:437:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__EFloat__Alternatives_4_0"
    // InternalMyDsl.g:446:1: rule__EFloat__Alternatives_4_0 : ( ( 'E' ) | ( 'e' ) );
    public final void rule__EFloat__Alternatives_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:450:1: ( ( 'E' ) | ( 'e' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            else if ( (LA2_0==12) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:451:2: ( 'E' )
                    {
                    // InternalMyDsl.g:451:2: ( 'E' )
                    // InternalMyDsl.g:452:3: 'E'
                    {
                     before(grammarAccess.getEFloatAccess().getEKeyword_4_0_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getEFloatAccess().getEKeyword_4_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:457:2: ( 'e' )
                    {
                    // InternalMyDsl.g:457:2: ( 'e' )
                    // InternalMyDsl.g:458:3: 'e'
                    {
                     before(grammarAccess.getEFloatAccess().getEKeyword_4_0_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getEFloatAccess().getEKeyword_4_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Alternatives_4_0"


    // $ANTLR start "rule__Typelight__Alternatives"
    // InternalMyDsl.g:467:1: rule__Typelight__Alternatives : ( ( ( 'UVlight' ) ) | ( ( 'BlueLight' ) ) | ( ( 'RedLight' ) ) | ( ( 'GreenLight' ) ) );
    public final void rule__Typelight__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:471:1: ( ( ( 'UVlight' ) ) | ( ( 'BlueLight' ) ) | ( ( 'RedLight' ) ) | ( ( 'GreenLight' ) ) )
            int alt3=4;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt3=1;
                }
                break;
            case 14:
                {
                alt3=2;
                }
                break;
            case 15:
                {
                alt3=3;
                }
                break;
            case 16:
                {
                alt3=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:472:2: ( ( 'UVlight' ) )
                    {
                    // InternalMyDsl.g:472:2: ( ( 'UVlight' ) )
                    // InternalMyDsl.g:473:3: ( 'UVlight' )
                    {
                     before(grammarAccess.getTypelightAccess().getUVlightEnumLiteralDeclaration_0()); 
                    // InternalMyDsl.g:474:3: ( 'UVlight' )
                    // InternalMyDsl.g:474:4: 'UVlight'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypelightAccess().getUVlightEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:478:2: ( ( 'BlueLight' ) )
                    {
                    // InternalMyDsl.g:478:2: ( ( 'BlueLight' ) )
                    // InternalMyDsl.g:479:3: ( 'BlueLight' )
                    {
                     before(grammarAccess.getTypelightAccess().getBlueLightEnumLiteralDeclaration_1()); 
                    // InternalMyDsl.g:480:3: ( 'BlueLight' )
                    // InternalMyDsl.g:480:4: 'BlueLight'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypelightAccess().getBlueLightEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:484:2: ( ( 'RedLight' ) )
                    {
                    // InternalMyDsl.g:484:2: ( ( 'RedLight' ) )
                    // InternalMyDsl.g:485:3: ( 'RedLight' )
                    {
                     before(grammarAccess.getTypelightAccess().getRedLightEnumLiteralDeclaration_2()); 
                    // InternalMyDsl.g:486:3: ( 'RedLight' )
                    // InternalMyDsl.g:486:4: 'RedLight'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypelightAccess().getRedLightEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:490:2: ( ( 'GreenLight' ) )
                    {
                    // InternalMyDsl.g:490:2: ( ( 'GreenLight' ) )
                    // InternalMyDsl.g:491:3: ( 'GreenLight' )
                    {
                     before(grammarAccess.getTypelightAccess().getGreenLightEnumLiteralDeclaration_3()); 
                    // InternalMyDsl.g:492:3: ( 'GreenLight' )
                    // InternalMyDsl.g:492:4: 'GreenLight'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getTypelightAccess().getGreenLightEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Typelight__Alternatives"


    // $ANTLR start "rule__CropType__Alternatives"
    // InternalMyDsl.g:500:1: rule__CropType__Alternatives : ( ( ( 'Tomato' ) ) | ( ( 'Cabbage' ) ) | ( ( 'Potato' ) ) );
    public final void rule__CropType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:504:1: ( ( ( 'Tomato' ) ) | ( ( 'Cabbage' ) ) | ( ( 'Potato' ) ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt4=1;
                }
                break;
            case 18:
                {
                alt4=2;
                }
                break;
            case 19:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:505:2: ( ( 'Tomato' ) )
                    {
                    // InternalMyDsl.g:505:2: ( ( 'Tomato' ) )
                    // InternalMyDsl.g:506:3: ( 'Tomato' )
                    {
                     before(grammarAccess.getCropTypeAccess().getTomatoEnumLiteralDeclaration_0()); 
                    // InternalMyDsl.g:507:3: ( 'Tomato' )
                    // InternalMyDsl.g:507:4: 'Tomato'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getCropTypeAccess().getTomatoEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:511:2: ( ( 'Cabbage' ) )
                    {
                    // InternalMyDsl.g:511:2: ( ( 'Cabbage' ) )
                    // InternalMyDsl.g:512:3: ( 'Cabbage' )
                    {
                     before(grammarAccess.getCropTypeAccess().getCabbageEnumLiteralDeclaration_1()); 
                    // InternalMyDsl.g:513:3: ( 'Cabbage' )
                    // InternalMyDsl.g:513:4: 'Cabbage'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getCropTypeAccess().getCabbageEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:517:2: ( ( 'Potato' ) )
                    {
                    // InternalMyDsl.g:517:2: ( ( 'Potato' ) )
                    // InternalMyDsl.g:518:3: ( 'Potato' )
                    {
                     before(grammarAccess.getCropTypeAccess().getPotatoEnumLiteralDeclaration_2()); 
                    // InternalMyDsl.g:519:3: ( 'Potato' )
                    // InternalMyDsl.g:519:4: 'Potato'
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getCropTypeAccess().getPotatoEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CropType__Alternatives"


    // $ANTLR start "rule__FocusArea__Alternatives"
    // InternalMyDsl.g:527:1: rule__FocusArea__Alternatives : ( ( ( 'Crates' ) ) | ( ( 'Plants' ) ) | ( ( 'Cameras' ) ) | ( ( 'Drones' ) ) | ( ( 'Sensors' ) ) );
    public final void rule__FocusArea__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:531:1: ( ( ( 'Crates' ) ) | ( ( 'Plants' ) ) | ( ( 'Cameras' ) ) | ( ( 'Drones' ) ) | ( ( 'Sensors' ) ) )
            int alt5=5;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt5=1;
                }
                break;
            case 21:
                {
                alt5=2;
                }
                break;
            case 22:
                {
                alt5=3;
                }
                break;
            case 23:
                {
                alt5=4;
                }
                break;
            case 24:
                {
                alt5=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:532:2: ( ( 'Crates' ) )
                    {
                    // InternalMyDsl.g:532:2: ( ( 'Crates' ) )
                    // InternalMyDsl.g:533:3: ( 'Crates' )
                    {
                     before(grammarAccess.getFocusAreaAccess().getCratesEnumLiteralDeclaration_0()); 
                    // InternalMyDsl.g:534:3: ( 'Crates' )
                    // InternalMyDsl.g:534:4: 'Crates'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getFocusAreaAccess().getCratesEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:538:2: ( ( 'Plants' ) )
                    {
                    // InternalMyDsl.g:538:2: ( ( 'Plants' ) )
                    // InternalMyDsl.g:539:3: ( 'Plants' )
                    {
                     before(grammarAccess.getFocusAreaAccess().getPlantsEnumLiteralDeclaration_1()); 
                    // InternalMyDsl.g:540:3: ( 'Plants' )
                    // InternalMyDsl.g:540:4: 'Plants'
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getFocusAreaAccess().getPlantsEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:544:2: ( ( 'Cameras' ) )
                    {
                    // InternalMyDsl.g:544:2: ( ( 'Cameras' ) )
                    // InternalMyDsl.g:545:3: ( 'Cameras' )
                    {
                     before(grammarAccess.getFocusAreaAccess().getCamerasEnumLiteralDeclaration_2()); 
                    // InternalMyDsl.g:546:3: ( 'Cameras' )
                    // InternalMyDsl.g:546:4: 'Cameras'
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getFocusAreaAccess().getCamerasEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:550:2: ( ( 'Drones' ) )
                    {
                    // InternalMyDsl.g:550:2: ( ( 'Drones' ) )
                    // InternalMyDsl.g:551:3: ( 'Drones' )
                    {
                     before(grammarAccess.getFocusAreaAccess().getDronesEnumLiteralDeclaration_3()); 
                    // InternalMyDsl.g:552:3: ( 'Drones' )
                    // InternalMyDsl.g:552:4: 'Drones'
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getFocusAreaAccess().getDronesEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:556:2: ( ( 'Sensors' ) )
                    {
                    // InternalMyDsl.g:556:2: ( ( 'Sensors' ) )
                    // InternalMyDsl.g:557:3: ( 'Sensors' )
                    {
                     before(grammarAccess.getFocusAreaAccess().getSensorsEnumLiteralDeclaration_4()); 
                    // InternalMyDsl.g:558:3: ( 'Sensors' )
                    // InternalMyDsl.g:558:4: 'Sensors'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getFocusAreaAccess().getSensorsEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FocusArea__Alternatives"


    // $ANTLR start "rule__Farm__Group__0"
    // InternalMyDsl.g:566:1: rule__Farm__Group__0 : rule__Farm__Group__0__Impl rule__Farm__Group__1 ;
    public final void rule__Farm__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:570:1: ( rule__Farm__Group__0__Impl rule__Farm__Group__1 )
            // InternalMyDsl.g:571:2: rule__Farm__Group__0__Impl rule__Farm__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Farm__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__0"


    // $ANTLR start "rule__Farm__Group__0__Impl"
    // InternalMyDsl.g:578:1: rule__Farm__Group__0__Impl : ( 'Farm' ) ;
    public final void rule__Farm__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:582:1: ( ( 'Farm' ) )
            // InternalMyDsl.g:583:1: ( 'Farm' )
            {
            // InternalMyDsl.g:583:1: ( 'Farm' )
            // InternalMyDsl.g:584:2: 'Farm'
            {
             before(grammarAccess.getFarmAccess().getFarmKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getFarmKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__0__Impl"


    // $ANTLR start "rule__Farm__Group__1"
    // InternalMyDsl.g:593:1: rule__Farm__Group__1 : rule__Farm__Group__1__Impl rule__Farm__Group__2 ;
    public final void rule__Farm__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:597:1: ( rule__Farm__Group__1__Impl rule__Farm__Group__2 )
            // InternalMyDsl.g:598:2: rule__Farm__Group__1__Impl rule__Farm__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Farm__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__1"


    // $ANTLR start "rule__Farm__Group__1__Impl"
    // InternalMyDsl.g:605:1: rule__Farm__Group__1__Impl : ( ( rule__Farm__NameAssignment_1 ) ) ;
    public final void rule__Farm__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:609:1: ( ( ( rule__Farm__NameAssignment_1 ) ) )
            // InternalMyDsl.g:610:1: ( ( rule__Farm__NameAssignment_1 ) )
            {
            // InternalMyDsl.g:610:1: ( ( rule__Farm__NameAssignment_1 ) )
            // InternalMyDsl.g:611:2: ( rule__Farm__NameAssignment_1 )
            {
             before(grammarAccess.getFarmAccess().getNameAssignment_1()); 
            // InternalMyDsl.g:612:2: ( rule__Farm__NameAssignment_1 )
            // InternalMyDsl.g:612:3: rule__Farm__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Farm__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__1__Impl"


    // $ANTLR start "rule__Farm__Group__2"
    // InternalMyDsl.g:620:1: rule__Farm__Group__2 : rule__Farm__Group__2__Impl rule__Farm__Group__3 ;
    public final void rule__Farm__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:624:1: ( rule__Farm__Group__2__Impl rule__Farm__Group__3 )
            // InternalMyDsl.g:625:2: rule__Farm__Group__2__Impl rule__Farm__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Farm__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__2"


    // $ANTLR start "rule__Farm__Group__2__Impl"
    // InternalMyDsl.g:632:1: rule__Farm__Group__2__Impl : ( '{' ) ;
    public final void rule__Farm__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:636:1: ( ( '{' ) )
            // InternalMyDsl.g:637:1: ( '{' )
            {
            // InternalMyDsl.g:637:1: ( '{' )
            // InternalMyDsl.g:638:2: '{'
            {
             before(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__2__Impl"


    // $ANTLR start "rule__Farm__Group__3"
    // InternalMyDsl.g:647:1: rule__Farm__Group__3 : rule__Farm__Group__3__Impl rule__Farm__Group__4 ;
    public final void rule__Farm__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:651:1: ( rule__Farm__Group__3__Impl rule__Farm__Group__4 )
            // InternalMyDsl.g:652:2: rule__Farm__Group__3__Impl rule__Farm__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Farm__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__3"


    // $ANTLR start "rule__Farm__Group__3__Impl"
    // InternalMyDsl.g:659:1: rule__Farm__Group__3__Impl : ( 'MaxCrates' ) ;
    public final void rule__Farm__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:663:1: ( ( 'MaxCrates' ) )
            // InternalMyDsl.g:664:1: ( 'MaxCrates' )
            {
            // InternalMyDsl.g:664:1: ( 'MaxCrates' )
            // InternalMyDsl.g:665:2: 'MaxCrates'
            {
             before(grammarAccess.getFarmAccess().getMaxCratesKeyword_3()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getMaxCratesKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__3__Impl"


    // $ANTLR start "rule__Farm__Group__4"
    // InternalMyDsl.g:674:1: rule__Farm__Group__4 : rule__Farm__Group__4__Impl rule__Farm__Group__5 ;
    public final void rule__Farm__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:678:1: ( rule__Farm__Group__4__Impl rule__Farm__Group__5 )
            // InternalMyDsl.g:679:2: rule__Farm__Group__4__Impl rule__Farm__Group__5
            {
            pushFollow(FOLLOW_7);
            rule__Farm__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__4"


    // $ANTLR start "rule__Farm__Group__4__Impl"
    // InternalMyDsl.g:686:1: rule__Farm__Group__4__Impl : ( ( rule__Farm__MaxCratesAssignment_4 ) ) ;
    public final void rule__Farm__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:690:1: ( ( ( rule__Farm__MaxCratesAssignment_4 ) ) )
            // InternalMyDsl.g:691:1: ( ( rule__Farm__MaxCratesAssignment_4 ) )
            {
            // InternalMyDsl.g:691:1: ( ( rule__Farm__MaxCratesAssignment_4 ) )
            // InternalMyDsl.g:692:2: ( rule__Farm__MaxCratesAssignment_4 )
            {
             before(grammarAccess.getFarmAccess().getMaxCratesAssignment_4()); 
            // InternalMyDsl.g:693:2: ( rule__Farm__MaxCratesAssignment_4 )
            // InternalMyDsl.g:693:3: rule__Farm__MaxCratesAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Farm__MaxCratesAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getMaxCratesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__4__Impl"


    // $ANTLR start "rule__Farm__Group__5"
    // InternalMyDsl.g:701:1: rule__Farm__Group__5 : rule__Farm__Group__5__Impl rule__Farm__Group__6 ;
    public final void rule__Farm__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:705:1: ( rule__Farm__Group__5__Impl rule__Farm__Group__6 )
            // InternalMyDsl.g:706:2: rule__Farm__Group__5__Impl rule__Farm__Group__6
            {
            pushFollow(FOLLOW_7);
            rule__Farm__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__5"


    // $ANTLR start "rule__Farm__Group__5__Impl"
    // InternalMyDsl.g:713:1: rule__Farm__Group__5__Impl : ( ( rule__Farm__Group_5__0 )? ) ;
    public final void rule__Farm__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:717:1: ( ( ( rule__Farm__Group_5__0 )? ) )
            // InternalMyDsl.g:718:1: ( ( rule__Farm__Group_5__0 )? )
            {
            // InternalMyDsl.g:718:1: ( ( rule__Farm__Group_5__0 )? )
            // InternalMyDsl.g:719:2: ( rule__Farm__Group_5__0 )?
            {
             before(grammarAccess.getFarmAccess().getGroup_5()); 
            // InternalMyDsl.g:720:2: ( rule__Farm__Group_5__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==30) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:720:3: rule__Farm__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Farm__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFarmAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__5__Impl"


    // $ANTLR start "rule__Farm__Group__6"
    // InternalMyDsl.g:728:1: rule__Farm__Group__6 : rule__Farm__Group__6__Impl rule__Farm__Group__7 ;
    public final void rule__Farm__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:732:1: ( rule__Farm__Group__6__Impl rule__Farm__Group__7 )
            // InternalMyDsl.g:733:2: rule__Farm__Group__6__Impl rule__Farm__Group__7
            {
            pushFollow(FOLLOW_4);
            rule__Farm__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__6"


    // $ANTLR start "rule__Farm__Group__6__Impl"
    // InternalMyDsl.g:740:1: rule__Farm__Group__6__Impl : ( 'drone' ) ;
    public final void rule__Farm__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:744:1: ( ( 'drone' ) )
            // InternalMyDsl.g:745:1: ( 'drone' )
            {
            // InternalMyDsl.g:745:1: ( 'drone' )
            // InternalMyDsl.g:746:2: 'drone'
            {
             before(grammarAccess.getFarmAccess().getDroneKeyword_6()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getDroneKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__6__Impl"


    // $ANTLR start "rule__Farm__Group__7"
    // InternalMyDsl.g:755:1: rule__Farm__Group__7 : rule__Farm__Group__7__Impl rule__Farm__Group__8 ;
    public final void rule__Farm__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:759:1: ( rule__Farm__Group__7__Impl rule__Farm__Group__8 )
            // InternalMyDsl.g:760:2: rule__Farm__Group__7__Impl rule__Farm__Group__8
            {
            pushFollow(FOLLOW_8);
            rule__Farm__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__7"


    // $ANTLR start "rule__Farm__Group__7__Impl"
    // InternalMyDsl.g:767:1: rule__Farm__Group__7__Impl : ( '{' ) ;
    public final void rule__Farm__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:771:1: ( ( '{' ) )
            // InternalMyDsl.g:772:1: ( '{' )
            {
            // InternalMyDsl.g:772:1: ( '{' )
            // InternalMyDsl.g:773:2: '{'
            {
             before(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_7()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__7__Impl"


    // $ANTLR start "rule__Farm__Group__8"
    // InternalMyDsl.g:782:1: rule__Farm__Group__8 : rule__Farm__Group__8__Impl rule__Farm__Group__9 ;
    public final void rule__Farm__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:786:1: ( rule__Farm__Group__8__Impl rule__Farm__Group__9 )
            // InternalMyDsl.g:787:2: rule__Farm__Group__8__Impl rule__Farm__Group__9
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__8"


    // $ANTLR start "rule__Farm__Group__8__Impl"
    // InternalMyDsl.g:794:1: rule__Farm__Group__8__Impl : ( ( rule__Farm__DroneAssignment_8 ) ) ;
    public final void rule__Farm__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:798:1: ( ( ( rule__Farm__DroneAssignment_8 ) ) )
            // InternalMyDsl.g:799:1: ( ( rule__Farm__DroneAssignment_8 ) )
            {
            // InternalMyDsl.g:799:1: ( ( rule__Farm__DroneAssignment_8 ) )
            // InternalMyDsl.g:800:2: ( rule__Farm__DroneAssignment_8 )
            {
             before(grammarAccess.getFarmAccess().getDroneAssignment_8()); 
            // InternalMyDsl.g:801:2: ( rule__Farm__DroneAssignment_8 )
            // InternalMyDsl.g:801:3: rule__Farm__DroneAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Farm__DroneAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getDroneAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__8__Impl"


    // $ANTLR start "rule__Farm__Group__9"
    // InternalMyDsl.g:809:1: rule__Farm__Group__9 : rule__Farm__Group__9__Impl rule__Farm__Group__10 ;
    public final void rule__Farm__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:813:1: ( rule__Farm__Group__9__Impl rule__Farm__Group__10 )
            // InternalMyDsl.g:814:2: rule__Farm__Group__9__Impl rule__Farm__Group__10
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__9"


    // $ANTLR start "rule__Farm__Group__9__Impl"
    // InternalMyDsl.g:821:1: rule__Farm__Group__9__Impl : ( ( rule__Farm__Group_9__0 )* ) ;
    public final void rule__Farm__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:825:1: ( ( ( rule__Farm__Group_9__0 )* ) )
            // InternalMyDsl.g:826:1: ( ( rule__Farm__Group_9__0 )* )
            {
            // InternalMyDsl.g:826:1: ( ( rule__Farm__Group_9__0 )* )
            // InternalMyDsl.g:827:2: ( rule__Farm__Group_9__0 )*
            {
             before(grammarAccess.getFarmAccess().getGroup_9()); 
            // InternalMyDsl.g:828:2: ( rule__Farm__Group_9__0 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==31) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalMyDsl.g:828:3: rule__Farm__Group_9__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__Farm__Group_9__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getFarmAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__9__Impl"


    // $ANTLR start "rule__Farm__Group__10"
    // InternalMyDsl.g:836:1: rule__Farm__Group__10 : rule__Farm__Group__10__Impl rule__Farm__Group__11 ;
    public final void rule__Farm__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:840:1: ( rule__Farm__Group__10__Impl rule__Farm__Group__11 )
            // InternalMyDsl.g:841:2: rule__Farm__Group__10__Impl rule__Farm__Group__11
            {
            pushFollow(FOLLOW_11);
            rule__Farm__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__10"


    // $ANTLR start "rule__Farm__Group__10__Impl"
    // InternalMyDsl.g:848:1: rule__Farm__Group__10__Impl : ( '}' ) ;
    public final void rule__Farm__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:852:1: ( ( '}' ) )
            // InternalMyDsl.g:853:1: ( '}' )
            {
            // InternalMyDsl.g:853:1: ( '}' )
            // InternalMyDsl.g:854:2: '}'
            {
             before(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_10()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__10__Impl"


    // $ANTLR start "rule__Farm__Group__11"
    // InternalMyDsl.g:863:1: rule__Farm__Group__11 : rule__Farm__Group__11__Impl rule__Farm__Group__12 ;
    public final void rule__Farm__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:867:1: ( rule__Farm__Group__11__Impl rule__Farm__Group__12 )
            // InternalMyDsl.g:868:2: rule__Farm__Group__11__Impl rule__Farm__Group__12
            {
            pushFollow(FOLLOW_11);
            rule__Farm__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__11"


    // $ANTLR start "rule__Farm__Group__11__Impl"
    // InternalMyDsl.g:875:1: rule__Farm__Group__11__Impl : ( ( rule__Farm__Group_11__0 )? ) ;
    public final void rule__Farm__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:879:1: ( ( ( rule__Farm__Group_11__0 )? ) )
            // InternalMyDsl.g:880:1: ( ( rule__Farm__Group_11__0 )? )
            {
            // InternalMyDsl.g:880:1: ( ( rule__Farm__Group_11__0 )? )
            // InternalMyDsl.g:881:2: ( rule__Farm__Group_11__0 )?
            {
             before(grammarAccess.getFarmAccess().getGroup_11()); 
            // InternalMyDsl.g:882:2: ( rule__Farm__Group_11__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==32) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:882:3: rule__Farm__Group_11__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Farm__Group_11__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFarmAccess().getGroup_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__11__Impl"


    // $ANTLR start "rule__Farm__Group__12"
    // InternalMyDsl.g:890:1: rule__Farm__Group__12 : rule__Farm__Group__12__Impl rule__Farm__Group__13 ;
    public final void rule__Farm__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:894:1: ( rule__Farm__Group__12__Impl rule__Farm__Group__13 )
            // InternalMyDsl.g:895:2: rule__Farm__Group__12__Impl rule__Farm__Group__13
            {
            pushFollow(FOLLOW_11);
            rule__Farm__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__12"


    // $ANTLR start "rule__Farm__Group__12__Impl"
    // InternalMyDsl.g:902:1: rule__Farm__Group__12__Impl : ( ( rule__Farm__Group_12__0 )? ) ;
    public final void rule__Farm__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:906:1: ( ( ( rule__Farm__Group_12__0 )? ) )
            // InternalMyDsl.g:907:1: ( ( rule__Farm__Group_12__0 )? )
            {
            // InternalMyDsl.g:907:1: ( ( rule__Farm__Group_12__0 )? )
            // InternalMyDsl.g:908:2: ( rule__Farm__Group_12__0 )?
            {
             before(grammarAccess.getFarmAccess().getGroup_12()); 
            // InternalMyDsl.g:909:2: ( rule__Farm__Group_12__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==33) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:909:3: rule__Farm__Group_12__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Farm__Group_12__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFarmAccess().getGroup_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__12__Impl"


    // $ANTLR start "rule__Farm__Group__13"
    // InternalMyDsl.g:917:1: rule__Farm__Group__13 : rule__Farm__Group__13__Impl ;
    public final void rule__Farm__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:921:1: ( rule__Farm__Group__13__Impl )
            // InternalMyDsl.g:922:2: rule__Farm__Group__13__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group__13__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__13"


    // $ANTLR start "rule__Farm__Group__13__Impl"
    // InternalMyDsl.g:928:1: rule__Farm__Group__13__Impl : ( '}' ) ;
    public final void rule__Farm__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:932:1: ( ( '}' ) )
            // InternalMyDsl.g:933:1: ( '}' )
            {
            // InternalMyDsl.g:933:1: ( '}' )
            // InternalMyDsl.g:934:2: '}'
            {
             before(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_13()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group__13__Impl"


    // $ANTLR start "rule__Farm__Group_5__0"
    // InternalMyDsl.g:944:1: rule__Farm__Group_5__0 : rule__Farm__Group_5__0__Impl rule__Farm__Group_5__1 ;
    public final void rule__Farm__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:948:1: ( rule__Farm__Group_5__0__Impl rule__Farm__Group_5__1 )
            // InternalMyDsl.g:949:2: rule__Farm__Group_5__0__Impl rule__Farm__Group_5__1
            {
            pushFollow(FOLLOW_4);
            rule__Farm__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__0"


    // $ANTLR start "rule__Farm__Group_5__0__Impl"
    // InternalMyDsl.g:956:1: rule__Farm__Group_5__0__Impl : ( 'crate' ) ;
    public final void rule__Farm__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:960:1: ( ( 'crate' ) )
            // InternalMyDsl.g:961:1: ( 'crate' )
            {
            // InternalMyDsl.g:961:1: ( 'crate' )
            // InternalMyDsl.g:962:2: 'crate'
            {
             before(grammarAccess.getFarmAccess().getCrateKeyword_5_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCrateKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__0__Impl"


    // $ANTLR start "rule__Farm__Group_5__1"
    // InternalMyDsl.g:971:1: rule__Farm__Group_5__1 : rule__Farm__Group_5__1__Impl rule__Farm__Group_5__2 ;
    public final void rule__Farm__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:975:1: ( rule__Farm__Group_5__1__Impl rule__Farm__Group_5__2 )
            // InternalMyDsl.g:976:2: rule__Farm__Group_5__1__Impl rule__Farm__Group_5__2
            {
            pushFollow(FOLLOW_12);
            rule__Farm__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__1"


    // $ANTLR start "rule__Farm__Group_5__1__Impl"
    // InternalMyDsl.g:983:1: rule__Farm__Group_5__1__Impl : ( '{' ) ;
    public final void rule__Farm__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:987:1: ( ( '{' ) )
            // InternalMyDsl.g:988:1: ( '{' )
            {
            // InternalMyDsl.g:988:1: ( '{' )
            // InternalMyDsl.g:989:2: '{'
            {
             before(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__1__Impl"


    // $ANTLR start "rule__Farm__Group_5__2"
    // InternalMyDsl.g:998:1: rule__Farm__Group_5__2 : rule__Farm__Group_5__2__Impl rule__Farm__Group_5__3 ;
    public final void rule__Farm__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1002:1: ( rule__Farm__Group_5__2__Impl rule__Farm__Group_5__3 )
            // InternalMyDsl.g:1003:2: rule__Farm__Group_5__2__Impl rule__Farm__Group_5__3
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__2"


    // $ANTLR start "rule__Farm__Group_5__2__Impl"
    // InternalMyDsl.g:1010:1: rule__Farm__Group_5__2__Impl : ( ( rule__Farm__CrateAssignment_5_2 ) ) ;
    public final void rule__Farm__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1014:1: ( ( ( rule__Farm__CrateAssignment_5_2 ) ) )
            // InternalMyDsl.g:1015:1: ( ( rule__Farm__CrateAssignment_5_2 ) )
            {
            // InternalMyDsl.g:1015:1: ( ( rule__Farm__CrateAssignment_5_2 ) )
            // InternalMyDsl.g:1016:2: ( rule__Farm__CrateAssignment_5_2 )
            {
             before(grammarAccess.getFarmAccess().getCrateAssignment_5_2()); 
            // InternalMyDsl.g:1017:2: ( rule__Farm__CrateAssignment_5_2 )
            // InternalMyDsl.g:1017:3: rule__Farm__CrateAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Farm__CrateAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getCrateAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__2__Impl"


    // $ANTLR start "rule__Farm__Group_5__3"
    // InternalMyDsl.g:1025:1: rule__Farm__Group_5__3 : rule__Farm__Group_5__3__Impl rule__Farm__Group_5__4 ;
    public final void rule__Farm__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1029:1: ( rule__Farm__Group_5__3__Impl rule__Farm__Group_5__4 )
            // InternalMyDsl.g:1030:2: rule__Farm__Group_5__3__Impl rule__Farm__Group_5__4
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__3"


    // $ANTLR start "rule__Farm__Group_5__3__Impl"
    // InternalMyDsl.g:1037:1: rule__Farm__Group_5__3__Impl : ( ( rule__Farm__Group_5_3__0 )* ) ;
    public final void rule__Farm__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1041:1: ( ( ( rule__Farm__Group_5_3__0 )* ) )
            // InternalMyDsl.g:1042:1: ( ( rule__Farm__Group_5_3__0 )* )
            {
            // InternalMyDsl.g:1042:1: ( ( rule__Farm__Group_5_3__0 )* )
            // InternalMyDsl.g:1043:2: ( rule__Farm__Group_5_3__0 )*
            {
             before(grammarAccess.getFarmAccess().getGroup_5_3()); 
            // InternalMyDsl.g:1044:2: ( rule__Farm__Group_5_3__0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==31) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalMyDsl.g:1044:3: rule__Farm__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__Farm__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getFarmAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__3__Impl"


    // $ANTLR start "rule__Farm__Group_5__4"
    // InternalMyDsl.g:1052:1: rule__Farm__Group_5__4 : rule__Farm__Group_5__4__Impl ;
    public final void rule__Farm__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1056:1: ( rule__Farm__Group_5__4__Impl )
            // InternalMyDsl.g:1057:2: rule__Farm__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__4"


    // $ANTLR start "rule__Farm__Group_5__4__Impl"
    // InternalMyDsl.g:1063:1: rule__Farm__Group_5__4__Impl : ( '}' ) ;
    public final void rule__Farm__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1067:1: ( ( '}' ) )
            // InternalMyDsl.g:1068:1: ( '}' )
            {
            // InternalMyDsl.g:1068:1: ( '}' )
            // InternalMyDsl.g:1069:2: '}'
            {
             before(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5__4__Impl"


    // $ANTLR start "rule__Farm__Group_5_3__0"
    // InternalMyDsl.g:1079:1: rule__Farm__Group_5_3__0 : rule__Farm__Group_5_3__0__Impl rule__Farm__Group_5_3__1 ;
    public final void rule__Farm__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1083:1: ( rule__Farm__Group_5_3__0__Impl rule__Farm__Group_5_3__1 )
            // InternalMyDsl.g:1084:2: rule__Farm__Group_5_3__0__Impl rule__Farm__Group_5_3__1
            {
            pushFollow(FOLLOW_12);
            rule__Farm__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5_3__0"


    // $ANTLR start "rule__Farm__Group_5_3__0__Impl"
    // InternalMyDsl.g:1091:1: rule__Farm__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__Farm__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1095:1: ( ( ',' ) )
            // InternalMyDsl.g:1096:1: ( ',' )
            {
            // InternalMyDsl.g:1096:1: ( ',' )
            // InternalMyDsl.g:1097:2: ','
            {
             before(grammarAccess.getFarmAccess().getCommaKeyword_5_3_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5_3__0__Impl"


    // $ANTLR start "rule__Farm__Group_5_3__1"
    // InternalMyDsl.g:1106:1: rule__Farm__Group_5_3__1 : rule__Farm__Group_5_3__1__Impl ;
    public final void rule__Farm__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1110:1: ( rule__Farm__Group_5_3__1__Impl )
            // InternalMyDsl.g:1111:2: rule__Farm__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5_3__1"


    // $ANTLR start "rule__Farm__Group_5_3__1__Impl"
    // InternalMyDsl.g:1117:1: rule__Farm__Group_5_3__1__Impl : ( ( rule__Farm__CrateAssignment_5_3_1 ) ) ;
    public final void rule__Farm__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1121:1: ( ( ( rule__Farm__CrateAssignment_5_3_1 ) ) )
            // InternalMyDsl.g:1122:1: ( ( rule__Farm__CrateAssignment_5_3_1 ) )
            {
            // InternalMyDsl.g:1122:1: ( ( rule__Farm__CrateAssignment_5_3_1 ) )
            // InternalMyDsl.g:1123:2: ( rule__Farm__CrateAssignment_5_3_1 )
            {
             before(grammarAccess.getFarmAccess().getCrateAssignment_5_3_1()); 
            // InternalMyDsl.g:1124:2: ( rule__Farm__CrateAssignment_5_3_1 )
            // InternalMyDsl.g:1124:3: rule__Farm__CrateAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Farm__CrateAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getCrateAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_5_3__1__Impl"


    // $ANTLR start "rule__Farm__Group_9__0"
    // InternalMyDsl.g:1133:1: rule__Farm__Group_9__0 : rule__Farm__Group_9__0__Impl rule__Farm__Group_9__1 ;
    public final void rule__Farm__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1137:1: ( rule__Farm__Group_9__0__Impl rule__Farm__Group_9__1 )
            // InternalMyDsl.g:1138:2: rule__Farm__Group_9__0__Impl rule__Farm__Group_9__1
            {
            pushFollow(FOLLOW_8);
            rule__Farm__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_9__0"


    // $ANTLR start "rule__Farm__Group_9__0__Impl"
    // InternalMyDsl.g:1145:1: rule__Farm__Group_9__0__Impl : ( ',' ) ;
    public final void rule__Farm__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1149:1: ( ( ',' ) )
            // InternalMyDsl.g:1150:1: ( ',' )
            {
            // InternalMyDsl.g:1150:1: ( ',' )
            // InternalMyDsl.g:1151:2: ','
            {
             before(grammarAccess.getFarmAccess().getCommaKeyword_9_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCommaKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_9__0__Impl"


    // $ANTLR start "rule__Farm__Group_9__1"
    // InternalMyDsl.g:1160:1: rule__Farm__Group_9__1 : rule__Farm__Group_9__1__Impl ;
    public final void rule__Farm__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1164:1: ( rule__Farm__Group_9__1__Impl )
            // InternalMyDsl.g:1165:2: rule__Farm__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_9__1"


    // $ANTLR start "rule__Farm__Group_9__1__Impl"
    // InternalMyDsl.g:1171:1: rule__Farm__Group_9__1__Impl : ( ( rule__Farm__DroneAssignment_9_1 ) ) ;
    public final void rule__Farm__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1175:1: ( ( ( rule__Farm__DroneAssignment_9_1 ) ) )
            // InternalMyDsl.g:1176:1: ( ( rule__Farm__DroneAssignment_9_1 ) )
            {
            // InternalMyDsl.g:1176:1: ( ( rule__Farm__DroneAssignment_9_1 ) )
            // InternalMyDsl.g:1177:2: ( rule__Farm__DroneAssignment_9_1 )
            {
             before(grammarAccess.getFarmAccess().getDroneAssignment_9_1()); 
            // InternalMyDsl.g:1178:2: ( rule__Farm__DroneAssignment_9_1 )
            // InternalMyDsl.g:1178:3: rule__Farm__DroneAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__Farm__DroneAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getDroneAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_9__1__Impl"


    // $ANTLR start "rule__Farm__Group_11__0"
    // InternalMyDsl.g:1187:1: rule__Farm__Group_11__0 : rule__Farm__Group_11__0__Impl rule__Farm__Group_11__1 ;
    public final void rule__Farm__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1191:1: ( rule__Farm__Group_11__0__Impl rule__Farm__Group_11__1 )
            // InternalMyDsl.g:1192:2: rule__Farm__Group_11__0__Impl rule__Farm__Group_11__1
            {
            pushFollow(FOLLOW_4);
            rule__Farm__Group_11__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_11__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__0"


    // $ANTLR start "rule__Farm__Group_11__0__Impl"
    // InternalMyDsl.g:1199:1: rule__Farm__Group_11__0__Impl : ( 'camera' ) ;
    public final void rule__Farm__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1203:1: ( ( 'camera' ) )
            // InternalMyDsl.g:1204:1: ( 'camera' )
            {
            // InternalMyDsl.g:1204:1: ( 'camera' )
            // InternalMyDsl.g:1205:2: 'camera'
            {
             before(grammarAccess.getFarmAccess().getCameraKeyword_11_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCameraKeyword_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__0__Impl"


    // $ANTLR start "rule__Farm__Group_11__1"
    // InternalMyDsl.g:1214:1: rule__Farm__Group_11__1 : rule__Farm__Group_11__1__Impl rule__Farm__Group_11__2 ;
    public final void rule__Farm__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1218:1: ( rule__Farm__Group_11__1__Impl rule__Farm__Group_11__2 )
            // InternalMyDsl.g:1219:2: rule__Farm__Group_11__1__Impl rule__Farm__Group_11__2
            {
            pushFollow(FOLLOW_13);
            rule__Farm__Group_11__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_11__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__1"


    // $ANTLR start "rule__Farm__Group_11__1__Impl"
    // InternalMyDsl.g:1226:1: rule__Farm__Group_11__1__Impl : ( '{' ) ;
    public final void rule__Farm__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1230:1: ( ( '{' ) )
            // InternalMyDsl.g:1231:1: ( '{' )
            {
            // InternalMyDsl.g:1231:1: ( '{' )
            // InternalMyDsl.g:1232:2: '{'
            {
             before(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_11_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_11_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__1__Impl"


    // $ANTLR start "rule__Farm__Group_11__2"
    // InternalMyDsl.g:1241:1: rule__Farm__Group_11__2 : rule__Farm__Group_11__2__Impl rule__Farm__Group_11__3 ;
    public final void rule__Farm__Group_11__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1245:1: ( rule__Farm__Group_11__2__Impl rule__Farm__Group_11__3 )
            // InternalMyDsl.g:1246:2: rule__Farm__Group_11__2__Impl rule__Farm__Group_11__3
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_11__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_11__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__2"


    // $ANTLR start "rule__Farm__Group_11__2__Impl"
    // InternalMyDsl.g:1253:1: rule__Farm__Group_11__2__Impl : ( ( rule__Farm__CameraAssignment_11_2 ) ) ;
    public final void rule__Farm__Group_11__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1257:1: ( ( ( rule__Farm__CameraAssignment_11_2 ) ) )
            // InternalMyDsl.g:1258:1: ( ( rule__Farm__CameraAssignment_11_2 ) )
            {
            // InternalMyDsl.g:1258:1: ( ( rule__Farm__CameraAssignment_11_2 ) )
            // InternalMyDsl.g:1259:2: ( rule__Farm__CameraAssignment_11_2 )
            {
             before(grammarAccess.getFarmAccess().getCameraAssignment_11_2()); 
            // InternalMyDsl.g:1260:2: ( rule__Farm__CameraAssignment_11_2 )
            // InternalMyDsl.g:1260:3: rule__Farm__CameraAssignment_11_2
            {
            pushFollow(FOLLOW_2);
            rule__Farm__CameraAssignment_11_2();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getCameraAssignment_11_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__2__Impl"


    // $ANTLR start "rule__Farm__Group_11__3"
    // InternalMyDsl.g:1268:1: rule__Farm__Group_11__3 : rule__Farm__Group_11__3__Impl rule__Farm__Group_11__4 ;
    public final void rule__Farm__Group_11__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1272:1: ( rule__Farm__Group_11__3__Impl rule__Farm__Group_11__4 )
            // InternalMyDsl.g:1273:2: rule__Farm__Group_11__3__Impl rule__Farm__Group_11__4
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_11__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_11__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__3"


    // $ANTLR start "rule__Farm__Group_11__3__Impl"
    // InternalMyDsl.g:1280:1: rule__Farm__Group_11__3__Impl : ( ( rule__Farm__Group_11_3__0 )* ) ;
    public final void rule__Farm__Group_11__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1284:1: ( ( ( rule__Farm__Group_11_3__0 )* ) )
            // InternalMyDsl.g:1285:1: ( ( rule__Farm__Group_11_3__0 )* )
            {
            // InternalMyDsl.g:1285:1: ( ( rule__Farm__Group_11_3__0 )* )
            // InternalMyDsl.g:1286:2: ( rule__Farm__Group_11_3__0 )*
            {
             before(grammarAccess.getFarmAccess().getGroup_11_3()); 
            // InternalMyDsl.g:1287:2: ( rule__Farm__Group_11_3__0 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==31) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalMyDsl.g:1287:3: rule__Farm__Group_11_3__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__Farm__Group_11_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getFarmAccess().getGroup_11_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__3__Impl"


    // $ANTLR start "rule__Farm__Group_11__4"
    // InternalMyDsl.g:1295:1: rule__Farm__Group_11__4 : rule__Farm__Group_11__4__Impl ;
    public final void rule__Farm__Group_11__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1299:1: ( rule__Farm__Group_11__4__Impl )
            // InternalMyDsl.g:1300:2: rule__Farm__Group_11__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_11__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__4"


    // $ANTLR start "rule__Farm__Group_11__4__Impl"
    // InternalMyDsl.g:1306:1: rule__Farm__Group_11__4__Impl : ( '}' ) ;
    public final void rule__Farm__Group_11__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1310:1: ( ( '}' ) )
            // InternalMyDsl.g:1311:1: ( '}' )
            {
            // InternalMyDsl.g:1311:1: ( '}' )
            // InternalMyDsl.g:1312:2: '}'
            {
             before(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_11_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_11_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11__4__Impl"


    // $ANTLR start "rule__Farm__Group_11_3__0"
    // InternalMyDsl.g:1322:1: rule__Farm__Group_11_3__0 : rule__Farm__Group_11_3__0__Impl rule__Farm__Group_11_3__1 ;
    public final void rule__Farm__Group_11_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1326:1: ( rule__Farm__Group_11_3__0__Impl rule__Farm__Group_11_3__1 )
            // InternalMyDsl.g:1327:2: rule__Farm__Group_11_3__0__Impl rule__Farm__Group_11_3__1
            {
            pushFollow(FOLLOW_13);
            rule__Farm__Group_11_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_11_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11_3__0"


    // $ANTLR start "rule__Farm__Group_11_3__0__Impl"
    // InternalMyDsl.g:1334:1: rule__Farm__Group_11_3__0__Impl : ( ',' ) ;
    public final void rule__Farm__Group_11_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1338:1: ( ( ',' ) )
            // InternalMyDsl.g:1339:1: ( ',' )
            {
            // InternalMyDsl.g:1339:1: ( ',' )
            // InternalMyDsl.g:1340:2: ','
            {
             before(grammarAccess.getFarmAccess().getCommaKeyword_11_3_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCommaKeyword_11_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11_3__0__Impl"


    // $ANTLR start "rule__Farm__Group_11_3__1"
    // InternalMyDsl.g:1349:1: rule__Farm__Group_11_3__1 : rule__Farm__Group_11_3__1__Impl ;
    public final void rule__Farm__Group_11_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1353:1: ( rule__Farm__Group_11_3__1__Impl )
            // InternalMyDsl.g:1354:2: rule__Farm__Group_11_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_11_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11_3__1"


    // $ANTLR start "rule__Farm__Group_11_3__1__Impl"
    // InternalMyDsl.g:1360:1: rule__Farm__Group_11_3__1__Impl : ( ( rule__Farm__CameraAssignment_11_3_1 ) ) ;
    public final void rule__Farm__Group_11_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1364:1: ( ( ( rule__Farm__CameraAssignment_11_3_1 ) ) )
            // InternalMyDsl.g:1365:1: ( ( rule__Farm__CameraAssignment_11_3_1 ) )
            {
            // InternalMyDsl.g:1365:1: ( ( rule__Farm__CameraAssignment_11_3_1 ) )
            // InternalMyDsl.g:1366:2: ( rule__Farm__CameraAssignment_11_3_1 )
            {
             before(grammarAccess.getFarmAccess().getCameraAssignment_11_3_1()); 
            // InternalMyDsl.g:1367:2: ( rule__Farm__CameraAssignment_11_3_1 )
            // InternalMyDsl.g:1367:3: rule__Farm__CameraAssignment_11_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Farm__CameraAssignment_11_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getCameraAssignment_11_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_11_3__1__Impl"


    // $ANTLR start "rule__Farm__Group_12__0"
    // InternalMyDsl.g:1376:1: rule__Farm__Group_12__0 : rule__Farm__Group_12__0__Impl rule__Farm__Group_12__1 ;
    public final void rule__Farm__Group_12__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1380:1: ( rule__Farm__Group_12__0__Impl rule__Farm__Group_12__1 )
            // InternalMyDsl.g:1381:2: rule__Farm__Group_12__0__Impl rule__Farm__Group_12__1
            {
            pushFollow(FOLLOW_4);
            rule__Farm__Group_12__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_12__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__0"


    // $ANTLR start "rule__Farm__Group_12__0__Impl"
    // InternalMyDsl.g:1388:1: rule__Farm__Group_12__0__Impl : ( 'ai' ) ;
    public final void rule__Farm__Group_12__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1392:1: ( ( 'ai' ) )
            // InternalMyDsl.g:1393:1: ( 'ai' )
            {
            // InternalMyDsl.g:1393:1: ( 'ai' )
            // InternalMyDsl.g:1394:2: 'ai'
            {
             before(grammarAccess.getFarmAccess().getAiKeyword_12_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getAiKeyword_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__0__Impl"


    // $ANTLR start "rule__Farm__Group_12__1"
    // InternalMyDsl.g:1403:1: rule__Farm__Group_12__1 : rule__Farm__Group_12__1__Impl rule__Farm__Group_12__2 ;
    public final void rule__Farm__Group_12__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1407:1: ( rule__Farm__Group_12__1__Impl rule__Farm__Group_12__2 )
            // InternalMyDsl.g:1408:2: rule__Farm__Group_12__1__Impl rule__Farm__Group_12__2
            {
            pushFollow(FOLLOW_14);
            rule__Farm__Group_12__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_12__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__1"


    // $ANTLR start "rule__Farm__Group_12__1__Impl"
    // InternalMyDsl.g:1415:1: rule__Farm__Group_12__1__Impl : ( '{' ) ;
    public final void rule__Farm__Group_12__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1419:1: ( ( '{' ) )
            // InternalMyDsl.g:1420:1: ( '{' )
            {
            // InternalMyDsl.g:1420:1: ( '{' )
            // InternalMyDsl.g:1421:2: '{'
            {
             before(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_12_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_12_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__1__Impl"


    // $ANTLR start "rule__Farm__Group_12__2"
    // InternalMyDsl.g:1430:1: rule__Farm__Group_12__2 : rule__Farm__Group_12__2__Impl rule__Farm__Group_12__3 ;
    public final void rule__Farm__Group_12__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1434:1: ( rule__Farm__Group_12__2__Impl rule__Farm__Group_12__3 )
            // InternalMyDsl.g:1435:2: rule__Farm__Group_12__2__Impl rule__Farm__Group_12__3
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_12__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_12__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__2"


    // $ANTLR start "rule__Farm__Group_12__2__Impl"
    // InternalMyDsl.g:1442:1: rule__Farm__Group_12__2__Impl : ( ( rule__Farm__AiAssignment_12_2 ) ) ;
    public final void rule__Farm__Group_12__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1446:1: ( ( ( rule__Farm__AiAssignment_12_2 ) ) )
            // InternalMyDsl.g:1447:1: ( ( rule__Farm__AiAssignment_12_2 ) )
            {
            // InternalMyDsl.g:1447:1: ( ( rule__Farm__AiAssignment_12_2 ) )
            // InternalMyDsl.g:1448:2: ( rule__Farm__AiAssignment_12_2 )
            {
             before(grammarAccess.getFarmAccess().getAiAssignment_12_2()); 
            // InternalMyDsl.g:1449:2: ( rule__Farm__AiAssignment_12_2 )
            // InternalMyDsl.g:1449:3: rule__Farm__AiAssignment_12_2
            {
            pushFollow(FOLLOW_2);
            rule__Farm__AiAssignment_12_2();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getAiAssignment_12_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__2__Impl"


    // $ANTLR start "rule__Farm__Group_12__3"
    // InternalMyDsl.g:1457:1: rule__Farm__Group_12__3 : rule__Farm__Group_12__3__Impl rule__Farm__Group_12__4 ;
    public final void rule__Farm__Group_12__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1461:1: ( rule__Farm__Group_12__3__Impl rule__Farm__Group_12__4 )
            // InternalMyDsl.g:1462:2: rule__Farm__Group_12__3__Impl rule__Farm__Group_12__4
            {
            pushFollow(FOLLOW_9);
            rule__Farm__Group_12__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_12__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__3"


    // $ANTLR start "rule__Farm__Group_12__3__Impl"
    // InternalMyDsl.g:1469:1: rule__Farm__Group_12__3__Impl : ( ( rule__Farm__Group_12_3__0 )* ) ;
    public final void rule__Farm__Group_12__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1473:1: ( ( ( rule__Farm__Group_12_3__0 )* ) )
            // InternalMyDsl.g:1474:1: ( ( rule__Farm__Group_12_3__0 )* )
            {
            // InternalMyDsl.g:1474:1: ( ( rule__Farm__Group_12_3__0 )* )
            // InternalMyDsl.g:1475:2: ( rule__Farm__Group_12_3__0 )*
            {
             before(grammarAccess.getFarmAccess().getGroup_12_3()); 
            // InternalMyDsl.g:1476:2: ( rule__Farm__Group_12_3__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==31) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalMyDsl.g:1476:3: rule__Farm__Group_12_3__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__Farm__Group_12_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getFarmAccess().getGroup_12_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__3__Impl"


    // $ANTLR start "rule__Farm__Group_12__4"
    // InternalMyDsl.g:1484:1: rule__Farm__Group_12__4 : rule__Farm__Group_12__4__Impl ;
    public final void rule__Farm__Group_12__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1488:1: ( rule__Farm__Group_12__4__Impl )
            // InternalMyDsl.g:1489:2: rule__Farm__Group_12__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_12__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__4"


    // $ANTLR start "rule__Farm__Group_12__4__Impl"
    // InternalMyDsl.g:1495:1: rule__Farm__Group_12__4__Impl : ( '}' ) ;
    public final void rule__Farm__Group_12__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1499:1: ( ( '}' ) )
            // InternalMyDsl.g:1500:1: ( '}' )
            {
            // InternalMyDsl.g:1500:1: ( '}' )
            // InternalMyDsl.g:1501:2: '}'
            {
             before(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_12_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_12_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12__4__Impl"


    // $ANTLR start "rule__Farm__Group_12_3__0"
    // InternalMyDsl.g:1511:1: rule__Farm__Group_12_3__0 : rule__Farm__Group_12_3__0__Impl rule__Farm__Group_12_3__1 ;
    public final void rule__Farm__Group_12_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1515:1: ( rule__Farm__Group_12_3__0__Impl rule__Farm__Group_12_3__1 )
            // InternalMyDsl.g:1516:2: rule__Farm__Group_12_3__0__Impl rule__Farm__Group_12_3__1
            {
            pushFollow(FOLLOW_14);
            rule__Farm__Group_12_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Farm__Group_12_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12_3__0"


    // $ANTLR start "rule__Farm__Group_12_3__0__Impl"
    // InternalMyDsl.g:1523:1: rule__Farm__Group_12_3__0__Impl : ( ',' ) ;
    public final void rule__Farm__Group_12_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1527:1: ( ( ',' ) )
            // InternalMyDsl.g:1528:1: ( ',' )
            {
            // InternalMyDsl.g:1528:1: ( ',' )
            // InternalMyDsl.g:1529:2: ','
            {
             before(grammarAccess.getFarmAccess().getCommaKeyword_12_3_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFarmAccess().getCommaKeyword_12_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12_3__0__Impl"


    // $ANTLR start "rule__Farm__Group_12_3__1"
    // InternalMyDsl.g:1538:1: rule__Farm__Group_12_3__1 : rule__Farm__Group_12_3__1__Impl ;
    public final void rule__Farm__Group_12_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1542:1: ( rule__Farm__Group_12_3__1__Impl )
            // InternalMyDsl.g:1543:2: rule__Farm__Group_12_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Farm__Group_12_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12_3__1"


    // $ANTLR start "rule__Farm__Group_12_3__1__Impl"
    // InternalMyDsl.g:1549:1: rule__Farm__Group_12_3__1__Impl : ( ( rule__Farm__AiAssignment_12_3_1 ) ) ;
    public final void rule__Farm__Group_12_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1553:1: ( ( ( rule__Farm__AiAssignment_12_3_1 ) ) )
            // InternalMyDsl.g:1554:1: ( ( rule__Farm__AiAssignment_12_3_1 ) )
            {
            // InternalMyDsl.g:1554:1: ( ( rule__Farm__AiAssignment_12_3_1 ) )
            // InternalMyDsl.g:1555:2: ( rule__Farm__AiAssignment_12_3_1 )
            {
             before(grammarAccess.getFarmAccess().getAiAssignment_12_3_1()); 
            // InternalMyDsl.g:1556:2: ( rule__Farm__AiAssignment_12_3_1 )
            // InternalMyDsl.g:1556:3: rule__Farm__AiAssignment_12_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Farm__AiAssignment_12_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFarmAccess().getAiAssignment_12_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__Group_12_3__1__Impl"


    // $ANTLR start "rule__Crate__Group__0"
    // InternalMyDsl.g:1565:1: rule__Crate__Group__0 : rule__Crate__Group__0__Impl rule__Crate__Group__1 ;
    public final void rule__Crate__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1569:1: ( rule__Crate__Group__0__Impl rule__Crate__Group__1 )
            // InternalMyDsl.g:1570:2: rule__Crate__Group__0__Impl rule__Crate__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Crate__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__0"


    // $ANTLR start "rule__Crate__Group__0__Impl"
    // InternalMyDsl.g:1577:1: rule__Crate__Group__0__Impl : ( 'Crate' ) ;
    public final void rule__Crate__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1581:1: ( ( 'Crate' ) )
            // InternalMyDsl.g:1582:1: ( 'Crate' )
            {
            // InternalMyDsl.g:1582:1: ( 'Crate' )
            // InternalMyDsl.g:1583:2: 'Crate'
            {
             before(grammarAccess.getCrateAccess().getCrateKeyword_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getCrateKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__0__Impl"


    // $ANTLR start "rule__Crate__Group__1"
    // InternalMyDsl.g:1592:1: rule__Crate__Group__1 : rule__Crate__Group__1__Impl rule__Crate__Group__2 ;
    public final void rule__Crate__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1596:1: ( rule__Crate__Group__1__Impl rule__Crate__Group__2 )
            // InternalMyDsl.g:1597:2: rule__Crate__Group__1__Impl rule__Crate__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Crate__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__1"


    // $ANTLR start "rule__Crate__Group__1__Impl"
    // InternalMyDsl.g:1604:1: rule__Crate__Group__1__Impl : ( '{' ) ;
    public final void rule__Crate__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1608:1: ( ( '{' ) )
            // InternalMyDsl.g:1609:1: ( '{' )
            {
            // InternalMyDsl.g:1609:1: ( '{' )
            // InternalMyDsl.g:1610:2: '{'
            {
             before(grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__1__Impl"


    // $ANTLR start "rule__Crate__Group__2"
    // InternalMyDsl.g:1619:1: rule__Crate__Group__2 : rule__Crate__Group__2__Impl rule__Crate__Group__3 ;
    public final void rule__Crate__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1623:1: ( rule__Crate__Group__2__Impl rule__Crate__Group__3 )
            // InternalMyDsl.g:1624:2: rule__Crate__Group__2__Impl rule__Crate__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Crate__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__2"


    // $ANTLR start "rule__Crate__Group__2__Impl"
    // InternalMyDsl.g:1631:1: rule__Crate__Group__2__Impl : ( ( rule__Crate__Group_2__0 )? ) ;
    public final void rule__Crate__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1635:1: ( ( ( rule__Crate__Group_2__0 )? ) )
            // InternalMyDsl.g:1636:1: ( ( rule__Crate__Group_2__0 )? )
            {
            // InternalMyDsl.g:1636:1: ( ( rule__Crate__Group_2__0 )? )
            // InternalMyDsl.g:1637:2: ( rule__Crate__Group_2__0 )?
            {
             before(grammarAccess.getCrateAccess().getGroup_2()); 
            // InternalMyDsl.g:1638:2: ( rule__Crate__Group_2__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==40) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:1638:3: rule__Crate__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Crate__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCrateAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__2__Impl"


    // $ANTLR start "rule__Crate__Group__3"
    // InternalMyDsl.g:1646:1: rule__Crate__Group__3 : rule__Crate__Group__3__Impl rule__Crate__Group__4 ;
    public final void rule__Crate__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1650:1: ( rule__Crate__Group__3__Impl rule__Crate__Group__4 )
            // InternalMyDsl.g:1651:2: rule__Crate__Group__3__Impl rule__Crate__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__Crate__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__3"


    // $ANTLR start "rule__Crate__Group__3__Impl"
    // InternalMyDsl.g:1658:1: rule__Crate__Group__3__Impl : ( 'light' ) ;
    public final void rule__Crate__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1662:1: ( ( 'light' ) )
            // InternalMyDsl.g:1663:1: ( 'light' )
            {
            // InternalMyDsl.g:1663:1: ( 'light' )
            // InternalMyDsl.g:1664:2: 'light'
            {
             before(grammarAccess.getCrateAccess().getLightKeyword_3()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getLightKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__3__Impl"


    // $ANTLR start "rule__Crate__Group__4"
    // InternalMyDsl.g:1673:1: rule__Crate__Group__4 : rule__Crate__Group__4__Impl rule__Crate__Group__5 ;
    public final void rule__Crate__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1677:1: ( rule__Crate__Group__4__Impl rule__Crate__Group__5 )
            // InternalMyDsl.g:1678:2: rule__Crate__Group__4__Impl rule__Crate__Group__5
            {
            pushFollow(FOLLOW_8);
            rule__Crate__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__4"


    // $ANTLR start "rule__Crate__Group__4__Impl"
    // InternalMyDsl.g:1685:1: rule__Crate__Group__4__Impl : ( '{' ) ;
    public final void rule__Crate__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1689:1: ( ( '{' ) )
            // InternalMyDsl.g:1690:1: ( '{' )
            {
            // InternalMyDsl.g:1690:1: ( '{' )
            // InternalMyDsl.g:1691:2: '{'
            {
             before(grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__4__Impl"


    // $ANTLR start "rule__Crate__Group__5"
    // InternalMyDsl.g:1700:1: rule__Crate__Group__5 : rule__Crate__Group__5__Impl rule__Crate__Group__6 ;
    public final void rule__Crate__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1704:1: ( rule__Crate__Group__5__Impl rule__Crate__Group__6 )
            // InternalMyDsl.g:1705:2: rule__Crate__Group__5__Impl rule__Crate__Group__6
            {
            pushFollow(FOLLOW_9);
            rule__Crate__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__5"


    // $ANTLR start "rule__Crate__Group__5__Impl"
    // InternalMyDsl.g:1712:1: rule__Crate__Group__5__Impl : ( ( rule__Crate__LightAssignment_5 ) ) ;
    public final void rule__Crate__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1716:1: ( ( ( rule__Crate__LightAssignment_5 ) ) )
            // InternalMyDsl.g:1717:1: ( ( rule__Crate__LightAssignment_5 ) )
            {
            // InternalMyDsl.g:1717:1: ( ( rule__Crate__LightAssignment_5 ) )
            // InternalMyDsl.g:1718:2: ( rule__Crate__LightAssignment_5 )
            {
             before(grammarAccess.getCrateAccess().getLightAssignment_5()); 
            // InternalMyDsl.g:1719:2: ( rule__Crate__LightAssignment_5 )
            // InternalMyDsl.g:1719:3: rule__Crate__LightAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Crate__LightAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getLightAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__5__Impl"


    // $ANTLR start "rule__Crate__Group__6"
    // InternalMyDsl.g:1727:1: rule__Crate__Group__6 : rule__Crate__Group__6__Impl rule__Crate__Group__7 ;
    public final void rule__Crate__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1731:1: ( rule__Crate__Group__6__Impl rule__Crate__Group__7 )
            // InternalMyDsl.g:1732:2: rule__Crate__Group__6__Impl rule__Crate__Group__7
            {
            pushFollow(FOLLOW_9);
            rule__Crate__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__6"


    // $ANTLR start "rule__Crate__Group__6__Impl"
    // InternalMyDsl.g:1739:1: rule__Crate__Group__6__Impl : ( ( rule__Crate__Group_6__0 )* ) ;
    public final void rule__Crate__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1743:1: ( ( ( rule__Crate__Group_6__0 )* ) )
            // InternalMyDsl.g:1744:1: ( ( rule__Crate__Group_6__0 )* )
            {
            // InternalMyDsl.g:1744:1: ( ( rule__Crate__Group_6__0 )* )
            // InternalMyDsl.g:1745:2: ( rule__Crate__Group_6__0 )*
            {
             before(grammarAccess.getCrateAccess().getGroup_6()); 
            // InternalMyDsl.g:1746:2: ( rule__Crate__Group_6__0 )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==31) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalMyDsl.g:1746:3: rule__Crate__Group_6__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__Crate__Group_6__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

             after(grammarAccess.getCrateAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__6__Impl"


    // $ANTLR start "rule__Crate__Group__7"
    // InternalMyDsl.g:1754:1: rule__Crate__Group__7 : rule__Crate__Group__7__Impl rule__Crate__Group__8 ;
    public final void rule__Crate__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1758:1: ( rule__Crate__Group__7__Impl rule__Crate__Group__8 )
            // InternalMyDsl.g:1759:2: rule__Crate__Group__7__Impl rule__Crate__Group__8
            {
            pushFollow(FOLLOW_16);
            rule__Crate__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__7"


    // $ANTLR start "rule__Crate__Group__7__Impl"
    // InternalMyDsl.g:1766:1: rule__Crate__Group__7__Impl : ( '}' ) ;
    public final void rule__Crate__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1770:1: ( ( '}' ) )
            // InternalMyDsl.g:1771:1: ( '}' )
            {
            // InternalMyDsl.g:1771:1: ( '}' )
            // InternalMyDsl.g:1772:2: '}'
            {
             before(grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_7()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__7__Impl"


    // $ANTLR start "rule__Crate__Group__8"
    // InternalMyDsl.g:1781:1: rule__Crate__Group__8 : rule__Crate__Group__8__Impl rule__Crate__Group__9 ;
    public final void rule__Crate__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1785:1: ( rule__Crate__Group__8__Impl rule__Crate__Group__9 )
            // InternalMyDsl.g:1786:2: rule__Crate__Group__8__Impl rule__Crate__Group__9
            {
            pushFollow(FOLLOW_8);
            rule__Crate__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__8"


    // $ANTLR start "rule__Crate__Group__8__Impl"
    // InternalMyDsl.g:1793:1: rule__Crate__Group__8__Impl : ( 'humiditysensor' ) ;
    public final void rule__Crate__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1797:1: ( ( 'humiditysensor' ) )
            // InternalMyDsl.g:1798:1: ( 'humiditysensor' )
            {
            // InternalMyDsl.g:1798:1: ( 'humiditysensor' )
            // InternalMyDsl.g:1799:2: 'humiditysensor'
            {
             before(grammarAccess.getCrateAccess().getHumiditysensorKeyword_8()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getHumiditysensorKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__8__Impl"


    // $ANTLR start "rule__Crate__Group__9"
    // InternalMyDsl.g:1808:1: rule__Crate__Group__9 : rule__Crate__Group__9__Impl rule__Crate__Group__10 ;
    public final void rule__Crate__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1812:1: ( rule__Crate__Group__9__Impl rule__Crate__Group__10 )
            // InternalMyDsl.g:1813:2: rule__Crate__Group__9__Impl rule__Crate__Group__10
            {
            pushFollow(FOLLOW_17);
            rule__Crate__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__9"


    // $ANTLR start "rule__Crate__Group__9__Impl"
    // InternalMyDsl.g:1820:1: rule__Crate__Group__9__Impl : ( ( rule__Crate__HumiditysensorAssignment_9 ) ) ;
    public final void rule__Crate__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1824:1: ( ( ( rule__Crate__HumiditysensorAssignment_9 ) ) )
            // InternalMyDsl.g:1825:1: ( ( rule__Crate__HumiditysensorAssignment_9 ) )
            {
            // InternalMyDsl.g:1825:1: ( ( rule__Crate__HumiditysensorAssignment_9 ) )
            // InternalMyDsl.g:1826:2: ( rule__Crate__HumiditysensorAssignment_9 )
            {
             before(grammarAccess.getCrateAccess().getHumiditysensorAssignment_9()); 
            // InternalMyDsl.g:1827:2: ( rule__Crate__HumiditysensorAssignment_9 )
            // InternalMyDsl.g:1827:3: rule__Crate__HumiditysensorAssignment_9
            {
            pushFollow(FOLLOW_2);
            rule__Crate__HumiditysensorAssignment_9();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getHumiditysensorAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__9__Impl"


    // $ANTLR start "rule__Crate__Group__10"
    // InternalMyDsl.g:1835:1: rule__Crate__Group__10 : rule__Crate__Group__10__Impl rule__Crate__Group__11 ;
    public final void rule__Crate__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1839:1: ( rule__Crate__Group__10__Impl rule__Crate__Group__11 )
            // InternalMyDsl.g:1840:2: rule__Crate__Group__10__Impl rule__Crate__Group__11
            {
            pushFollow(FOLLOW_18);
            rule__Crate__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__10"


    // $ANTLR start "rule__Crate__Group__10__Impl"
    // InternalMyDsl.g:1847:1: rule__Crate__Group__10__Impl : ( 'temperaturesensor' ) ;
    public final void rule__Crate__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1851:1: ( ( 'temperaturesensor' ) )
            // InternalMyDsl.g:1852:1: ( 'temperaturesensor' )
            {
            // InternalMyDsl.g:1852:1: ( 'temperaturesensor' )
            // InternalMyDsl.g:1853:2: 'temperaturesensor'
            {
             before(grammarAccess.getCrateAccess().getTemperaturesensorKeyword_10()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getTemperaturesensorKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__10__Impl"


    // $ANTLR start "rule__Crate__Group__11"
    // InternalMyDsl.g:1862:1: rule__Crate__Group__11 : rule__Crate__Group__11__Impl rule__Crate__Group__12 ;
    public final void rule__Crate__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1866:1: ( rule__Crate__Group__11__Impl rule__Crate__Group__12 )
            // InternalMyDsl.g:1867:2: rule__Crate__Group__11__Impl rule__Crate__Group__12
            {
            pushFollow(FOLLOW_19);
            rule__Crate__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__11"


    // $ANTLR start "rule__Crate__Group__11__Impl"
    // InternalMyDsl.g:1874:1: rule__Crate__Group__11__Impl : ( ( rule__Crate__TemperaturesensorAssignment_11 ) ) ;
    public final void rule__Crate__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1878:1: ( ( ( rule__Crate__TemperaturesensorAssignment_11 ) ) )
            // InternalMyDsl.g:1879:1: ( ( rule__Crate__TemperaturesensorAssignment_11 ) )
            {
            // InternalMyDsl.g:1879:1: ( ( rule__Crate__TemperaturesensorAssignment_11 ) )
            // InternalMyDsl.g:1880:2: ( rule__Crate__TemperaturesensorAssignment_11 )
            {
             before(grammarAccess.getCrateAccess().getTemperaturesensorAssignment_11()); 
            // InternalMyDsl.g:1881:2: ( rule__Crate__TemperaturesensorAssignment_11 )
            // InternalMyDsl.g:1881:3: rule__Crate__TemperaturesensorAssignment_11
            {
            pushFollow(FOLLOW_2);
            rule__Crate__TemperaturesensorAssignment_11();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getTemperaturesensorAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__11__Impl"


    // $ANTLR start "rule__Crate__Group__12"
    // InternalMyDsl.g:1889:1: rule__Crate__Group__12 : rule__Crate__Group__12__Impl rule__Crate__Group__13 ;
    public final void rule__Crate__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1893:1: ( rule__Crate__Group__12__Impl rule__Crate__Group__13 )
            // InternalMyDsl.g:1894:2: rule__Crate__Group__12__Impl rule__Crate__Group__13
            {
            pushFollow(FOLLOW_20);
            rule__Crate__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__12"


    // $ANTLR start "rule__Crate__Group__12__Impl"
    // InternalMyDsl.g:1901:1: rule__Crate__Group__12__Impl : ( 'soilsenor' ) ;
    public final void rule__Crate__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1905:1: ( ( 'soilsenor' ) )
            // InternalMyDsl.g:1906:1: ( 'soilsenor' )
            {
            // InternalMyDsl.g:1906:1: ( 'soilsenor' )
            // InternalMyDsl.g:1907:2: 'soilsenor'
            {
             before(grammarAccess.getCrateAccess().getSoilsenorKeyword_12()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getSoilsenorKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__12__Impl"


    // $ANTLR start "rule__Crate__Group__13"
    // InternalMyDsl.g:1916:1: rule__Crate__Group__13 : rule__Crate__Group__13__Impl rule__Crate__Group__14 ;
    public final void rule__Crate__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1920:1: ( rule__Crate__Group__13__Impl rule__Crate__Group__14 )
            // InternalMyDsl.g:1921:2: rule__Crate__Group__13__Impl rule__Crate__Group__14
            {
            pushFollow(FOLLOW_21);
            rule__Crate__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__13"


    // $ANTLR start "rule__Crate__Group__13__Impl"
    // InternalMyDsl.g:1928:1: rule__Crate__Group__13__Impl : ( ( rule__Crate__SoilsenorAssignment_13 ) ) ;
    public final void rule__Crate__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1932:1: ( ( ( rule__Crate__SoilsenorAssignment_13 ) ) )
            // InternalMyDsl.g:1933:1: ( ( rule__Crate__SoilsenorAssignment_13 ) )
            {
            // InternalMyDsl.g:1933:1: ( ( rule__Crate__SoilsenorAssignment_13 ) )
            // InternalMyDsl.g:1934:2: ( rule__Crate__SoilsenorAssignment_13 )
            {
             before(grammarAccess.getCrateAccess().getSoilsenorAssignment_13()); 
            // InternalMyDsl.g:1935:2: ( rule__Crate__SoilsenorAssignment_13 )
            // InternalMyDsl.g:1935:3: rule__Crate__SoilsenorAssignment_13
            {
            pushFollow(FOLLOW_2);
            rule__Crate__SoilsenorAssignment_13();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getSoilsenorAssignment_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__13__Impl"


    // $ANTLR start "rule__Crate__Group__14"
    // InternalMyDsl.g:1943:1: rule__Crate__Group__14 : rule__Crate__Group__14__Impl rule__Crate__Group__15 ;
    public final void rule__Crate__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1947:1: ( rule__Crate__Group__14__Impl rule__Crate__Group__15 )
            // InternalMyDsl.g:1948:2: rule__Crate__Group__14__Impl rule__Crate__Group__15
            {
            pushFollow(FOLLOW_22);
            rule__Crate__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__14"


    // $ANTLR start "rule__Crate__Group__14__Impl"
    // InternalMyDsl.g:1955:1: rule__Crate__Group__14__Impl : ( 'cropType' ) ;
    public final void rule__Crate__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1959:1: ( ( 'cropType' ) )
            // InternalMyDsl.g:1960:1: ( 'cropType' )
            {
            // InternalMyDsl.g:1960:1: ( 'cropType' )
            // InternalMyDsl.g:1961:2: 'cropType'
            {
             before(grammarAccess.getCrateAccess().getCropTypeKeyword_14()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getCropTypeKeyword_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__14__Impl"


    // $ANTLR start "rule__Crate__Group__15"
    // InternalMyDsl.g:1970:1: rule__Crate__Group__15 : rule__Crate__Group__15__Impl rule__Crate__Group__16 ;
    public final void rule__Crate__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1974:1: ( rule__Crate__Group__15__Impl rule__Crate__Group__16 )
            // InternalMyDsl.g:1975:2: rule__Crate__Group__15__Impl rule__Crate__Group__16
            {
            pushFollow(FOLLOW_23);
            rule__Crate__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__15"


    // $ANTLR start "rule__Crate__Group__15__Impl"
    // InternalMyDsl.g:1982:1: rule__Crate__Group__15__Impl : ( ( rule__Crate__CropTypeAssignment_15 ) ) ;
    public final void rule__Crate__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1986:1: ( ( ( rule__Crate__CropTypeAssignment_15 ) ) )
            // InternalMyDsl.g:1987:1: ( ( rule__Crate__CropTypeAssignment_15 ) )
            {
            // InternalMyDsl.g:1987:1: ( ( rule__Crate__CropTypeAssignment_15 ) )
            // InternalMyDsl.g:1988:2: ( rule__Crate__CropTypeAssignment_15 )
            {
             before(grammarAccess.getCrateAccess().getCropTypeAssignment_15()); 
            // InternalMyDsl.g:1989:2: ( rule__Crate__CropTypeAssignment_15 )
            // InternalMyDsl.g:1989:3: rule__Crate__CropTypeAssignment_15
            {
            pushFollow(FOLLOW_2);
            rule__Crate__CropTypeAssignment_15();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getCropTypeAssignment_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__15__Impl"


    // $ANTLR start "rule__Crate__Group__16"
    // InternalMyDsl.g:1997:1: rule__Crate__Group__16 : rule__Crate__Group__16__Impl ;
    public final void rule__Crate__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2001:1: ( rule__Crate__Group__16__Impl )
            // InternalMyDsl.g:2002:2: rule__Crate__Group__16__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Crate__Group__16__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__16"


    // $ANTLR start "rule__Crate__Group__16__Impl"
    // InternalMyDsl.g:2008:1: rule__Crate__Group__16__Impl : ( '}' ) ;
    public final void rule__Crate__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2012:1: ( ( '}' ) )
            // InternalMyDsl.g:2013:1: ( '}' )
            {
            // InternalMyDsl.g:2013:1: ( '}' )
            // InternalMyDsl.g:2014:2: '}'
            {
             before(grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_16()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group__16__Impl"


    // $ANTLR start "rule__Crate__Group_2__0"
    // InternalMyDsl.g:2024:1: rule__Crate__Group_2__0 : rule__Crate__Group_2__0__Impl rule__Crate__Group_2__1 ;
    public final void rule__Crate__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2028:1: ( rule__Crate__Group_2__0__Impl rule__Crate__Group_2__1 )
            // InternalMyDsl.g:2029:2: rule__Crate__Group_2__0__Impl rule__Crate__Group_2__1
            {
            pushFollow(FOLLOW_3);
            rule__Crate__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_2__0"


    // $ANTLR start "rule__Crate__Group_2__0__Impl"
    // InternalMyDsl.g:2036:1: rule__Crate__Group_2__0__Impl : ( 'id' ) ;
    public final void rule__Crate__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2040:1: ( ( 'id' ) )
            // InternalMyDsl.g:2041:1: ( 'id' )
            {
            // InternalMyDsl.g:2041:1: ( 'id' )
            // InternalMyDsl.g:2042:2: 'id'
            {
             before(grammarAccess.getCrateAccess().getIdKeyword_2_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getIdKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_2__0__Impl"


    // $ANTLR start "rule__Crate__Group_2__1"
    // InternalMyDsl.g:2051:1: rule__Crate__Group_2__1 : rule__Crate__Group_2__1__Impl ;
    public final void rule__Crate__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2055:1: ( rule__Crate__Group_2__1__Impl )
            // InternalMyDsl.g:2056:2: rule__Crate__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Crate__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_2__1"


    // $ANTLR start "rule__Crate__Group_2__1__Impl"
    // InternalMyDsl.g:2062:1: rule__Crate__Group_2__1__Impl : ( ( rule__Crate__IdAssignment_2_1 ) ) ;
    public final void rule__Crate__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2066:1: ( ( ( rule__Crate__IdAssignment_2_1 ) ) )
            // InternalMyDsl.g:2067:1: ( ( rule__Crate__IdAssignment_2_1 ) )
            {
            // InternalMyDsl.g:2067:1: ( ( rule__Crate__IdAssignment_2_1 ) )
            // InternalMyDsl.g:2068:2: ( rule__Crate__IdAssignment_2_1 )
            {
             before(grammarAccess.getCrateAccess().getIdAssignment_2_1()); 
            // InternalMyDsl.g:2069:2: ( rule__Crate__IdAssignment_2_1 )
            // InternalMyDsl.g:2069:3: rule__Crate__IdAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Crate__IdAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getIdAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_2__1__Impl"


    // $ANTLR start "rule__Crate__Group_6__0"
    // InternalMyDsl.g:2078:1: rule__Crate__Group_6__0 : rule__Crate__Group_6__0__Impl rule__Crate__Group_6__1 ;
    public final void rule__Crate__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2082:1: ( rule__Crate__Group_6__0__Impl rule__Crate__Group_6__1 )
            // InternalMyDsl.g:2083:2: rule__Crate__Group_6__0__Impl rule__Crate__Group_6__1
            {
            pushFollow(FOLLOW_8);
            rule__Crate__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crate__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_6__0"


    // $ANTLR start "rule__Crate__Group_6__0__Impl"
    // InternalMyDsl.g:2090:1: rule__Crate__Group_6__0__Impl : ( ',' ) ;
    public final void rule__Crate__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2094:1: ( ( ',' ) )
            // InternalMyDsl.g:2095:1: ( ',' )
            {
            // InternalMyDsl.g:2095:1: ( ',' )
            // InternalMyDsl.g:2096:2: ','
            {
             before(grammarAccess.getCrateAccess().getCommaKeyword_6_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getCrateAccess().getCommaKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_6__0__Impl"


    // $ANTLR start "rule__Crate__Group_6__1"
    // InternalMyDsl.g:2105:1: rule__Crate__Group_6__1 : rule__Crate__Group_6__1__Impl ;
    public final void rule__Crate__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2109:1: ( rule__Crate__Group_6__1__Impl )
            // InternalMyDsl.g:2110:2: rule__Crate__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Crate__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_6__1"


    // $ANTLR start "rule__Crate__Group_6__1__Impl"
    // InternalMyDsl.g:2116:1: rule__Crate__Group_6__1__Impl : ( ( rule__Crate__LightAssignment_6_1 ) ) ;
    public final void rule__Crate__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2120:1: ( ( ( rule__Crate__LightAssignment_6_1 ) ) )
            // InternalMyDsl.g:2121:1: ( ( rule__Crate__LightAssignment_6_1 ) )
            {
            // InternalMyDsl.g:2121:1: ( ( rule__Crate__LightAssignment_6_1 ) )
            // InternalMyDsl.g:2122:2: ( rule__Crate__LightAssignment_6_1 )
            {
             before(grammarAccess.getCrateAccess().getLightAssignment_6_1()); 
            // InternalMyDsl.g:2123:2: ( rule__Crate__LightAssignment_6_1 )
            // InternalMyDsl.g:2123:3: rule__Crate__LightAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Crate__LightAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getCrateAccess().getLightAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__Group_6__1__Impl"


    // $ANTLR start "rule__Drone__Group__0"
    // InternalMyDsl.g:2132:1: rule__Drone__Group__0 : rule__Drone__Group__0__Impl rule__Drone__Group__1 ;
    public final void rule__Drone__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2136:1: ( rule__Drone__Group__0__Impl rule__Drone__Group__1 )
            // InternalMyDsl.g:2137:2: rule__Drone__Group__0__Impl rule__Drone__Group__1
            {
            pushFollow(FOLLOW_24);
            rule__Drone__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__0"


    // $ANTLR start "rule__Drone__Group__0__Impl"
    // InternalMyDsl.g:2144:1: rule__Drone__Group__0__Impl : ( ( rule__Drone__TurnOnAssignment_0 ) ) ;
    public final void rule__Drone__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2148:1: ( ( ( rule__Drone__TurnOnAssignment_0 ) ) )
            // InternalMyDsl.g:2149:1: ( ( rule__Drone__TurnOnAssignment_0 ) )
            {
            // InternalMyDsl.g:2149:1: ( ( rule__Drone__TurnOnAssignment_0 ) )
            // InternalMyDsl.g:2150:2: ( rule__Drone__TurnOnAssignment_0 )
            {
             before(grammarAccess.getDroneAccess().getTurnOnAssignment_0()); 
            // InternalMyDsl.g:2151:2: ( rule__Drone__TurnOnAssignment_0 )
            // InternalMyDsl.g:2151:3: rule__Drone__TurnOnAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Drone__TurnOnAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getDroneAccess().getTurnOnAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__0__Impl"


    // $ANTLR start "rule__Drone__Group__1"
    // InternalMyDsl.g:2159:1: rule__Drone__Group__1 : rule__Drone__Group__1__Impl rule__Drone__Group__2 ;
    public final void rule__Drone__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2163:1: ( rule__Drone__Group__1__Impl rule__Drone__Group__2 )
            // InternalMyDsl.g:2164:2: rule__Drone__Group__1__Impl rule__Drone__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Drone__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__1"


    // $ANTLR start "rule__Drone__Group__1__Impl"
    // InternalMyDsl.g:2171:1: rule__Drone__Group__1__Impl : ( 'Drone' ) ;
    public final void rule__Drone__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2175:1: ( ( 'Drone' ) )
            // InternalMyDsl.g:2176:1: ( 'Drone' )
            {
            // InternalMyDsl.g:2176:1: ( 'Drone' )
            // InternalMyDsl.g:2177:2: 'Drone'
            {
             before(grammarAccess.getDroneAccess().getDroneKeyword_1()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getDroneAccess().getDroneKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__1__Impl"


    // $ANTLR start "rule__Drone__Group__2"
    // InternalMyDsl.g:2186:1: rule__Drone__Group__2 : rule__Drone__Group__2__Impl rule__Drone__Group__3 ;
    public final void rule__Drone__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2190:1: ( rule__Drone__Group__2__Impl rule__Drone__Group__3 )
            // InternalMyDsl.g:2191:2: rule__Drone__Group__2__Impl rule__Drone__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Drone__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__2"


    // $ANTLR start "rule__Drone__Group__2__Impl"
    // InternalMyDsl.g:2198:1: rule__Drone__Group__2__Impl : ( ( rule__Drone__NameAssignment_2 ) ) ;
    public final void rule__Drone__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2202:1: ( ( ( rule__Drone__NameAssignment_2 ) ) )
            // InternalMyDsl.g:2203:1: ( ( rule__Drone__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:2203:1: ( ( rule__Drone__NameAssignment_2 ) )
            // InternalMyDsl.g:2204:2: ( rule__Drone__NameAssignment_2 )
            {
             before(grammarAccess.getDroneAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:2205:2: ( rule__Drone__NameAssignment_2 )
            // InternalMyDsl.g:2205:3: rule__Drone__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Drone__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getDroneAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__2__Impl"


    // $ANTLR start "rule__Drone__Group__3"
    // InternalMyDsl.g:2213:1: rule__Drone__Group__3 : rule__Drone__Group__3__Impl rule__Drone__Group__4 ;
    public final void rule__Drone__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2217:1: ( rule__Drone__Group__3__Impl rule__Drone__Group__4 )
            // InternalMyDsl.g:2218:2: rule__Drone__Group__3__Impl rule__Drone__Group__4
            {
            pushFollow(FOLLOW_25);
            rule__Drone__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__3"


    // $ANTLR start "rule__Drone__Group__3__Impl"
    // InternalMyDsl.g:2225:1: rule__Drone__Group__3__Impl : ( '{' ) ;
    public final void rule__Drone__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2229:1: ( ( '{' ) )
            // InternalMyDsl.g:2230:1: ( '{' )
            {
            // InternalMyDsl.g:2230:1: ( '{' )
            // InternalMyDsl.g:2231:2: '{'
            {
             before(grammarAccess.getDroneAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getDroneAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__3__Impl"


    // $ANTLR start "rule__Drone__Group__4"
    // InternalMyDsl.g:2240:1: rule__Drone__Group__4 : rule__Drone__Group__4__Impl rule__Drone__Group__5 ;
    public final void rule__Drone__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2244:1: ( rule__Drone__Group__4__Impl rule__Drone__Group__5 )
            // InternalMyDsl.g:2245:2: rule__Drone__Group__4__Impl rule__Drone__Group__5
            {
            pushFollow(FOLLOW_25);
            rule__Drone__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__4"


    // $ANTLR start "rule__Drone__Group__4__Impl"
    // InternalMyDsl.g:2252:1: rule__Drone__Group__4__Impl : ( ( rule__Drone__Group_4__0 )? ) ;
    public final void rule__Drone__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2256:1: ( ( ( rule__Drone__Group_4__0 )? ) )
            // InternalMyDsl.g:2257:1: ( ( rule__Drone__Group_4__0 )? )
            {
            // InternalMyDsl.g:2257:1: ( ( rule__Drone__Group_4__0 )? )
            // InternalMyDsl.g:2258:2: ( rule__Drone__Group_4__0 )?
            {
             before(grammarAccess.getDroneAccess().getGroup_4()); 
            // InternalMyDsl.g:2259:2: ( rule__Drone__Group_4__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==42) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:2259:3: rule__Drone__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Drone__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getDroneAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__4__Impl"


    // $ANTLR start "rule__Drone__Group__5"
    // InternalMyDsl.g:2267:1: rule__Drone__Group__5 : rule__Drone__Group__5__Impl ;
    public final void rule__Drone__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2271:1: ( rule__Drone__Group__5__Impl )
            // InternalMyDsl.g:2272:2: rule__Drone__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Drone__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__5"


    // $ANTLR start "rule__Drone__Group__5__Impl"
    // InternalMyDsl.g:2278:1: rule__Drone__Group__5__Impl : ( '}' ) ;
    public final void rule__Drone__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2282:1: ( ( '}' ) )
            // InternalMyDsl.g:2283:1: ( '}' )
            {
            // InternalMyDsl.g:2283:1: ( '}' )
            // InternalMyDsl.g:2284:2: '}'
            {
             before(grammarAccess.getDroneAccess().getRightCurlyBracketKeyword_5()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getDroneAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group__5__Impl"


    // $ANTLR start "rule__Drone__Group_4__0"
    // InternalMyDsl.g:2294:1: rule__Drone__Group_4__0 : rule__Drone__Group_4__0__Impl rule__Drone__Group_4__1 ;
    public final void rule__Drone__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2298:1: ( rule__Drone__Group_4__0__Impl rule__Drone__Group_4__1 )
            // InternalMyDsl.g:2299:2: rule__Drone__Group_4__0__Impl rule__Drone__Group_4__1
            {
            pushFollow(FOLLOW_26);
            rule__Drone__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Drone__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group_4__0"


    // $ANTLR start "rule__Drone__Group_4__0__Impl"
    // InternalMyDsl.g:2306:1: rule__Drone__Group_4__0__Impl : ( 'DroneMonitoring' ) ;
    public final void rule__Drone__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2310:1: ( ( 'DroneMonitoring' ) )
            // InternalMyDsl.g:2311:1: ( 'DroneMonitoring' )
            {
            // InternalMyDsl.g:2311:1: ( 'DroneMonitoring' )
            // InternalMyDsl.g:2312:2: 'DroneMonitoring'
            {
             before(grammarAccess.getDroneAccess().getDroneMonitoringKeyword_4_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getDroneAccess().getDroneMonitoringKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group_4__0__Impl"


    // $ANTLR start "rule__Drone__Group_4__1"
    // InternalMyDsl.g:2321:1: rule__Drone__Group_4__1 : rule__Drone__Group_4__1__Impl ;
    public final void rule__Drone__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2325:1: ( rule__Drone__Group_4__1__Impl )
            // InternalMyDsl.g:2326:2: rule__Drone__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Drone__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group_4__1"


    // $ANTLR start "rule__Drone__Group_4__1__Impl"
    // InternalMyDsl.g:2332:1: rule__Drone__Group_4__1__Impl : ( ( rule__Drone__DroneMonitoringAssignment_4_1 ) ) ;
    public final void rule__Drone__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2336:1: ( ( ( rule__Drone__DroneMonitoringAssignment_4_1 ) ) )
            // InternalMyDsl.g:2337:1: ( ( rule__Drone__DroneMonitoringAssignment_4_1 ) )
            {
            // InternalMyDsl.g:2337:1: ( ( rule__Drone__DroneMonitoringAssignment_4_1 ) )
            // InternalMyDsl.g:2338:2: ( rule__Drone__DroneMonitoringAssignment_4_1 )
            {
             before(grammarAccess.getDroneAccess().getDroneMonitoringAssignment_4_1()); 
            // InternalMyDsl.g:2339:2: ( rule__Drone__DroneMonitoringAssignment_4_1 )
            // InternalMyDsl.g:2339:3: rule__Drone__DroneMonitoringAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Drone__DroneMonitoringAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getDroneAccess().getDroneMonitoringAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__Group_4__1__Impl"


    // $ANTLR start "rule__Camera__Group__0"
    // InternalMyDsl.g:2348:1: rule__Camera__Group__0 : rule__Camera__Group__0__Impl rule__Camera__Group__1 ;
    public final void rule__Camera__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2352:1: ( rule__Camera__Group__0__Impl rule__Camera__Group__1 )
            // InternalMyDsl.g:2353:2: rule__Camera__Group__0__Impl rule__Camera__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__Camera__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__0"


    // $ANTLR start "rule__Camera__Group__0__Impl"
    // InternalMyDsl.g:2360:1: rule__Camera__Group__0__Impl : ( () ) ;
    public final void rule__Camera__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2364:1: ( ( () ) )
            // InternalMyDsl.g:2365:1: ( () )
            {
            // InternalMyDsl.g:2365:1: ( () )
            // InternalMyDsl.g:2366:2: ()
            {
             before(grammarAccess.getCameraAccess().getCameraAction_0()); 
            // InternalMyDsl.g:2367:2: ()
            // InternalMyDsl.g:2367:3: 
            {
            }

             after(grammarAccess.getCameraAccess().getCameraAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__0__Impl"


    // $ANTLR start "rule__Camera__Group__1"
    // InternalMyDsl.g:2375:1: rule__Camera__Group__1 : rule__Camera__Group__1__Impl rule__Camera__Group__2 ;
    public final void rule__Camera__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2379:1: ( rule__Camera__Group__1__Impl rule__Camera__Group__2 )
            // InternalMyDsl.g:2380:2: rule__Camera__Group__1__Impl rule__Camera__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Camera__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__1"


    // $ANTLR start "rule__Camera__Group__1__Impl"
    // InternalMyDsl.g:2387:1: rule__Camera__Group__1__Impl : ( 'Camera' ) ;
    public final void rule__Camera__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2391:1: ( ( 'Camera' ) )
            // InternalMyDsl.g:2392:1: ( 'Camera' )
            {
            // InternalMyDsl.g:2392:1: ( 'Camera' )
            // InternalMyDsl.g:2393:2: 'Camera'
            {
             before(grammarAccess.getCameraAccess().getCameraKeyword_1()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getCameraAccess().getCameraKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__1__Impl"


    // $ANTLR start "rule__Camera__Group__2"
    // InternalMyDsl.g:2402:1: rule__Camera__Group__2 : rule__Camera__Group__2__Impl rule__Camera__Group__3 ;
    public final void rule__Camera__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2406:1: ( rule__Camera__Group__2__Impl rule__Camera__Group__3 )
            // InternalMyDsl.g:2407:2: rule__Camera__Group__2__Impl rule__Camera__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Camera__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__2"


    // $ANTLR start "rule__Camera__Group__2__Impl"
    // InternalMyDsl.g:2414:1: rule__Camera__Group__2__Impl : ( ( rule__Camera__NameAssignment_2 ) ) ;
    public final void rule__Camera__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2418:1: ( ( ( rule__Camera__NameAssignment_2 ) ) )
            // InternalMyDsl.g:2419:1: ( ( rule__Camera__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:2419:1: ( ( rule__Camera__NameAssignment_2 ) )
            // InternalMyDsl.g:2420:2: ( rule__Camera__NameAssignment_2 )
            {
             before(grammarAccess.getCameraAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:2421:2: ( rule__Camera__NameAssignment_2 )
            // InternalMyDsl.g:2421:3: rule__Camera__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Camera__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getCameraAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__2__Impl"


    // $ANTLR start "rule__Camera__Group__3"
    // InternalMyDsl.g:2429:1: rule__Camera__Group__3 : rule__Camera__Group__3__Impl rule__Camera__Group__4 ;
    public final void rule__Camera__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2433:1: ( rule__Camera__Group__3__Impl rule__Camera__Group__4 )
            // InternalMyDsl.g:2434:2: rule__Camera__Group__3__Impl rule__Camera__Group__4
            {
            pushFollow(FOLLOW_27);
            rule__Camera__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__3"


    // $ANTLR start "rule__Camera__Group__3__Impl"
    // InternalMyDsl.g:2441:1: rule__Camera__Group__3__Impl : ( '{' ) ;
    public final void rule__Camera__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2445:1: ( ( '{' ) )
            // InternalMyDsl.g:2446:1: ( '{' )
            {
            // InternalMyDsl.g:2446:1: ( '{' )
            // InternalMyDsl.g:2447:2: '{'
            {
             before(grammarAccess.getCameraAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getCameraAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__3__Impl"


    // $ANTLR start "rule__Camera__Group__4"
    // InternalMyDsl.g:2456:1: rule__Camera__Group__4 : rule__Camera__Group__4__Impl rule__Camera__Group__5 ;
    public final void rule__Camera__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2460:1: ( rule__Camera__Group__4__Impl rule__Camera__Group__5 )
            // InternalMyDsl.g:2461:2: rule__Camera__Group__4__Impl rule__Camera__Group__5
            {
            pushFollow(FOLLOW_27);
            rule__Camera__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__4"


    // $ANTLR start "rule__Camera__Group__4__Impl"
    // InternalMyDsl.g:2468:1: rule__Camera__Group__4__Impl : ( ( rule__Camera__Group_4__0 )? ) ;
    public final void rule__Camera__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2472:1: ( ( ( rule__Camera__Group_4__0 )? ) )
            // InternalMyDsl.g:2473:1: ( ( rule__Camera__Group_4__0 )? )
            {
            // InternalMyDsl.g:2473:1: ( ( rule__Camera__Group_4__0 )? )
            // InternalMyDsl.g:2474:2: ( rule__Camera__Group_4__0 )?
            {
             before(grammarAccess.getCameraAccess().getGroup_4()); 
            // InternalMyDsl.g:2475:2: ( rule__Camera__Group_4__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==44) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:2475:3: rule__Camera__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Camera__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCameraAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__4__Impl"


    // $ANTLR start "rule__Camera__Group__5"
    // InternalMyDsl.g:2483:1: rule__Camera__Group__5 : rule__Camera__Group__5__Impl ;
    public final void rule__Camera__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2487:1: ( rule__Camera__Group__5__Impl )
            // InternalMyDsl.g:2488:2: rule__Camera__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Camera__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__5"


    // $ANTLR start "rule__Camera__Group__5__Impl"
    // InternalMyDsl.g:2494:1: rule__Camera__Group__5__Impl : ( '}' ) ;
    public final void rule__Camera__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2498:1: ( ( '}' ) )
            // InternalMyDsl.g:2499:1: ( '}' )
            {
            // InternalMyDsl.g:2499:1: ( '}' )
            // InternalMyDsl.g:2500:2: '}'
            {
             before(grammarAccess.getCameraAccess().getRightCurlyBracketKeyword_5()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getCameraAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group__5__Impl"


    // $ANTLR start "rule__Camera__Group_4__0"
    // InternalMyDsl.g:2510:1: rule__Camera__Group_4__0 : rule__Camera__Group_4__0__Impl rule__Camera__Group_4__1 ;
    public final void rule__Camera__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2514:1: ( rule__Camera__Group_4__0__Impl rule__Camera__Group_4__1 )
            // InternalMyDsl.g:2515:2: rule__Camera__Group_4__0__Impl rule__Camera__Group_4__1
            {
            pushFollow(FOLLOW_26);
            rule__Camera__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Camera__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group_4__0"


    // $ANTLR start "rule__Camera__Group_4__0__Impl"
    // InternalMyDsl.g:2522:1: rule__Camera__Group_4__0__Impl : ( 'CameraFocus' ) ;
    public final void rule__Camera__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2526:1: ( ( 'CameraFocus' ) )
            // InternalMyDsl.g:2527:1: ( 'CameraFocus' )
            {
            // InternalMyDsl.g:2527:1: ( 'CameraFocus' )
            // InternalMyDsl.g:2528:2: 'CameraFocus'
            {
             before(grammarAccess.getCameraAccess().getCameraFocusKeyword_4_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getCameraAccess().getCameraFocusKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group_4__0__Impl"


    // $ANTLR start "rule__Camera__Group_4__1"
    // InternalMyDsl.g:2537:1: rule__Camera__Group_4__1 : rule__Camera__Group_4__1__Impl ;
    public final void rule__Camera__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2541:1: ( rule__Camera__Group_4__1__Impl )
            // InternalMyDsl.g:2542:2: rule__Camera__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Camera__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group_4__1"


    // $ANTLR start "rule__Camera__Group_4__1__Impl"
    // InternalMyDsl.g:2548:1: rule__Camera__Group_4__1__Impl : ( ( rule__Camera__CameraFocusAssignment_4_1 ) ) ;
    public final void rule__Camera__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2552:1: ( ( ( rule__Camera__CameraFocusAssignment_4_1 ) ) )
            // InternalMyDsl.g:2553:1: ( ( rule__Camera__CameraFocusAssignment_4_1 ) )
            {
            // InternalMyDsl.g:2553:1: ( ( rule__Camera__CameraFocusAssignment_4_1 ) )
            // InternalMyDsl.g:2554:2: ( rule__Camera__CameraFocusAssignment_4_1 )
            {
             before(grammarAccess.getCameraAccess().getCameraFocusAssignment_4_1()); 
            // InternalMyDsl.g:2555:2: ( rule__Camera__CameraFocusAssignment_4_1 )
            // InternalMyDsl.g:2555:3: rule__Camera__CameraFocusAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Camera__CameraFocusAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getCameraAccess().getCameraFocusAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__Group_4__1__Impl"


    // $ANTLR start "rule__AI__Group__0"
    // InternalMyDsl.g:2564:1: rule__AI__Group__0 : rule__AI__Group__0__Impl rule__AI__Group__1 ;
    public final void rule__AI__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2568:1: ( rule__AI__Group__0__Impl rule__AI__Group__1 )
            // InternalMyDsl.g:2569:2: rule__AI__Group__0__Impl rule__AI__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__AI__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__0"


    // $ANTLR start "rule__AI__Group__0__Impl"
    // InternalMyDsl.g:2576:1: rule__AI__Group__0__Impl : ( () ) ;
    public final void rule__AI__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2580:1: ( ( () ) )
            // InternalMyDsl.g:2581:1: ( () )
            {
            // InternalMyDsl.g:2581:1: ( () )
            // InternalMyDsl.g:2582:2: ()
            {
             before(grammarAccess.getAIAccess().getAIAction_0()); 
            // InternalMyDsl.g:2583:2: ()
            // InternalMyDsl.g:2583:3: 
            {
            }

             after(grammarAccess.getAIAccess().getAIAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__0__Impl"


    // $ANTLR start "rule__AI__Group__1"
    // InternalMyDsl.g:2591:1: rule__AI__Group__1 : rule__AI__Group__1__Impl rule__AI__Group__2 ;
    public final void rule__AI__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2595:1: ( rule__AI__Group__1__Impl rule__AI__Group__2 )
            // InternalMyDsl.g:2596:2: rule__AI__Group__1__Impl rule__AI__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__AI__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__1"


    // $ANTLR start "rule__AI__Group__1__Impl"
    // InternalMyDsl.g:2603:1: rule__AI__Group__1__Impl : ( 'AI' ) ;
    public final void rule__AI__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2607:1: ( ( 'AI' ) )
            // InternalMyDsl.g:2608:1: ( 'AI' )
            {
            // InternalMyDsl.g:2608:1: ( 'AI' )
            // InternalMyDsl.g:2609:2: 'AI'
            {
             before(grammarAccess.getAIAccess().getAIKeyword_1()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getAIAccess().getAIKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__1__Impl"


    // $ANTLR start "rule__AI__Group__2"
    // InternalMyDsl.g:2618:1: rule__AI__Group__2 : rule__AI__Group__2__Impl rule__AI__Group__3 ;
    public final void rule__AI__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2622:1: ( rule__AI__Group__2__Impl rule__AI__Group__3 )
            // InternalMyDsl.g:2623:2: rule__AI__Group__2__Impl rule__AI__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__AI__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__2"


    // $ANTLR start "rule__AI__Group__2__Impl"
    // InternalMyDsl.g:2630:1: rule__AI__Group__2__Impl : ( ( rule__AI__NameAssignment_2 ) ) ;
    public final void rule__AI__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2634:1: ( ( ( rule__AI__NameAssignment_2 ) ) )
            // InternalMyDsl.g:2635:1: ( ( rule__AI__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:2635:1: ( ( rule__AI__NameAssignment_2 ) )
            // InternalMyDsl.g:2636:2: ( rule__AI__NameAssignment_2 )
            {
             before(grammarAccess.getAIAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:2637:2: ( rule__AI__NameAssignment_2 )
            // InternalMyDsl.g:2637:3: rule__AI__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__AI__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getAIAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__2__Impl"


    // $ANTLR start "rule__AI__Group__3"
    // InternalMyDsl.g:2645:1: rule__AI__Group__3 : rule__AI__Group__3__Impl rule__AI__Group__4 ;
    public final void rule__AI__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2649:1: ( rule__AI__Group__3__Impl rule__AI__Group__4 )
            // InternalMyDsl.g:2650:2: rule__AI__Group__3__Impl rule__AI__Group__4
            {
            pushFollow(FOLLOW_28);
            rule__AI__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__3"


    // $ANTLR start "rule__AI__Group__3__Impl"
    // InternalMyDsl.g:2657:1: rule__AI__Group__3__Impl : ( '{' ) ;
    public final void rule__AI__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2661:1: ( ( '{' ) )
            // InternalMyDsl.g:2662:1: ( '{' )
            {
            // InternalMyDsl.g:2662:1: ( '{' )
            // InternalMyDsl.g:2663:2: '{'
            {
             before(grammarAccess.getAIAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getAIAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__3__Impl"


    // $ANTLR start "rule__AI__Group__4"
    // InternalMyDsl.g:2672:1: rule__AI__Group__4 : rule__AI__Group__4__Impl rule__AI__Group__5 ;
    public final void rule__AI__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2676:1: ( rule__AI__Group__4__Impl rule__AI__Group__5 )
            // InternalMyDsl.g:2677:2: rule__AI__Group__4__Impl rule__AI__Group__5
            {
            pushFollow(FOLLOW_28);
            rule__AI__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__4"


    // $ANTLR start "rule__AI__Group__4__Impl"
    // InternalMyDsl.g:2684:1: rule__AI__Group__4__Impl : ( ( rule__AI__Group_4__0 )? ) ;
    public final void rule__AI__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2688:1: ( ( ( rule__AI__Group_4__0 )? ) )
            // InternalMyDsl.g:2689:1: ( ( rule__AI__Group_4__0 )? )
            {
            // InternalMyDsl.g:2689:1: ( ( rule__AI__Group_4__0 )? )
            // InternalMyDsl.g:2690:2: ( rule__AI__Group_4__0 )?
            {
             before(grammarAccess.getAIAccess().getGroup_4()); 
            // InternalMyDsl.g:2691:2: ( rule__AI__Group_4__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==46) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:2691:3: rule__AI__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__AI__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAIAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__4__Impl"


    // $ANTLR start "rule__AI__Group__5"
    // InternalMyDsl.g:2699:1: rule__AI__Group__5 : rule__AI__Group__5__Impl ;
    public final void rule__AI__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2703:1: ( rule__AI__Group__5__Impl )
            // InternalMyDsl.g:2704:2: rule__AI__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AI__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__5"


    // $ANTLR start "rule__AI__Group__5__Impl"
    // InternalMyDsl.g:2710:1: rule__AI__Group__5__Impl : ( '}' ) ;
    public final void rule__AI__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2714:1: ( ( '}' ) )
            // InternalMyDsl.g:2715:1: ( '}' )
            {
            // InternalMyDsl.g:2715:1: ( '}' )
            // InternalMyDsl.g:2716:2: '}'
            {
             before(grammarAccess.getAIAccess().getRightCurlyBracketKeyword_5()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getAIAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group__5__Impl"


    // $ANTLR start "rule__AI__Group_4__0"
    // InternalMyDsl.g:2726:1: rule__AI__Group_4__0 : rule__AI__Group_4__0__Impl rule__AI__Group_4__1 ;
    public final void rule__AI__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2730:1: ( rule__AI__Group_4__0__Impl rule__AI__Group_4__1 )
            // InternalMyDsl.g:2731:2: rule__AI__Group_4__0__Impl rule__AI__Group_4__1
            {
            pushFollow(FOLLOW_26);
            rule__AI__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__AI__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group_4__0"


    // $ANTLR start "rule__AI__Group_4__0__Impl"
    // InternalMyDsl.g:2738:1: rule__AI__Group_4__0__Impl : ( 'AIMonitoring' ) ;
    public final void rule__AI__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2742:1: ( ( 'AIMonitoring' ) )
            // InternalMyDsl.g:2743:1: ( 'AIMonitoring' )
            {
            // InternalMyDsl.g:2743:1: ( 'AIMonitoring' )
            // InternalMyDsl.g:2744:2: 'AIMonitoring'
            {
             before(grammarAccess.getAIAccess().getAIMonitoringKeyword_4_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getAIAccess().getAIMonitoringKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group_4__0__Impl"


    // $ANTLR start "rule__AI__Group_4__1"
    // InternalMyDsl.g:2753:1: rule__AI__Group_4__1 : rule__AI__Group_4__1__Impl ;
    public final void rule__AI__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2757:1: ( rule__AI__Group_4__1__Impl )
            // InternalMyDsl.g:2758:2: rule__AI__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__AI__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group_4__1"


    // $ANTLR start "rule__AI__Group_4__1__Impl"
    // InternalMyDsl.g:2764:1: rule__AI__Group_4__1__Impl : ( ( rule__AI__AIMonitoringAssignment_4_1 ) ) ;
    public final void rule__AI__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2768:1: ( ( ( rule__AI__AIMonitoringAssignment_4_1 ) ) )
            // InternalMyDsl.g:2769:1: ( ( rule__AI__AIMonitoringAssignment_4_1 ) )
            {
            // InternalMyDsl.g:2769:1: ( ( rule__AI__AIMonitoringAssignment_4_1 ) )
            // InternalMyDsl.g:2770:2: ( rule__AI__AIMonitoringAssignment_4_1 )
            {
             before(grammarAccess.getAIAccess().getAIMonitoringAssignment_4_1()); 
            // InternalMyDsl.g:2771:2: ( rule__AI__AIMonitoringAssignment_4_1 )
            // InternalMyDsl.g:2771:3: rule__AI__AIMonitoringAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__AI__AIMonitoringAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getAIAccess().getAIMonitoringAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__Group_4__1__Impl"


    // $ANTLR start "rule__EInt__Group__0"
    // InternalMyDsl.g:2780:1: rule__EInt__Group__0 : rule__EInt__Group__0__Impl rule__EInt__Group__1 ;
    public final void rule__EInt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2784:1: ( rule__EInt__Group__0__Impl rule__EInt__Group__1 )
            // InternalMyDsl.g:2785:2: rule__EInt__Group__0__Impl rule__EInt__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__EInt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EInt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0"


    // $ANTLR start "rule__EInt__Group__0__Impl"
    // InternalMyDsl.g:2792:1: rule__EInt__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EInt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2796:1: ( ( ( '-' )? ) )
            // InternalMyDsl.g:2797:1: ( ( '-' )? )
            {
            // InternalMyDsl.g:2797:1: ( ( '-' )? )
            // InternalMyDsl.g:2798:2: ( '-' )?
            {
             before(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 
            // InternalMyDsl.g:2799:2: ( '-' )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==47) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:2799:3: '-'
                    {
                    match(input,47,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0__Impl"


    // $ANTLR start "rule__EInt__Group__1"
    // InternalMyDsl.g:2807:1: rule__EInt__Group__1 : rule__EInt__Group__1__Impl ;
    public final void rule__EInt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2811:1: ( rule__EInt__Group__1__Impl )
            // InternalMyDsl.g:2812:2: rule__EInt__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1"


    // $ANTLR start "rule__EInt__Group__1__Impl"
    // InternalMyDsl.g:2818:1: rule__EInt__Group__1__Impl : ( RULE_INT ) ;
    public final void rule__EInt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2822:1: ( ( RULE_INT ) )
            // InternalMyDsl.g:2823:1: ( RULE_INT )
            {
            // InternalMyDsl.g:2823:1: ( RULE_INT )
            // InternalMyDsl.g:2824:2: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1__Impl"


    // $ANTLR start "rule__Light__Group__0"
    // InternalMyDsl.g:2834:1: rule__Light__Group__0 : rule__Light__Group__0__Impl rule__Light__Group__1 ;
    public final void rule__Light__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2838:1: ( rule__Light__Group__0__Impl rule__Light__Group__1 )
            // InternalMyDsl.g:2839:2: rule__Light__Group__0__Impl rule__Light__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__Light__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__0"


    // $ANTLR start "rule__Light__Group__0__Impl"
    // InternalMyDsl.g:2846:1: rule__Light__Group__0__Impl : ( ( rule__Light__TurnOnAssignment_0 ) ) ;
    public final void rule__Light__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2850:1: ( ( ( rule__Light__TurnOnAssignment_0 ) ) )
            // InternalMyDsl.g:2851:1: ( ( rule__Light__TurnOnAssignment_0 ) )
            {
            // InternalMyDsl.g:2851:1: ( ( rule__Light__TurnOnAssignment_0 ) )
            // InternalMyDsl.g:2852:2: ( rule__Light__TurnOnAssignment_0 )
            {
             before(grammarAccess.getLightAccess().getTurnOnAssignment_0()); 
            // InternalMyDsl.g:2853:2: ( rule__Light__TurnOnAssignment_0 )
            // InternalMyDsl.g:2853:3: rule__Light__TurnOnAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Light__TurnOnAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getTurnOnAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__0__Impl"


    // $ANTLR start "rule__Light__Group__1"
    // InternalMyDsl.g:2861:1: rule__Light__Group__1 : rule__Light__Group__1__Impl rule__Light__Group__2 ;
    public final void rule__Light__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2865:1: ( rule__Light__Group__1__Impl rule__Light__Group__2 )
            // InternalMyDsl.g:2866:2: rule__Light__Group__1__Impl rule__Light__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Light__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__1"


    // $ANTLR start "rule__Light__Group__1__Impl"
    // InternalMyDsl.g:2873:1: rule__Light__Group__1__Impl : ( 'Light' ) ;
    public final void rule__Light__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2877:1: ( ( 'Light' ) )
            // InternalMyDsl.g:2878:1: ( 'Light' )
            {
            // InternalMyDsl.g:2878:1: ( 'Light' )
            // InternalMyDsl.g:2879:2: 'Light'
            {
             before(grammarAccess.getLightAccess().getLightKeyword_1()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getLightKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__1__Impl"


    // $ANTLR start "rule__Light__Group__2"
    // InternalMyDsl.g:2888:1: rule__Light__Group__2 : rule__Light__Group__2__Impl rule__Light__Group__3 ;
    public final void rule__Light__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2892:1: ( rule__Light__Group__2__Impl rule__Light__Group__3 )
            // InternalMyDsl.g:2893:2: rule__Light__Group__2__Impl rule__Light__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Light__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__2"


    // $ANTLR start "rule__Light__Group__2__Impl"
    // InternalMyDsl.g:2900:1: rule__Light__Group__2__Impl : ( ( rule__Light__NameAssignment_2 ) ) ;
    public final void rule__Light__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2904:1: ( ( ( rule__Light__NameAssignment_2 ) ) )
            // InternalMyDsl.g:2905:1: ( ( rule__Light__NameAssignment_2 ) )
            {
            // InternalMyDsl.g:2905:1: ( ( rule__Light__NameAssignment_2 ) )
            // InternalMyDsl.g:2906:2: ( rule__Light__NameAssignment_2 )
            {
             before(grammarAccess.getLightAccess().getNameAssignment_2()); 
            // InternalMyDsl.g:2907:2: ( rule__Light__NameAssignment_2 )
            // InternalMyDsl.g:2907:3: rule__Light__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Light__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__2__Impl"


    // $ANTLR start "rule__Light__Group__3"
    // InternalMyDsl.g:2915:1: rule__Light__Group__3 : rule__Light__Group__3__Impl rule__Light__Group__4 ;
    public final void rule__Light__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2919:1: ( rule__Light__Group__3__Impl rule__Light__Group__4 )
            // InternalMyDsl.g:2920:2: rule__Light__Group__3__Impl rule__Light__Group__4
            {
            pushFollow(FOLLOW_30);
            rule__Light__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__3"


    // $ANTLR start "rule__Light__Group__3__Impl"
    // InternalMyDsl.g:2927:1: rule__Light__Group__3__Impl : ( '{' ) ;
    public final void rule__Light__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2931:1: ( ( '{' ) )
            // InternalMyDsl.g:2932:1: ( '{' )
            {
            // InternalMyDsl.g:2932:1: ( '{' )
            // InternalMyDsl.g:2933:2: '{'
            {
             before(grammarAccess.getLightAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__3__Impl"


    // $ANTLR start "rule__Light__Group__4"
    // InternalMyDsl.g:2942:1: rule__Light__Group__4 : rule__Light__Group__4__Impl rule__Light__Group__5 ;
    public final void rule__Light__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2946:1: ( rule__Light__Group__4__Impl rule__Light__Group__5 )
            // InternalMyDsl.g:2947:2: rule__Light__Group__4__Impl rule__Light__Group__5
            {
            pushFollow(FOLLOW_30);
            rule__Light__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__4"


    // $ANTLR start "rule__Light__Group__4__Impl"
    // InternalMyDsl.g:2954:1: rule__Light__Group__4__Impl : ( ( rule__Light__Group_4__0 )? ) ;
    public final void rule__Light__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2958:1: ( ( ( rule__Light__Group_4__0 )? ) )
            // InternalMyDsl.g:2959:1: ( ( rule__Light__Group_4__0 )? )
            {
            // InternalMyDsl.g:2959:1: ( ( rule__Light__Group_4__0 )? )
            // InternalMyDsl.g:2960:2: ( rule__Light__Group_4__0 )?
            {
             before(grammarAccess.getLightAccess().getGroup_4()); 
            // InternalMyDsl.g:2961:2: ( rule__Light__Group_4__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==49) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyDsl.g:2961:3: rule__Light__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Light__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLightAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__4__Impl"


    // $ANTLR start "rule__Light__Group__5"
    // InternalMyDsl.g:2969:1: rule__Light__Group__5 : rule__Light__Group__5__Impl ;
    public final void rule__Light__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2973:1: ( rule__Light__Group__5__Impl )
            // InternalMyDsl.g:2974:2: rule__Light__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Light__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__5"


    // $ANTLR start "rule__Light__Group__5__Impl"
    // InternalMyDsl.g:2980:1: rule__Light__Group__5__Impl : ( '}' ) ;
    public final void rule__Light__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2984:1: ( ( '}' ) )
            // InternalMyDsl.g:2985:1: ( '}' )
            {
            // InternalMyDsl.g:2985:1: ( '}' )
            // InternalMyDsl.g:2986:2: '}'
            {
             before(grammarAccess.getLightAccess().getRightCurlyBracketKeyword_5()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group__5__Impl"


    // $ANTLR start "rule__Light__Group_4__0"
    // InternalMyDsl.g:2996:1: rule__Light__Group_4__0 : rule__Light__Group_4__0__Impl rule__Light__Group_4__1 ;
    public final void rule__Light__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3000:1: ( rule__Light__Group_4__0__Impl rule__Light__Group_4__1 )
            // InternalMyDsl.g:3001:2: rule__Light__Group_4__0__Impl rule__Light__Group_4__1
            {
            pushFollow(FOLLOW_31);
            rule__Light__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Light__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group_4__0"


    // $ANTLR start "rule__Light__Group_4__0__Impl"
    // InternalMyDsl.g:3008:1: rule__Light__Group_4__0__Impl : ( 'TypeLight' ) ;
    public final void rule__Light__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3012:1: ( ( 'TypeLight' ) )
            // InternalMyDsl.g:3013:1: ( 'TypeLight' )
            {
            // InternalMyDsl.g:3013:1: ( 'TypeLight' )
            // InternalMyDsl.g:3014:2: 'TypeLight'
            {
             before(grammarAccess.getLightAccess().getTypeLightKeyword_4_0()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getTypeLightKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group_4__0__Impl"


    // $ANTLR start "rule__Light__Group_4__1"
    // InternalMyDsl.g:3023:1: rule__Light__Group_4__1 : rule__Light__Group_4__1__Impl ;
    public final void rule__Light__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3027:1: ( rule__Light__Group_4__1__Impl )
            // InternalMyDsl.g:3028:2: rule__Light__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Light__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group_4__1"


    // $ANTLR start "rule__Light__Group_4__1__Impl"
    // InternalMyDsl.g:3034:1: rule__Light__Group_4__1__Impl : ( ( rule__Light__TypeLightAssignment_4_1 ) ) ;
    public final void rule__Light__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3038:1: ( ( ( rule__Light__TypeLightAssignment_4_1 ) ) )
            // InternalMyDsl.g:3039:1: ( ( rule__Light__TypeLightAssignment_4_1 ) )
            {
            // InternalMyDsl.g:3039:1: ( ( rule__Light__TypeLightAssignment_4_1 ) )
            // InternalMyDsl.g:3040:2: ( rule__Light__TypeLightAssignment_4_1 )
            {
             before(grammarAccess.getLightAccess().getTypeLightAssignment_4_1()); 
            // InternalMyDsl.g:3041:2: ( rule__Light__TypeLightAssignment_4_1 )
            // InternalMyDsl.g:3041:3: rule__Light__TypeLightAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Light__TypeLightAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getLightAccess().getTypeLightAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__Group_4__1__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__0"
    // InternalMyDsl.g:3050:1: rule__HumiditySensor__Group__0 : rule__HumiditySensor__Group__0__Impl rule__HumiditySensor__Group__1 ;
    public final void rule__HumiditySensor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3054:1: ( rule__HumiditySensor__Group__0__Impl rule__HumiditySensor__Group__1 )
            // InternalMyDsl.g:3055:2: rule__HumiditySensor__Group__0__Impl rule__HumiditySensor__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__HumiditySensor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__0"


    // $ANTLR start "rule__HumiditySensor__Group__0__Impl"
    // InternalMyDsl.g:3062:1: rule__HumiditySensor__Group__0__Impl : ( ( rule__HumiditySensor__TurnOnAssignment_0 ) ) ;
    public final void rule__HumiditySensor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3066:1: ( ( ( rule__HumiditySensor__TurnOnAssignment_0 ) ) )
            // InternalMyDsl.g:3067:1: ( ( rule__HumiditySensor__TurnOnAssignment_0 ) )
            {
            // InternalMyDsl.g:3067:1: ( ( rule__HumiditySensor__TurnOnAssignment_0 ) )
            // InternalMyDsl.g:3068:2: ( rule__HumiditySensor__TurnOnAssignment_0 )
            {
             before(grammarAccess.getHumiditySensorAccess().getTurnOnAssignment_0()); 
            // InternalMyDsl.g:3069:2: ( rule__HumiditySensor__TurnOnAssignment_0 )
            // InternalMyDsl.g:3069:3: rule__HumiditySensor__TurnOnAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__HumiditySensor__TurnOnAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getHumiditySensorAccess().getTurnOnAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__0__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__1"
    // InternalMyDsl.g:3077:1: rule__HumiditySensor__Group__1 : rule__HumiditySensor__Group__1__Impl rule__HumiditySensor__Group__2 ;
    public final void rule__HumiditySensor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3081:1: ( rule__HumiditySensor__Group__1__Impl rule__HumiditySensor__Group__2 )
            // InternalMyDsl.g:3082:2: rule__HumiditySensor__Group__1__Impl rule__HumiditySensor__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__HumiditySensor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__1"


    // $ANTLR start "rule__HumiditySensor__Group__1__Impl"
    // InternalMyDsl.g:3089:1: rule__HumiditySensor__Group__1__Impl : ( 'HumiditySensor' ) ;
    public final void rule__HumiditySensor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3093:1: ( ( 'HumiditySensor' ) )
            // InternalMyDsl.g:3094:1: ( 'HumiditySensor' )
            {
            // InternalMyDsl.g:3094:1: ( 'HumiditySensor' )
            // InternalMyDsl.g:3095:2: 'HumiditySensor'
            {
             before(grammarAccess.getHumiditySensorAccess().getHumiditySensorKeyword_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getHumiditySensorAccess().getHumiditySensorKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__1__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__2"
    // InternalMyDsl.g:3104:1: rule__HumiditySensor__Group__2 : rule__HumiditySensor__Group__2__Impl rule__HumiditySensor__Group__3 ;
    public final void rule__HumiditySensor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3108:1: ( rule__HumiditySensor__Group__2__Impl rule__HumiditySensor__Group__3 )
            // InternalMyDsl.g:3109:2: rule__HumiditySensor__Group__2__Impl rule__HumiditySensor__Group__3
            {
            pushFollow(FOLLOW_33);
            rule__HumiditySensor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__2"


    // $ANTLR start "rule__HumiditySensor__Group__2__Impl"
    // InternalMyDsl.g:3116:1: rule__HumiditySensor__Group__2__Impl : ( '{' ) ;
    public final void rule__HumiditySensor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3120:1: ( ( '{' ) )
            // InternalMyDsl.g:3121:1: ( '{' )
            {
            // InternalMyDsl.g:3121:1: ( '{' )
            // InternalMyDsl.g:3122:2: '{'
            {
             before(grammarAccess.getHumiditySensorAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getHumiditySensorAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__2__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__3"
    // InternalMyDsl.g:3131:1: rule__HumiditySensor__Group__3 : rule__HumiditySensor__Group__3__Impl rule__HumiditySensor__Group__4 ;
    public final void rule__HumiditySensor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3135:1: ( rule__HumiditySensor__Group__3__Impl rule__HumiditySensor__Group__4 )
            // InternalMyDsl.g:3136:2: rule__HumiditySensor__Group__3__Impl rule__HumiditySensor__Group__4
            {
            pushFollow(FOLLOW_34);
            rule__HumiditySensor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__3"


    // $ANTLR start "rule__HumiditySensor__Group__3__Impl"
    // InternalMyDsl.g:3143:1: rule__HumiditySensor__Group__3__Impl : ( 'HumidityValueInPercentage' ) ;
    public final void rule__HumiditySensor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3147:1: ( ( 'HumidityValueInPercentage' ) )
            // InternalMyDsl.g:3148:1: ( 'HumidityValueInPercentage' )
            {
            // InternalMyDsl.g:3148:1: ( 'HumidityValueInPercentage' )
            // InternalMyDsl.g:3149:2: 'HumidityValueInPercentage'
            {
             before(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageKeyword_3()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__3__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__4"
    // InternalMyDsl.g:3158:1: rule__HumiditySensor__Group__4 : rule__HumiditySensor__Group__4__Impl rule__HumiditySensor__Group__5 ;
    public final void rule__HumiditySensor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3162:1: ( rule__HumiditySensor__Group__4__Impl rule__HumiditySensor__Group__5 )
            // InternalMyDsl.g:3163:2: rule__HumiditySensor__Group__4__Impl rule__HumiditySensor__Group__5
            {
            pushFollow(FOLLOW_23);
            rule__HumiditySensor__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__4"


    // $ANTLR start "rule__HumiditySensor__Group__4__Impl"
    // InternalMyDsl.g:3170:1: rule__HumiditySensor__Group__4__Impl : ( ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 ) ) ;
    public final void rule__HumiditySensor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3174:1: ( ( ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 ) ) )
            // InternalMyDsl.g:3175:1: ( ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 ) )
            {
            // InternalMyDsl.g:3175:1: ( ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 ) )
            // InternalMyDsl.g:3176:2: ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 )
            {
             before(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageAssignment_4()); 
            // InternalMyDsl.g:3177:2: ( rule__HumiditySensor__HumidityValueInPercentageAssignment_4 )
            // InternalMyDsl.g:3177:3: rule__HumiditySensor__HumidityValueInPercentageAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__HumiditySensor__HumidityValueInPercentageAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__4__Impl"


    // $ANTLR start "rule__HumiditySensor__Group__5"
    // InternalMyDsl.g:3185:1: rule__HumiditySensor__Group__5 : rule__HumiditySensor__Group__5__Impl ;
    public final void rule__HumiditySensor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3189:1: ( rule__HumiditySensor__Group__5__Impl )
            // InternalMyDsl.g:3190:2: rule__HumiditySensor__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__HumiditySensor__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__5"


    // $ANTLR start "rule__HumiditySensor__Group__5__Impl"
    // InternalMyDsl.g:3196:1: rule__HumiditySensor__Group__5__Impl : ( '}' ) ;
    public final void rule__HumiditySensor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3200:1: ( ( '}' ) )
            // InternalMyDsl.g:3201:1: ( '}' )
            {
            // InternalMyDsl.g:3201:1: ( '}' )
            // InternalMyDsl.g:3202:2: '}'
            {
             before(grammarAccess.getHumiditySensorAccess().getRightCurlyBracketKeyword_5()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getHumiditySensorAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__Group__5__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__0"
    // InternalMyDsl.g:3212:1: rule__TemperatureSensosor__Group__0 : rule__TemperatureSensosor__Group__0__Impl rule__TemperatureSensosor__Group__1 ;
    public final void rule__TemperatureSensosor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3216:1: ( rule__TemperatureSensosor__Group__0__Impl rule__TemperatureSensosor__Group__1 )
            // InternalMyDsl.g:3217:2: rule__TemperatureSensosor__Group__0__Impl rule__TemperatureSensosor__Group__1
            {
            pushFollow(FOLLOW_35);
            rule__TemperatureSensosor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__0"


    // $ANTLR start "rule__TemperatureSensosor__Group__0__Impl"
    // InternalMyDsl.g:3224:1: rule__TemperatureSensosor__Group__0__Impl : ( ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 ) ) ;
    public final void rule__TemperatureSensosor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3228:1: ( ( ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 ) ) )
            // InternalMyDsl.g:3229:1: ( ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 ) )
            {
            // InternalMyDsl.g:3229:1: ( ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 ) )
            // InternalMyDsl.g:3230:2: ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 )
            {
             before(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusAssignment_0()); 
            // InternalMyDsl.g:3231:2: ( rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 )
            // InternalMyDsl.g:3231:3: rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__0__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__1"
    // InternalMyDsl.g:3239:1: rule__TemperatureSensosor__Group__1 : rule__TemperatureSensosor__Group__1__Impl rule__TemperatureSensosor__Group__2 ;
    public final void rule__TemperatureSensosor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3243:1: ( rule__TemperatureSensosor__Group__1__Impl rule__TemperatureSensosor__Group__2 )
            // InternalMyDsl.g:3244:2: rule__TemperatureSensosor__Group__1__Impl rule__TemperatureSensosor__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TemperatureSensosor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__1"


    // $ANTLR start "rule__TemperatureSensosor__Group__1__Impl"
    // InternalMyDsl.g:3251:1: rule__TemperatureSensosor__Group__1__Impl : ( 'TemperatureSensosor' ) ;
    public final void rule__TemperatureSensosor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3255:1: ( ( 'TemperatureSensosor' ) )
            // InternalMyDsl.g:3256:1: ( 'TemperatureSensosor' )
            {
            // InternalMyDsl.g:3256:1: ( 'TemperatureSensosor' )
            // InternalMyDsl.g:3257:2: 'TemperatureSensosor'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getTemperatureSensosorKeyword_1()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getTemperatureSensosorKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__1__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__2"
    // InternalMyDsl.g:3266:1: rule__TemperatureSensosor__Group__2 : rule__TemperatureSensosor__Group__2__Impl rule__TemperatureSensosor__Group__3 ;
    public final void rule__TemperatureSensosor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3270:1: ( rule__TemperatureSensosor__Group__2__Impl rule__TemperatureSensosor__Group__3 )
            // InternalMyDsl.g:3271:2: rule__TemperatureSensosor__Group__2__Impl rule__TemperatureSensosor__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__TemperatureSensosor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__2"


    // $ANTLR start "rule__TemperatureSensosor__Group__2__Impl"
    // InternalMyDsl.g:3278:1: rule__TemperatureSensosor__Group__2__Impl : ( '{' ) ;
    public final void rule__TemperatureSensosor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3282:1: ( ( '{' ) )
            // InternalMyDsl.g:3283:1: ( '{' )
            {
            // InternalMyDsl.g:3283:1: ( '{' )
            // InternalMyDsl.g:3284:2: '{'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__2__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__3"
    // InternalMyDsl.g:3293:1: rule__TemperatureSensosor__Group__3 : rule__TemperatureSensosor__Group__3__Impl rule__TemperatureSensosor__Group__4 ;
    public final void rule__TemperatureSensosor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3297:1: ( rule__TemperatureSensosor__Group__3__Impl rule__TemperatureSensosor__Group__4 )
            // InternalMyDsl.g:3298:2: rule__TemperatureSensosor__Group__3__Impl rule__TemperatureSensosor__Group__4
            {
            pushFollow(FOLLOW_34);
            rule__TemperatureSensosor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__3"


    // $ANTLR start "rule__TemperatureSensosor__Group__3__Impl"
    // InternalMyDsl.g:3305:1: rule__TemperatureSensosor__Group__3__Impl : ( 'CrateTemperature' ) ;
    public final void rule__TemperatureSensosor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3309:1: ( ( 'CrateTemperature' ) )
            // InternalMyDsl.g:3310:1: ( 'CrateTemperature' )
            {
            // InternalMyDsl.g:3310:1: ( 'CrateTemperature' )
            // InternalMyDsl.g:3311:2: 'CrateTemperature'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureKeyword_3()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__3__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__4"
    // InternalMyDsl.g:3320:1: rule__TemperatureSensosor__Group__4 : rule__TemperatureSensosor__Group__4__Impl rule__TemperatureSensosor__Group__5 ;
    public final void rule__TemperatureSensosor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3324:1: ( rule__TemperatureSensosor__Group__4__Impl rule__TemperatureSensosor__Group__5 )
            // InternalMyDsl.g:3325:2: rule__TemperatureSensosor__Group__4__Impl rule__TemperatureSensosor__Group__5
            {
            pushFollow(FOLLOW_37);
            rule__TemperatureSensosor__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__4"


    // $ANTLR start "rule__TemperatureSensosor__Group__4__Impl"
    // InternalMyDsl.g:3332:1: rule__TemperatureSensosor__Group__4__Impl : ( ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 ) ) ;
    public final void rule__TemperatureSensosor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3336:1: ( ( ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 ) ) )
            // InternalMyDsl.g:3337:1: ( ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 ) )
            {
            // InternalMyDsl.g:3337:1: ( ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 ) )
            // InternalMyDsl.g:3338:2: ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 )
            {
             before(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureAssignment_4()); 
            // InternalMyDsl.g:3339:2: ( rule__TemperatureSensosor__CrateTemperatureAssignment_4 )
            // InternalMyDsl.g:3339:3: rule__TemperatureSensosor__CrateTemperatureAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__CrateTemperatureAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__4__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__5"
    // InternalMyDsl.g:3347:1: rule__TemperatureSensosor__Group__5 : rule__TemperatureSensosor__Group__5__Impl rule__TemperatureSensosor__Group__6 ;
    public final void rule__TemperatureSensosor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3351:1: ( rule__TemperatureSensosor__Group__5__Impl rule__TemperatureSensosor__Group__6 )
            // InternalMyDsl.g:3352:2: rule__TemperatureSensosor__Group__5__Impl rule__TemperatureSensosor__Group__6
            {
            pushFollow(FOLLOW_34);
            rule__TemperatureSensosor__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__5"


    // $ANTLR start "rule__TemperatureSensosor__Group__5__Impl"
    // InternalMyDsl.g:3359:1: rule__TemperatureSensosor__Group__5__Impl : ( 'PlantTemperature' ) ;
    public final void rule__TemperatureSensosor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3363:1: ( ( 'PlantTemperature' ) )
            // InternalMyDsl.g:3364:1: ( 'PlantTemperature' )
            {
            // InternalMyDsl.g:3364:1: ( 'PlantTemperature' )
            // InternalMyDsl.g:3365:2: 'PlantTemperature'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureKeyword_5()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__5__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__6"
    // InternalMyDsl.g:3374:1: rule__TemperatureSensosor__Group__6 : rule__TemperatureSensosor__Group__6__Impl rule__TemperatureSensosor__Group__7 ;
    public final void rule__TemperatureSensosor__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3378:1: ( rule__TemperatureSensosor__Group__6__Impl rule__TemperatureSensosor__Group__7 )
            // InternalMyDsl.g:3379:2: rule__TemperatureSensosor__Group__6__Impl rule__TemperatureSensosor__Group__7
            {
            pushFollow(FOLLOW_23);
            rule__TemperatureSensosor__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__6"


    // $ANTLR start "rule__TemperatureSensosor__Group__6__Impl"
    // InternalMyDsl.g:3386:1: rule__TemperatureSensosor__Group__6__Impl : ( ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 ) ) ;
    public final void rule__TemperatureSensosor__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3390:1: ( ( ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 ) ) )
            // InternalMyDsl.g:3391:1: ( ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 ) )
            {
            // InternalMyDsl.g:3391:1: ( ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 ) )
            // InternalMyDsl.g:3392:2: ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 )
            {
             before(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureAssignment_6()); 
            // InternalMyDsl.g:3393:2: ( rule__TemperatureSensosor__PlantTemperatureAssignment_6 )
            // InternalMyDsl.g:3393:3: rule__TemperatureSensosor__PlantTemperatureAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__PlantTemperatureAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__6__Impl"


    // $ANTLR start "rule__TemperatureSensosor__Group__7"
    // InternalMyDsl.g:3401:1: rule__TemperatureSensosor__Group__7 : rule__TemperatureSensosor__Group__7__Impl ;
    public final void rule__TemperatureSensosor__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3405:1: ( rule__TemperatureSensosor__Group__7__Impl )
            // InternalMyDsl.g:3406:2: rule__TemperatureSensosor__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TemperatureSensosor__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__7"


    // $ANTLR start "rule__TemperatureSensosor__Group__7__Impl"
    // InternalMyDsl.g:3412:1: rule__TemperatureSensosor__Group__7__Impl : ( '}' ) ;
    public final void rule__TemperatureSensosor__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3416:1: ( ( '}' ) )
            // InternalMyDsl.g:3417:1: ( '}' )
            {
            // InternalMyDsl.g:3417:1: ( '}' )
            // InternalMyDsl.g:3418:2: '}'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getRightCurlyBracketKeyword_7()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__Group__7__Impl"


    // $ANTLR start "rule__SoilSensor__Group__0"
    // InternalMyDsl.g:3428:1: rule__SoilSensor__Group__0 : rule__SoilSensor__Group__0__Impl rule__SoilSensor__Group__1 ;
    public final void rule__SoilSensor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3432:1: ( rule__SoilSensor__Group__0__Impl rule__SoilSensor__Group__1 )
            // InternalMyDsl.g:3433:2: rule__SoilSensor__Group__0__Impl rule__SoilSensor__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__SoilSensor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__0"


    // $ANTLR start "rule__SoilSensor__Group__0__Impl"
    // InternalMyDsl.g:3440:1: rule__SoilSensor__Group__0__Impl : ( 'SoilSensor' ) ;
    public final void rule__SoilSensor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3444:1: ( ( 'SoilSensor' ) )
            // InternalMyDsl.g:3445:1: ( 'SoilSensor' )
            {
            // InternalMyDsl.g:3445:1: ( 'SoilSensor' )
            // InternalMyDsl.g:3446:2: 'SoilSensor'
            {
             before(grammarAccess.getSoilSensorAccess().getSoilSensorKeyword_0()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getSoilSensorAccess().getSoilSensorKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__0__Impl"


    // $ANTLR start "rule__SoilSensor__Group__1"
    // InternalMyDsl.g:3455:1: rule__SoilSensor__Group__1 : rule__SoilSensor__Group__1__Impl rule__SoilSensor__Group__2 ;
    public final void rule__SoilSensor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3459:1: ( rule__SoilSensor__Group__1__Impl rule__SoilSensor__Group__2 )
            // InternalMyDsl.g:3460:2: rule__SoilSensor__Group__1__Impl rule__SoilSensor__Group__2
            {
            pushFollow(FOLLOW_38);
            rule__SoilSensor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__1"


    // $ANTLR start "rule__SoilSensor__Group__1__Impl"
    // InternalMyDsl.g:3467:1: rule__SoilSensor__Group__1__Impl : ( '{' ) ;
    public final void rule__SoilSensor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3471:1: ( ( '{' ) )
            // InternalMyDsl.g:3472:1: ( '{' )
            {
            // InternalMyDsl.g:3472:1: ( '{' )
            // InternalMyDsl.g:3473:2: '{'
            {
             before(grammarAccess.getSoilSensorAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getSoilSensorAccess().getLeftCurlyBracketKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__1__Impl"


    // $ANTLR start "rule__SoilSensor__Group__2"
    // InternalMyDsl.g:3482:1: rule__SoilSensor__Group__2 : rule__SoilSensor__Group__2__Impl rule__SoilSensor__Group__3 ;
    public final void rule__SoilSensor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3486:1: ( rule__SoilSensor__Group__2__Impl rule__SoilSensor__Group__3 )
            // InternalMyDsl.g:3487:2: rule__SoilSensor__Group__2__Impl rule__SoilSensor__Group__3
            {
            pushFollow(FOLLOW_6);
            rule__SoilSensor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__2"


    // $ANTLR start "rule__SoilSensor__Group__2__Impl"
    // InternalMyDsl.g:3494:1: rule__SoilSensor__Group__2__Impl : ( 'ph' ) ;
    public final void rule__SoilSensor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3498:1: ( ( 'ph' ) )
            // InternalMyDsl.g:3499:1: ( 'ph' )
            {
            // InternalMyDsl.g:3499:1: ( 'ph' )
            // InternalMyDsl.g:3500:2: 'ph'
            {
             before(grammarAccess.getSoilSensorAccess().getPhKeyword_2()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getSoilSensorAccess().getPhKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__2__Impl"


    // $ANTLR start "rule__SoilSensor__Group__3"
    // InternalMyDsl.g:3509:1: rule__SoilSensor__Group__3 : rule__SoilSensor__Group__3__Impl rule__SoilSensor__Group__4 ;
    public final void rule__SoilSensor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3513:1: ( rule__SoilSensor__Group__3__Impl rule__SoilSensor__Group__4 )
            // InternalMyDsl.g:3514:2: rule__SoilSensor__Group__3__Impl rule__SoilSensor__Group__4
            {
            pushFollow(FOLLOW_39);
            rule__SoilSensor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__3"


    // $ANTLR start "rule__SoilSensor__Group__3__Impl"
    // InternalMyDsl.g:3521:1: rule__SoilSensor__Group__3__Impl : ( ( rule__SoilSensor__PhAssignment_3 ) ) ;
    public final void rule__SoilSensor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3525:1: ( ( ( rule__SoilSensor__PhAssignment_3 ) ) )
            // InternalMyDsl.g:3526:1: ( ( rule__SoilSensor__PhAssignment_3 ) )
            {
            // InternalMyDsl.g:3526:1: ( ( rule__SoilSensor__PhAssignment_3 ) )
            // InternalMyDsl.g:3527:2: ( rule__SoilSensor__PhAssignment_3 )
            {
             before(grammarAccess.getSoilSensorAccess().getPhAssignment_3()); 
            // InternalMyDsl.g:3528:2: ( rule__SoilSensor__PhAssignment_3 )
            // InternalMyDsl.g:3528:3: rule__SoilSensor__PhAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__SoilSensor__PhAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getSoilSensorAccess().getPhAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__3__Impl"


    // $ANTLR start "rule__SoilSensor__Group__4"
    // InternalMyDsl.g:3536:1: rule__SoilSensor__Group__4 : rule__SoilSensor__Group__4__Impl rule__SoilSensor__Group__5 ;
    public final void rule__SoilSensor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3540:1: ( rule__SoilSensor__Group__4__Impl rule__SoilSensor__Group__5 )
            // InternalMyDsl.g:3541:2: rule__SoilSensor__Group__4__Impl rule__SoilSensor__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SoilSensor__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__4"


    // $ANTLR start "rule__SoilSensor__Group__4__Impl"
    // InternalMyDsl.g:3548:1: rule__SoilSensor__Group__4__Impl : ( 'SoilMoistureInPercentage' ) ;
    public final void rule__SoilSensor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3552:1: ( ( 'SoilMoistureInPercentage' ) )
            // InternalMyDsl.g:3553:1: ( 'SoilMoistureInPercentage' )
            {
            // InternalMyDsl.g:3553:1: ( 'SoilMoistureInPercentage' )
            // InternalMyDsl.g:3554:2: 'SoilMoistureInPercentage'
            {
             before(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageKeyword_4()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__4__Impl"


    // $ANTLR start "rule__SoilSensor__Group__5"
    // InternalMyDsl.g:3563:1: rule__SoilSensor__Group__5 : rule__SoilSensor__Group__5__Impl rule__SoilSensor__Group__6 ;
    public final void rule__SoilSensor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3567:1: ( rule__SoilSensor__Group__5__Impl rule__SoilSensor__Group__6 )
            // InternalMyDsl.g:3568:2: rule__SoilSensor__Group__5__Impl rule__SoilSensor__Group__6
            {
            pushFollow(FOLLOW_23);
            rule__SoilSensor__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__5"


    // $ANTLR start "rule__SoilSensor__Group__5__Impl"
    // InternalMyDsl.g:3575:1: rule__SoilSensor__Group__5__Impl : ( ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 ) ) ;
    public final void rule__SoilSensor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3579:1: ( ( ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 ) ) )
            // InternalMyDsl.g:3580:1: ( ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 ) )
            {
            // InternalMyDsl.g:3580:1: ( ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 ) )
            // InternalMyDsl.g:3581:2: ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 )
            {
             before(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageAssignment_5()); 
            // InternalMyDsl.g:3582:2: ( rule__SoilSensor__SoilMoistureInPercentageAssignment_5 )
            // InternalMyDsl.g:3582:3: rule__SoilSensor__SoilMoistureInPercentageAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__SoilSensor__SoilMoistureInPercentageAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__5__Impl"


    // $ANTLR start "rule__SoilSensor__Group__6"
    // InternalMyDsl.g:3590:1: rule__SoilSensor__Group__6 : rule__SoilSensor__Group__6__Impl ;
    public final void rule__SoilSensor__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3594:1: ( rule__SoilSensor__Group__6__Impl )
            // InternalMyDsl.g:3595:2: rule__SoilSensor__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SoilSensor__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__6"


    // $ANTLR start "rule__SoilSensor__Group__6__Impl"
    // InternalMyDsl.g:3601:1: rule__SoilSensor__Group__6__Impl : ( '}' ) ;
    public final void rule__SoilSensor__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3605:1: ( ( '}' ) )
            // InternalMyDsl.g:3606:1: ( '}' )
            {
            // InternalMyDsl.g:3606:1: ( '}' )
            // InternalMyDsl.g:3607:2: '}'
            {
             before(grammarAccess.getSoilSensorAccess().getRightCurlyBracketKeyword_6()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getSoilSensorAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__Group__6__Impl"


    // $ANTLR start "rule__Crop__Group__0"
    // InternalMyDsl.g:3617:1: rule__Crop__Group__0 : rule__Crop__Group__0__Impl rule__Crop__Group__1 ;
    public final void rule__Crop__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3621:1: ( rule__Crop__Group__0__Impl rule__Crop__Group__1 )
            // InternalMyDsl.g:3622:2: rule__Crop__Group__0__Impl rule__Crop__Group__1
            {
            pushFollow(FOLLOW_22);
            rule__Crop__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crop__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__0"


    // $ANTLR start "rule__Crop__Group__0__Impl"
    // InternalMyDsl.g:3629:1: rule__Crop__Group__0__Impl : ( () ) ;
    public final void rule__Crop__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3633:1: ( ( () ) )
            // InternalMyDsl.g:3634:1: ( () )
            {
            // InternalMyDsl.g:3634:1: ( () )
            // InternalMyDsl.g:3635:2: ()
            {
             before(grammarAccess.getCropAccess().getCropAction_0()); 
            // InternalMyDsl.g:3636:2: ()
            // InternalMyDsl.g:3636:3: 
            {
            }

             after(grammarAccess.getCropAccess().getCropAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__0__Impl"


    // $ANTLR start "rule__Crop__Group__1"
    // InternalMyDsl.g:3644:1: rule__Crop__Group__1 : rule__Crop__Group__1__Impl rule__Crop__Group__2 ;
    public final void rule__Crop__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3648:1: ( rule__Crop__Group__1__Impl rule__Crop__Group__2 )
            // InternalMyDsl.g:3649:2: rule__Crop__Group__1__Impl rule__Crop__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Crop__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crop__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__1"


    // $ANTLR start "rule__Crop__Group__1__Impl"
    // InternalMyDsl.g:3656:1: rule__Crop__Group__1__Impl : ( 'Crop' ) ;
    public final void rule__Crop__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3660:1: ( ( 'Crop' ) )
            // InternalMyDsl.g:3661:1: ( 'Crop' )
            {
            // InternalMyDsl.g:3661:1: ( 'Crop' )
            // InternalMyDsl.g:3662:2: 'Crop'
            {
             before(grammarAccess.getCropAccess().getCropKeyword_1()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getCropAccess().getCropKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__1__Impl"


    // $ANTLR start "rule__Crop__Group__2"
    // InternalMyDsl.g:3671:1: rule__Crop__Group__2 : rule__Crop__Group__2__Impl rule__Crop__Group__3 ;
    public final void rule__Crop__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3675:1: ( rule__Crop__Group__2__Impl rule__Crop__Group__3 )
            // InternalMyDsl.g:3676:2: rule__Crop__Group__2__Impl rule__Crop__Group__3
            {
            pushFollow(FOLLOW_40);
            rule__Crop__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crop__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__2"


    // $ANTLR start "rule__Crop__Group__2__Impl"
    // InternalMyDsl.g:3683:1: rule__Crop__Group__2__Impl : ( '{' ) ;
    public final void rule__Crop__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3687:1: ( ( '{' ) )
            // InternalMyDsl.g:3688:1: ( '{' )
            {
            // InternalMyDsl.g:3688:1: ( '{' )
            // InternalMyDsl.g:3689:2: '{'
            {
             before(grammarAccess.getCropAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getCropAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__2__Impl"


    // $ANTLR start "rule__Crop__Group__3"
    // InternalMyDsl.g:3698:1: rule__Crop__Group__3 : rule__Crop__Group__3__Impl rule__Crop__Group__4 ;
    public final void rule__Crop__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3702:1: ( rule__Crop__Group__3__Impl rule__Crop__Group__4 )
            // InternalMyDsl.g:3703:2: rule__Crop__Group__3__Impl rule__Crop__Group__4
            {
            pushFollow(FOLLOW_40);
            rule__Crop__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crop__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__3"


    // $ANTLR start "rule__Crop__Group__3__Impl"
    // InternalMyDsl.g:3710:1: rule__Crop__Group__3__Impl : ( ( rule__Crop__Group_3__0 )? ) ;
    public final void rule__Crop__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3714:1: ( ( ( rule__Crop__Group_3__0 )? ) )
            // InternalMyDsl.g:3715:1: ( ( rule__Crop__Group_3__0 )? )
            {
            // InternalMyDsl.g:3715:1: ( ( rule__Crop__Group_3__0 )? )
            // InternalMyDsl.g:3716:2: ( rule__Crop__Group_3__0 )?
            {
             before(grammarAccess.getCropAccess().getGroup_3()); 
            // InternalMyDsl.g:3717:2: ( rule__Crop__Group_3__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==58) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMyDsl.g:3717:3: rule__Crop__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Crop__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCropAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__3__Impl"


    // $ANTLR start "rule__Crop__Group__4"
    // InternalMyDsl.g:3725:1: rule__Crop__Group__4 : rule__Crop__Group__4__Impl ;
    public final void rule__Crop__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3729:1: ( rule__Crop__Group__4__Impl )
            // InternalMyDsl.g:3730:2: rule__Crop__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Crop__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__4"


    // $ANTLR start "rule__Crop__Group__4__Impl"
    // InternalMyDsl.g:3736:1: rule__Crop__Group__4__Impl : ( '}' ) ;
    public final void rule__Crop__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3740:1: ( ( '}' ) )
            // InternalMyDsl.g:3741:1: ( '}' )
            {
            // InternalMyDsl.g:3741:1: ( '}' )
            // InternalMyDsl.g:3742:2: '}'
            {
             before(grammarAccess.getCropAccess().getRightCurlyBracketKeyword_4()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getCropAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group__4__Impl"


    // $ANTLR start "rule__Crop__Group_3__0"
    // InternalMyDsl.g:3752:1: rule__Crop__Group_3__0 : rule__Crop__Group_3__0__Impl rule__Crop__Group_3__1 ;
    public final void rule__Crop__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3756:1: ( rule__Crop__Group_3__0__Impl rule__Crop__Group_3__1 )
            // InternalMyDsl.g:3757:2: rule__Crop__Group_3__0__Impl rule__Crop__Group_3__1
            {
            pushFollow(FOLLOW_41);
            rule__Crop__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Crop__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group_3__0"


    // $ANTLR start "rule__Crop__Group_3__0__Impl"
    // InternalMyDsl.g:3764:1: rule__Crop__Group_3__0__Impl : ( 'Crop' ) ;
    public final void rule__Crop__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3768:1: ( ( 'Crop' ) )
            // InternalMyDsl.g:3769:1: ( 'Crop' )
            {
            // InternalMyDsl.g:3769:1: ( 'Crop' )
            // InternalMyDsl.g:3770:2: 'Crop'
            {
             before(grammarAccess.getCropAccess().getCropKeyword_3_0()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getCropAccess().getCropKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group_3__0__Impl"


    // $ANTLR start "rule__Crop__Group_3__1"
    // InternalMyDsl.g:3779:1: rule__Crop__Group_3__1 : rule__Crop__Group_3__1__Impl ;
    public final void rule__Crop__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3783:1: ( rule__Crop__Group_3__1__Impl )
            // InternalMyDsl.g:3784:2: rule__Crop__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Crop__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group_3__1"


    // $ANTLR start "rule__Crop__Group_3__1__Impl"
    // InternalMyDsl.g:3790:1: rule__Crop__Group_3__1__Impl : ( ( rule__Crop__CropAssignment_3_1 ) ) ;
    public final void rule__Crop__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3794:1: ( ( ( rule__Crop__CropAssignment_3_1 ) ) )
            // InternalMyDsl.g:3795:1: ( ( rule__Crop__CropAssignment_3_1 ) )
            {
            // InternalMyDsl.g:3795:1: ( ( rule__Crop__CropAssignment_3_1 ) )
            // InternalMyDsl.g:3796:2: ( rule__Crop__CropAssignment_3_1 )
            {
             before(grammarAccess.getCropAccess().getCropAssignment_3_1()); 
            // InternalMyDsl.g:3797:2: ( rule__Crop__CropAssignment_3_1 )
            // InternalMyDsl.g:3797:3: rule__Crop__CropAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Crop__CropAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getCropAccess().getCropAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__Group_3__1__Impl"


    // $ANTLR start "rule__EFloat__Group__0"
    // InternalMyDsl.g:3806:1: rule__EFloat__Group__0 : rule__EFloat__Group__0__Impl rule__EFloat__Group__1 ;
    public final void rule__EFloat__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3810:1: ( rule__EFloat__Group__0__Impl rule__EFloat__Group__1 )
            // InternalMyDsl.g:3811:2: rule__EFloat__Group__0__Impl rule__EFloat__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__EFloat__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__0"


    // $ANTLR start "rule__EFloat__Group__0__Impl"
    // InternalMyDsl.g:3818:1: rule__EFloat__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EFloat__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3822:1: ( ( ( '-' )? ) )
            // InternalMyDsl.g:3823:1: ( ( '-' )? )
            {
            // InternalMyDsl.g:3823:1: ( ( '-' )? )
            // InternalMyDsl.g:3824:2: ( '-' )?
            {
             before(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0()); 
            // InternalMyDsl.g:3825:2: ( '-' )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==47) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalMyDsl.g:3825:3: '-'
                    {
                    match(input,47,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__0__Impl"


    // $ANTLR start "rule__EFloat__Group__1"
    // InternalMyDsl.g:3833:1: rule__EFloat__Group__1 : rule__EFloat__Group__1__Impl rule__EFloat__Group__2 ;
    public final void rule__EFloat__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3837:1: ( rule__EFloat__Group__1__Impl rule__EFloat__Group__2 )
            // InternalMyDsl.g:3838:2: rule__EFloat__Group__1__Impl rule__EFloat__Group__2
            {
            pushFollow(FOLLOW_34);
            rule__EFloat__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__1"


    // $ANTLR start "rule__EFloat__Group__1__Impl"
    // InternalMyDsl.g:3845:1: rule__EFloat__Group__1__Impl : ( ( RULE_INT )? ) ;
    public final void rule__EFloat__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3849:1: ( ( ( RULE_INT )? ) )
            // InternalMyDsl.g:3850:1: ( ( RULE_INT )? )
            {
            // InternalMyDsl.g:3850:1: ( ( RULE_INT )? )
            // InternalMyDsl.g:3851:2: ( RULE_INT )?
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1()); 
            // InternalMyDsl.g:3852:2: ( RULE_INT )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==RULE_INT) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalMyDsl.g:3852:3: RULE_INT
                    {
                    match(input,RULE_INT,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__1__Impl"


    // $ANTLR start "rule__EFloat__Group__2"
    // InternalMyDsl.g:3860:1: rule__EFloat__Group__2 : rule__EFloat__Group__2__Impl rule__EFloat__Group__3 ;
    public final void rule__EFloat__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3864:1: ( rule__EFloat__Group__2__Impl rule__EFloat__Group__3 )
            // InternalMyDsl.g:3865:2: rule__EFloat__Group__2__Impl rule__EFloat__Group__3
            {
            pushFollow(FOLLOW_42);
            rule__EFloat__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__2"


    // $ANTLR start "rule__EFloat__Group__2__Impl"
    // InternalMyDsl.g:3872:1: rule__EFloat__Group__2__Impl : ( '.' ) ;
    public final void rule__EFloat__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3876:1: ( ( '.' ) )
            // InternalMyDsl.g:3877:1: ( '.' )
            {
            // InternalMyDsl.g:3877:1: ( '.' )
            // InternalMyDsl.g:3878:2: '.'
            {
             before(grammarAccess.getEFloatAccess().getFullStopKeyword_2()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__2__Impl"


    // $ANTLR start "rule__EFloat__Group__3"
    // InternalMyDsl.g:3887:1: rule__EFloat__Group__3 : rule__EFloat__Group__3__Impl rule__EFloat__Group__4 ;
    public final void rule__EFloat__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3891:1: ( rule__EFloat__Group__3__Impl rule__EFloat__Group__4 )
            // InternalMyDsl.g:3892:2: rule__EFloat__Group__3__Impl rule__EFloat__Group__4
            {
            pushFollow(FOLLOW_43);
            rule__EFloat__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__3"


    // $ANTLR start "rule__EFloat__Group__3__Impl"
    // InternalMyDsl.g:3899:1: rule__EFloat__Group__3__Impl : ( RULE_INT ) ;
    public final void rule__EFloat__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3903:1: ( ( RULE_INT ) )
            // InternalMyDsl.g:3904:1: ( RULE_INT )
            {
            // InternalMyDsl.g:3904:1: ( RULE_INT )
            // InternalMyDsl.g:3905:2: RULE_INT
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__3__Impl"


    // $ANTLR start "rule__EFloat__Group__4"
    // InternalMyDsl.g:3914:1: rule__EFloat__Group__4 : rule__EFloat__Group__4__Impl ;
    public final void rule__EFloat__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3918:1: ( rule__EFloat__Group__4__Impl )
            // InternalMyDsl.g:3919:2: rule__EFloat__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__4"


    // $ANTLR start "rule__EFloat__Group__4__Impl"
    // InternalMyDsl.g:3925:1: rule__EFloat__Group__4__Impl : ( ( rule__EFloat__Group_4__0 )? ) ;
    public final void rule__EFloat__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3929:1: ( ( ( rule__EFloat__Group_4__0 )? ) )
            // InternalMyDsl.g:3930:1: ( ( rule__EFloat__Group_4__0 )? )
            {
            // InternalMyDsl.g:3930:1: ( ( rule__EFloat__Group_4__0 )? )
            // InternalMyDsl.g:3931:2: ( rule__EFloat__Group_4__0 )?
            {
             before(grammarAccess.getEFloatAccess().getGroup_4()); 
            // InternalMyDsl.g:3932:2: ( rule__EFloat__Group_4__0 )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( ((LA23_0>=11 && LA23_0<=12)) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalMyDsl.g:3932:3: rule__EFloat__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EFloat__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__4__Impl"


    // $ANTLR start "rule__EFloat__Group_4__0"
    // InternalMyDsl.g:3941:1: rule__EFloat__Group_4__0 : rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1 ;
    public final void rule__EFloat__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3945:1: ( rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1 )
            // InternalMyDsl.g:3946:2: rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1
            {
            pushFollow(FOLLOW_6);
            rule__EFloat__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__0"


    // $ANTLR start "rule__EFloat__Group_4__0__Impl"
    // InternalMyDsl.g:3953:1: rule__EFloat__Group_4__0__Impl : ( ( rule__EFloat__Alternatives_4_0 ) ) ;
    public final void rule__EFloat__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3957:1: ( ( ( rule__EFloat__Alternatives_4_0 ) ) )
            // InternalMyDsl.g:3958:1: ( ( rule__EFloat__Alternatives_4_0 ) )
            {
            // InternalMyDsl.g:3958:1: ( ( rule__EFloat__Alternatives_4_0 ) )
            // InternalMyDsl.g:3959:2: ( rule__EFloat__Alternatives_4_0 )
            {
             before(grammarAccess.getEFloatAccess().getAlternatives_4_0()); 
            // InternalMyDsl.g:3960:2: ( rule__EFloat__Alternatives_4_0 )
            // InternalMyDsl.g:3960:3: rule__EFloat__Alternatives_4_0
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Alternatives_4_0();

            state._fsp--;


            }

             after(grammarAccess.getEFloatAccess().getAlternatives_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__0__Impl"


    // $ANTLR start "rule__EFloat__Group_4__1"
    // InternalMyDsl.g:3968:1: rule__EFloat__Group_4__1 : rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2 ;
    public final void rule__EFloat__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3972:1: ( rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2 )
            // InternalMyDsl.g:3973:2: rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2
            {
            pushFollow(FOLLOW_6);
            rule__EFloat__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__1"


    // $ANTLR start "rule__EFloat__Group_4__1__Impl"
    // InternalMyDsl.g:3980:1: rule__EFloat__Group_4__1__Impl : ( ( '-' )? ) ;
    public final void rule__EFloat__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3984:1: ( ( ( '-' )? ) )
            // InternalMyDsl.g:3985:1: ( ( '-' )? )
            {
            // InternalMyDsl.g:3985:1: ( ( '-' )? )
            // InternalMyDsl.g:3986:2: ( '-' )?
            {
             before(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1()); 
            // InternalMyDsl.g:3987:2: ( '-' )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==47) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalMyDsl.g:3987:3: '-'
                    {
                    match(input,47,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__1__Impl"


    // $ANTLR start "rule__EFloat__Group_4__2"
    // InternalMyDsl.g:3995:1: rule__EFloat__Group_4__2 : rule__EFloat__Group_4__2__Impl ;
    public final void rule__EFloat__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3999:1: ( rule__EFloat__Group_4__2__Impl )
            // InternalMyDsl.g:4000:2: rule__EFloat__Group_4__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__2"


    // $ANTLR start "rule__EFloat__Group_4__2__Impl"
    // InternalMyDsl.g:4006:1: rule__EFloat__Group_4__2__Impl : ( RULE_INT ) ;
    public final void rule__EFloat__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4010:1: ( ( RULE_INT ) )
            // InternalMyDsl.g:4011:1: ( RULE_INT )
            {
            // InternalMyDsl.g:4011:1: ( RULE_INT )
            // InternalMyDsl.g:4012:2: RULE_INT
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__2__Impl"


    // $ANTLR start "rule__Farm__NameAssignment_1"
    // InternalMyDsl.g:4022:1: rule__Farm__NameAssignment_1 : ( ruleEString ) ;
    public final void rule__Farm__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4026:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4027:2: ( ruleEString )
            {
            // InternalMyDsl.g:4027:2: ( ruleEString )
            // InternalMyDsl.g:4028:3: ruleEString
            {
             before(grammarAccess.getFarmAccess().getNameEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getNameEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__NameAssignment_1"


    // $ANTLR start "rule__Farm__MaxCratesAssignment_4"
    // InternalMyDsl.g:4037:1: rule__Farm__MaxCratesAssignment_4 : ( ruleEInt ) ;
    public final void rule__Farm__MaxCratesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4041:1: ( ( ruleEInt ) )
            // InternalMyDsl.g:4042:2: ( ruleEInt )
            {
            // InternalMyDsl.g:4042:2: ( ruleEInt )
            // InternalMyDsl.g:4043:3: ruleEInt
            {
             before(grammarAccess.getFarmAccess().getMaxCratesEIntParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getMaxCratesEIntParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__MaxCratesAssignment_4"


    // $ANTLR start "rule__Farm__CrateAssignment_5_2"
    // InternalMyDsl.g:4052:1: rule__Farm__CrateAssignment_5_2 : ( ruleCrate ) ;
    public final void rule__Farm__CrateAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4056:1: ( ( ruleCrate ) )
            // InternalMyDsl.g:4057:2: ( ruleCrate )
            {
            // InternalMyDsl.g:4057:2: ( ruleCrate )
            // InternalMyDsl.g:4058:3: ruleCrate
            {
             before(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCrate();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__CrateAssignment_5_2"


    // $ANTLR start "rule__Farm__CrateAssignment_5_3_1"
    // InternalMyDsl.g:4067:1: rule__Farm__CrateAssignment_5_3_1 : ( ruleCrate ) ;
    public final void rule__Farm__CrateAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4071:1: ( ( ruleCrate ) )
            // InternalMyDsl.g:4072:2: ( ruleCrate )
            {
            // InternalMyDsl.g:4072:2: ( ruleCrate )
            // InternalMyDsl.g:4073:3: ruleCrate
            {
             before(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCrate();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__CrateAssignment_5_3_1"


    // $ANTLR start "rule__Farm__DroneAssignment_8"
    // InternalMyDsl.g:4082:1: rule__Farm__DroneAssignment_8 : ( ruleDrone ) ;
    public final void rule__Farm__DroneAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4086:1: ( ( ruleDrone ) )
            // InternalMyDsl.g:4087:2: ( ruleDrone )
            {
            // InternalMyDsl.g:4087:2: ( ruleDrone )
            // InternalMyDsl.g:4088:3: ruleDrone
            {
             before(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleDrone();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__DroneAssignment_8"


    // $ANTLR start "rule__Farm__DroneAssignment_9_1"
    // InternalMyDsl.g:4097:1: rule__Farm__DroneAssignment_9_1 : ( ruleDrone ) ;
    public final void rule__Farm__DroneAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4101:1: ( ( ruleDrone ) )
            // InternalMyDsl.g:4102:2: ( ruleDrone )
            {
            // InternalMyDsl.g:4102:2: ( ruleDrone )
            // InternalMyDsl.g:4103:3: ruleDrone
            {
             before(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDrone();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__DroneAssignment_9_1"


    // $ANTLR start "rule__Farm__CameraAssignment_11_2"
    // InternalMyDsl.g:4112:1: rule__Farm__CameraAssignment_11_2 : ( ruleCamera ) ;
    public final void rule__Farm__CameraAssignment_11_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4116:1: ( ( ruleCamera ) )
            // InternalMyDsl.g:4117:2: ( ruleCamera )
            {
            // InternalMyDsl.g:4117:2: ( ruleCamera )
            // InternalMyDsl.g:4118:3: ruleCamera
            {
             before(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCamera();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__CameraAssignment_11_2"


    // $ANTLR start "rule__Farm__CameraAssignment_11_3_1"
    // InternalMyDsl.g:4127:1: rule__Farm__CameraAssignment_11_3_1 : ( ruleCamera ) ;
    public final void rule__Farm__CameraAssignment_11_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4131:1: ( ( ruleCamera ) )
            // InternalMyDsl.g:4132:2: ( ruleCamera )
            {
            // InternalMyDsl.g:4132:2: ( ruleCamera )
            // InternalMyDsl.g:4133:3: ruleCamera
            {
             before(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCamera();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__CameraAssignment_11_3_1"


    // $ANTLR start "rule__Farm__AiAssignment_12_2"
    // InternalMyDsl.g:4142:1: rule__Farm__AiAssignment_12_2 : ( ruleAI ) ;
    public final void rule__Farm__AiAssignment_12_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4146:1: ( ( ruleAI ) )
            // InternalMyDsl.g:4147:2: ( ruleAI )
            {
            // InternalMyDsl.g:4147:2: ( ruleAI )
            // InternalMyDsl.g:4148:3: ruleAI
            {
             before(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAI();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__AiAssignment_12_2"


    // $ANTLR start "rule__Farm__AiAssignment_12_3_1"
    // InternalMyDsl.g:4157:1: rule__Farm__AiAssignment_12_3_1 : ( ruleAI ) ;
    public final void rule__Farm__AiAssignment_12_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4161:1: ( ( ruleAI ) )
            // InternalMyDsl.g:4162:2: ( ruleAI )
            {
            // InternalMyDsl.g:4162:2: ( ruleAI )
            // InternalMyDsl.g:4163:3: ruleAI
            {
             before(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAI();

            state._fsp--;

             after(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Farm__AiAssignment_12_3_1"


    // $ANTLR start "rule__Crate__IdAssignment_2_1"
    // InternalMyDsl.g:4172:1: rule__Crate__IdAssignment_2_1 : ( ruleEString ) ;
    public final void rule__Crate__IdAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4176:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4177:2: ( ruleEString )
            {
            // InternalMyDsl.g:4177:2: ( ruleEString )
            // InternalMyDsl.g:4178:3: ruleEString
            {
             before(grammarAccess.getCrateAccess().getIdEStringParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getIdEStringParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__IdAssignment_2_1"


    // $ANTLR start "rule__Crate__LightAssignment_5"
    // InternalMyDsl.g:4187:1: rule__Crate__LightAssignment_5 : ( ruleLight ) ;
    public final void rule__Crate__LightAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4191:1: ( ( ruleLight ) )
            // InternalMyDsl.g:4192:2: ( ruleLight )
            {
            // InternalMyDsl.g:4192:2: ( ruleLight )
            // InternalMyDsl.g:4193:3: ruleLight
            {
             before(grammarAccess.getCrateAccess().getLightLightParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleLight();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getLightLightParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__LightAssignment_5"


    // $ANTLR start "rule__Crate__LightAssignment_6_1"
    // InternalMyDsl.g:4202:1: rule__Crate__LightAssignment_6_1 : ( ruleLight ) ;
    public final void rule__Crate__LightAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4206:1: ( ( ruleLight ) )
            // InternalMyDsl.g:4207:2: ( ruleLight )
            {
            // InternalMyDsl.g:4207:2: ( ruleLight )
            // InternalMyDsl.g:4208:3: ruleLight
            {
             before(grammarAccess.getCrateAccess().getLightLightParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLight();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getLightLightParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__LightAssignment_6_1"


    // $ANTLR start "rule__Crate__HumiditysensorAssignment_9"
    // InternalMyDsl.g:4217:1: rule__Crate__HumiditysensorAssignment_9 : ( ruleHumiditySensor ) ;
    public final void rule__Crate__HumiditysensorAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4221:1: ( ( ruleHumiditySensor ) )
            // InternalMyDsl.g:4222:2: ( ruleHumiditySensor )
            {
            // InternalMyDsl.g:4222:2: ( ruleHumiditySensor )
            // InternalMyDsl.g:4223:3: ruleHumiditySensor
            {
             before(grammarAccess.getCrateAccess().getHumiditysensorHumiditySensorParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleHumiditySensor();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getHumiditysensorHumiditySensorParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__HumiditysensorAssignment_9"


    // $ANTLR start "rule__Crate__TemperaturesensorAssignment_11"
    // InternalMyDsl.g:4232:1: rule__Crate__TemperaturesensorAssignment_11 : ( ruleTemperatureSensosor ) ;
    public final void rule__Crate__TemperaturesensorAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4236:1: ( ( ruleTemperatureSensosor ) )
            // InternalMyDsl.g:4237:2: ( ruleTemperatureSensosor )
            {
            // InternalMyDsl.g:4237:2: ( ruleTemperatureSensosor )
            // InternalMyDsl.g:4238:3: ruleTemperatureSensosor
            {
             before(grammarAccess.getCrateAccess().getTemperaturesensorTemperatureSensosorParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleTemperatureSensosor();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getTemperaturesensorTemperatureSensosorParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__TemperaturesensorAssignment_11"


    // $ANTLR start "rule__Crate__SoilsenorAssignment_13"
    // InternalMyDsl.g:4247:1: rule__Crate__SoilsenorAssignment_13 : ( ruleSoilSensor ) ;
    public final void rule__Crate__SoilsenorAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4251:1: ( ( ruleSoilSensor ) )
            // InternalMyDsl.g:4252:2: ( ruleSoilSensor )
            {
            // InternalMyDsl.g:4252:2: ( ruleSoilSensor )
            // InternalMyDsl.g:4253:3: ruleSoilSensor
            {
             before(grammarAccess.getCrateAccess().getSoilsenorSoilSensorParserRuleCall_13_0()); 
            pushFollow(FOLLOW_2);
            ruleSoilSensor();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getSoilsenorSoilSensorParserRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__SoilsenorAssignment_13"


    // $ANTLR start "rule__Crate__CropTypeAssignment_15"
    // InternalMyDsl.g:4262:1: rule__Crate__CropTypeAssignment_15 : ( ruleCrop ) ;
    public final void rule__Crate__CropTypeAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4266:1: ( ( ruleCrop ) )
            // InternalMyDsl.g:4267:2: ( ruleCrop )
            {
            // InternalMyDsl.g:4267:2: ( ruleCrop )
            // InternalMyDsl.g:4268:3: ruleCrop
            {
             before(grammarAccess.getCrateAccess().getCropTypeCropParserRuleCall_15_0()); 
            pushFollow(FOLLOW_2);
            ruleCrop();

            state._fsp--;

             after(grammarAccess.getCrateAccess().getCropTypeCropParserRuleCall_15_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crate__CropTypeAssignment_15"


    // $ANTLR start "rule__Drone__TurnOnAssignment_0"
    // InternalMyDsl.g:4277:1: rule__Drone__TurnOnAssignment_0 : ( ( 'TurnOn' ) ) ;
    public final void rule__Drone__TurnOnAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4281:1: ( ( ( 'TurnOn' ) ) )
            // InternalMyDsl.g:4282:2: ( ( 'TurnOn' ) )
            {
            // InternalMyDsl.g:4282:2: ( ( 'TurnOn' ) )
            // InternalMyDsl.g:4283:3: ( 'TurnOn' )
            {
             before(grammarAccess.getDroneAccess().getTurnOnTurnOnKeyword_0_0()); 
            // InternalMyDsl.g:4284:3: ( 'TurnOn' )
            // InternalMyDsl.g:4285:4: 'TurnOn'
            {
             before(grammarAccess.getDroneAccess().getTurnOnTurnOnKeyword_0_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getDroneAccess().getTurnOnTurnOnKeyword_0_0()); 

            }

             after(grammarAccess.getDroneAccess().getTurnOnTurnOnKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__TurnOnAssignment_0"


    // $ANTLR start "rule__Drone__NameAssignment_2"
    // InternalMyDsl.g:4296:1: rule__Drone__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Drone__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4300:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4301:2: ( ruleEString )
            {
            // InternalMyDsl.g:4301:2: ( ruleEString )
            // InternalMyDsl.g:4302:3: ruleEString
            {
             before(grammarAccess.getDroneAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getDroneAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__NameAssignment_2"


    // $ANTLR start "rule__Drone__DroneMonitoringAssignment_4_1"
    // InternalMyDsl.g:4311:1: rule__Drone__DroneMonitoringAssignment_4_1 : ( ruleFocusArea ) ;
    public final void rule__Drone__DroneMonitoringAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4315:1: ( ( ruleFocusArea ) )
            // InternalMyDsl.g:4316:2: ( ruleFocusArea )
            {
            // InternalMyDsl.g:4316:2: ( ruleFocusArea )
            // InternalMyDsl.g:4317:3: ruleFocusArea
            {
             before(grammarAccess.getDroneAccess().getDroneMonitoringFocusAreaEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleFocusArea();

            state._fsp--;

             after(grammarAccess.getDroneAccess().getDroneMonitoringFocusAreaEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Drone__DroneMonitoringAssignment_4_1"


    // $ANTLR start "rule__Camera__NameAssignment_2"
    // InternalMyDsl.g:4326:1: rule__Camera__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Camera__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4330:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4331:2: ( ruleEString )
            {
            // InternalMyDsl.g:4331:2: ( ruleEString )
            // InternalMyDsl.g:4332:3: ruleEString
            {
             before(grammarAccess.getCameraAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCameraAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__NameAssignment_2"


    // $ANTLR start "rule__Camera__CameraFocusAssignment_4_1"
    // InternalMyDsl.g:4341:1: rule__Camera__CameraFocusAssignment_4_1 : ( ruleFocusArea ) ;
    public final void rule__Camera__CameraFocusAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4345:1: ( ( ruleFocusArea ) )
            // InternalMyDsl.g:4346:2: ( ruleFocusArea )
            {
            // InternalMyDsl.g:4346:2: ( ruleFocusArea )
            // InternalMyDsl.g:4347:3: ruleFocusArea
            {
             before(grammarAccess.getCameraAccess().getCameraFocusFocusAreaEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleFocusArea();

            state._fsp--;

             after(grammarAccess.getCameraAccess().getCameraFocusFocusAreaEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Camera__CameraFocusAssignment_4_1"


    // $ANTLR start "rule__AI__NameAssignment_2"
    // InternalMyDsl.g:4356:1: rule__AI__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__AI__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4360:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4361:2: ( ruleEString )
            {
            // InternalMyDsl.g:4361:2: ( ruleEString )
            // InternalMyDsl.g:4362:3: ruleEString
            {
             before(grammarAccess.getAIAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getAIAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__NameAssignment_2"


    // $ANTLR start "rule__AI__AIMonitoringAssignment_4_1"
    // InternalMyDsl.g:4371:1: rule__AI__AIMonitoringAssignment_4_1 : ( ruleFocusArea ) ;
    public final void rule__AI__AIMonitoringAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4375:1: ( ( ruleFocusArea ) )
            // InternalMyDsl.g:4376:2: ( ruleFocusArea )
            {
            // InternalMyDsl.g:4376:2: ( ruleFocusArea )
            // InternalMyDsl.g:4377:3: ruleFocusArea
            {
             before(grammarAccess.getAIAccess().getAIMonitoringFocusAreaEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleFocusArea();

            state._fsp--;

             after(grammarAccess.getAIAccess().getAIMonitoringFocusAreaEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AI__AIMonitoringAssignment_4_1"


    // $ANTLR start "rule__Light__TurnOnAssignment_0"
    // InternalMyDsl.g:4386:1: rule__Light__TurnOnAssignment_0 : ( ( 'TurnOn' ) ) ;
    public final void rule__Light__TurnOnAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4390:1: ( ( ( 'TurnOn' ) ) )
            // InternalMyDsl.g:4391:2: ( ( 'TurnOn' ) )
            {
            // InternalMyDsl.g:4391:2: ( ( 'TurnOn' ) )
            // InternalMyDsl.g:4392:3: ( 'TurnOn' )
            {
             before(grammarAccess.getLightAccess().getTurnOnTurnOnKeyword_0_0()); 
            // InternalMyDsl.g:4393:3: ( 'TurnOn' )
            // InternalMyDsl.g:4394:4: 'TurnOn'
            {
             before(grammarAccess.getLightAccess().getTurnOnTurnOnKeyword_0_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getLightAccess().getTurnOnTurnOnKeyword_0_0()); 

            }

             after(grammarAccess.getLightAccess().getTurnOnTurnOnKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__TurnOnAssignment_0"


    // $ANTLR start "rule__Light__NameAssignment_2"
    // InternalMyDsl.g:4405:1: rule__Light__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Light__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4409:1: ( ( ruleEString ) )
            // InternalMyDsl.g:4410:2: ( ruleEString )
            {
            // InternalMyDsl.g:4410:2: ( ruleEString )
            // InternalMyDsl.g:4411:3: ruleEString
            {
             before(grammarAccess.getLightAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getLightAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__NameAssignment_2"


    // $ANTLR start "rule__Light__TypeLightAssignment_4_1"
    // InternalMyDsl.g:4420:1: rule__Light__TypeLightAssignment_4_1 : ( ruletypelight ) ;
    public final void rule__Light__TypeLightAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4424:1: ( ( ruletypelight ) )
            // InternalMyDsl.g:4425:2: ( ruletypelight )
            {
            // InternalMyDsl.g:4425:2: ( ruletypelight )
            // InternalMyDsl.g:4426:3: ruletypelight
            {
             before(grammarAccess.getLightAccess().getTypeLightTypelightEnumRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruletypelight();

            state._fsp--;

             after(grammarAccess.getLightAccess().getTypeLightTypelightEnumRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Light__TypeLightAssignment_4_1"


    // $ANTLR start "rule__HumiditySensor__TurnOnAssignment_0"
    // InternalMyDsl.g:4435:1: rule__HumiditySensor__TurnOnAssignment_0 : ( ( 'TurnOn' ) ) ;
    public final void rule__HumiditySensor__TurnOnAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4439:1: ( ( ( 'TurnOn' ) ) )
            // InternalMyDsl.g:4440:2: ( ( 'TurnOn' ) )
            {
            // InternalMyDsl.g:4440:2: ( ( 'TurnOn' ) )
            // InternalMyDsl.g:4441:3: ( 'TurnOn' )
            {
             before(grammarAccess.getHumiditySensorAccess().getTurnOnTurnOnKeyword_0_0()); 
            // InternalMyDsl.g:4442:3: ( 'TurnOn' )
            // InternalMyDsl.g:4443:4: 'TurnOn'
            {
             before(grammarAccess.getHumiditySensorAccess().getTurnOnTurnOnKeyword_0_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getHumiditySensorAccess().getTurnOnTurnOnKeyword_0_0()); 

            }

             after(grammarAccess.getHumiditySensorAccess().getTurnOnTurnOnKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__TurnOnAssignment_0"


    // $ANTLR start "rule__HumiditySensor__HumidityValueInPercentageAssignment_4"
    // InternalMyDsl.g:4454:1: rule__HumiditySensor__HumidityValueInPercentageAssignment_4 : ( ruleEFloat ) ;
    public final void rule__HumiditySensor__HumidityValueInPercentageAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4458:1: ( ( ruleEFloat ) )
            // InternalMyDsl.g:4459:2: ( ruleEFloat )
            {
            // InternalMyDsl.g:4459:2: ( ruleEFloat )
            // InternalMyDsl.g:4460:3: ruleEFloat
            {
             before(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageEFloatParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageEFloatParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HumiditySensor__HumidityValueInPercentageAssignment_4"


    // $ANTLR start "rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0"
    // InternalMyDsl.g:4469:1: rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0 : ( ( 'TemperatureinDegreeCelcius' ) ) ;
    public final void rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4473:1: ( ( ( 'TemperatureinDegreeCelcius' ) ) )
            // InternalMyDsl.g:4474:2: ( ( 'TemperatureinDegreeCelcius' ) )
            {
            // InternalMyDsl.g:4474:2: ( ( 'TemperatureinDegreeCelcius' ) )
            // InternalMyDsl.g:4475:3: ( 'TemperatureinDegreeCelcius' )
            {
             before(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusTemperatureinDegreeCelciusKeyword_0_0()); 
            // InternalMyDsl.g:4476:3: ( 'TemperatureinDegreeCelcius' )
            // InternalMyDsl.g:4477:4: 'TemperatureinDegreeCelcius'
            {
             before(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusTemperatureinDegreeCelciusKeyword_0_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusTemperatureinDegreeCelciusKeyword_0_0()); 

            }

             after(grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusTemperatureinDegreeCelciusKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__TemperatureinDegreeCelciusAssignment_0"


    // $ANTLR start "rule__TemperatureSensosor__CrateTemperatureAssignment_4"
    // InternalMyDsl.g:4488:1: rule__TemperatureSensosor__CrateTemperatureAssignment_4 : ( ruleEFloat ) ;
    public final void rule__TemperatureSensosor__CrateTemperatureAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4492:1: ( ( ruleEFloat ) )
            // InternalMyDsl.g:4493:2: ( ruleEFloat )
            {
            // InternalMyDsl.g:4493:2: ( ruleEFloat )
            // InternalMyDsl.g:4494:3: ruleEFloat
            {
             before(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureEFloatParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureEFloatParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__CrateTemperatureAssignment_4"


    // $ANTLR start "rule__TemperatureSensosor__PlantTemperatureAssignment_6"
    // InternalMyDsl.g:4503:1: rule__TemperatureSensosor__PlantTemperatureAssignment_6 : ( ruleEFloat ) ;
    public final void rule__TemperatureSensosor__PlantTemperatureAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4507:1: ( ( ruleEFloat ) )
            // InternalMyDsl.g:4508:2: ( ruleEFloat )
            {
            // InternalMyDsl.g:4508:2: ( ruleEFloat )
            // InternalMyDsl.g:4509:3: ruleEFloat
            {
             before(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureEFloatParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureEFloatParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TemperatureSensosor__PlantTemperatureAssignment_6"


    // $ANTLR start "rule__SoilSensor__PhAssignment_3"
    // InternalMyDsl.g:4518:1: rule__SoilSensor__PhAssignment_3 : ( ruleEInt ) ;
    public final void rule__SoilSensor__PhAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4522:1: ( ( ruleEInt ) )
            // InternalMyDsl.g:4523:2: ( ruleEInt )
            {
            // InternalMyDsl.g:4523:2: ( ruleEInt )
            // InternalMyDsl.g:4524:3: ruleEInt
            {
             before(grammarAccess.getSoilSensorAccess().getPhEIntParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSoilSensorAccess().getPhEIntParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__PhAssignment_3"


    // $ANTLR start "rule__SoilSensor__SoilMoistureInPercentageAssignment_5"
    // InternalMyDsl.g:4533:1: rule__SoilSensor__SoilMoistureInPercentageAssignment_5 : ( ruleEInt ) ;
    public final void rule__SoilSensor__SoilMoistureInPercentageAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4537:1: ( ( ruleEInt ) )
            // InternalMyDsl.g:4538:2: ( ruleEInt )
            {
            // InternalMyDsl.g:4538:2: ( ruleEInt )
            // InternalMyDsl.g:4539:3: ruleEInt
            {
             before(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageEIntParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageEIntParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SoilSensor__SoilMoistureInPercentageAssignment_5"


    // $ANTLR start "rule__Crop__CropAssignment_3_1"
    // InternalMyDsl.g:4548:1: rule__Crop__CropAssignment_3_1 : ( ruleCropType ) ;
    public final void rule__Crop__CropAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4552:1: ( ( ruleCropType ) )
            // InternalMyDsl.g:4553:2: ( ruleCropType )
            {
            // InternalMyDsl.g:4553:2: ( ruleCropType )
            // InternalMyDsl.g:4554:3: ruleCropType
            {
             before(grammarAccess.getCropAccess().getCropCropTypeEnumRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCropType();

            state._fsp--;

             after(grammarAccess.getCropAccess().getCropCropTypeEnumRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Crop__CropAssignment_3_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000800000000040L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000050000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00000000A0000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000080000002L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000320000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000010800000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000040020000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000001F00000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000100020000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000400020000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0002000020000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x000000000001E000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0800800000000040L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0400000020000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x00000000000E0000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000001800L});

}