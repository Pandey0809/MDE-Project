/**
 */
package smartFarming2.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import smartFarming2.Crop;
import smartFarming2.CropType;
import smartFarming2.SmartFarming2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Crop</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.impl.CropImpl#getCrop <em>Crop</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CropImpl extends MinimalEObjectImpl.Container implements Crop {
	/**
	 * The default value of the '{@link #getCrop() <em>Crop</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrop()
	 * @generated
	 * @ordered
	 */
	protected static final CropType CROP_EDEFAULT = CropType.TOMATO;

	/**
	 * The cached value of the '{@link #getCrop() <em>Crop</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrop()
	 * @generated
	 * @ordered
	 */
	protected CropType crop = CROP_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CropImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarming2Package.Literals.CROP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CropType getCrop() {
		return crop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCrop(CropType newCrop) {
		CropType oldCrop = crop;
		crop = newCrop == null ? CROP_EDEFAULT : newCrop;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.CROP__CROP, oldCrop, crop));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarming2Package.CROP__CROP:
				return getCrop();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarming2Package.CROP__CROP:
				setCrop((CropType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.CROP__CROP:
				setCrop(CROP_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.CROP__CROP:
				return crop != CROP_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Crop: ");
		result.append(crop);
		result.append(')');
		return result.toString();
	}

} //CropImpl
