/**
 */
package smartFarming;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Camera#getCameraFocus <em>Camera Focus</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getCamera()
 * @model
 * @generated
 */
public interface Camera extends Name {
	/**
	 * Returns the value of the '<em><b>Camera Focus</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming.FocusArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera Focus</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #setCameraFocus(FocusArea)
	 * @see smartFarming.SmartFarmingPackage#getCamera_CameraFocus()
	 * @model
	 * @generated
	 */
	FocusArea getCameraFocus();

	/**
	 * Sets the value of the '{@link smartFarming.Camera#getCameraFocus <em>Camera Focus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Camera Focus</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #getCameraFocus()
	 * @generated
	 */
	void setCameraFocus(FocusArea value);

} // Camera
