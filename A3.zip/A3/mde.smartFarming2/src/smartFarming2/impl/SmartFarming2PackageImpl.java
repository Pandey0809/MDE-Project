/**
 */
package smartFarming2.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EGenericType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import smartFarming2.Camera;
import smartFarming2.Crate;
import smartFarming2.CrateSensors;
import smartFarming2.Crateid;
import smartFarming2.Crop;
import smartFarming2.CropType;
import smartFarming2.Drone;
import smartFarming2.Farm;
import smartFarming2.FocusArea;
import smartFarming2.Light;
import smartFarming2.MonitoringOS;
import smartFarming2.Name;
import smartFarming2.SmartFarming2Factory;
import smartFarming2.SmartFarming2Package;
import smartFarming2.typelight;

import smartFarming2.util.SmartFarming2Validator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SmartFarming2PackageImpl extends EPackageImpl implements SmartFarming2Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass farmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass droneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass monitoringOSEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crateSensorsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lightEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cropEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crateidEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum typelightEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum focusAreaEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum cropTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see smartFarming2.SmartFarming2Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private SmartFarming2PackageImpl() {
		super(eNS_URI, SmartFarming2Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link SmartFarming2Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static SmartFarming2Package init() {
		if (isInited) return (SmartFarming2Package)EPackage.Registry.INSTANCE.getEPackage(SmartFarming2Package.eNS_URI);

		// Obtain or create and register package
		Object registeredSmartFarming2Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		SmartFarming2PackageImpl theSmartFarming2Package = registeredSmartFarming2Package instanceof SmartFarming2PackageImpl ? (SmartFarming2PackageImpl)registeredSmartFarming2Package : new SmartFarming2PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theSmartFarming2Package.createPackageContents();

		// Initialize created meta-data
		theSmartFarming2Package.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theSmartFarming2Package,
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return SmartFarming2Validator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theSmartFarming2Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(SmartFarming2Package.eNS_URI, theSmartFarming2Package);
		return theSmartFarming2Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFarm() {
		return farmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Crate() {
		return (EReference)farmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Drone() {
		return (EReference)farmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Camera() {
		return (EReference)farmEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFarm_Os() {
		return (EReference)farmEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFarm_MaxCrates() {
		return (EAttribute)farmEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFarm__IsSpaceaAvailable() {
		return farmEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFarm__SufficientSpace__DiagnosticChain_Map() {
		return farmEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrate() {
		return crateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Light() {
		return (EReference)crateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_Sensors() {
		return (EReference)crateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_CropType() {
		return (EReference)crateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingOS() {
		return (EReference)crateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingDrones() {
		return (EReference)crateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCrate_WorkingCameras() {
		return (EReference)crateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDrone() {
		return droneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrone_TurnOn() {
		return (EAttribute)droneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrone_DroneMonitoring() {
		return (EAttribute)droneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCamera() {
		return cameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_CameraFocus() {
		return (EAttribute)cameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMonitoringOS() {
		return monitoringOSEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMonitoringOS_OSfocusArea() {
		return (EAttribute)monitoringOSEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrateSensors() {
		return crateSensorsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_TemperatureinDegreeCelcius() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_CrateTemperature() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_PlantTemperature() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_Ph() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_SoilMoistureInPercentage() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateSensors_HumidityValueInPercentage() {
		return (EAttribute)crateSensorsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__ArePlantsAlive() {
		return crateSensorsEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__IsSoiltooBasic__DiagnosticChain_Map() {
		return crateSensorsEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__IsHumiditytooless__DiagnosticChain_Map() {
		return crateSensorsEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__IsHumiditytoomuch__DiagnosticChain_Map() {
		return crateSensorsEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__IsSoiltooAcidic__DiagnosticChain_Map() {
		return crateSensorsEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCrateSensors__ArePlantsAlive__DiagnosticChain_Map() {
		return crateSensorsEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLight() {
		return lightEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLight_TypeLight() {
		return (EAttribute)lightEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLight_TurnOn() {
		return (EAttribute)lightEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getName_() {
		return nameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getName_Name() {
		return (EAttribute)nameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrop() {
		return cropEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrop_Crop() {
		return (EAttribute)cropEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCrateid() {
		return crateidEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCrateid_Id() {
		return (EAttribute)crateidEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum gettypelight() {
		return typelightEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getFocusArea() {
		return focusAreaEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCropType() {
		return cropTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarming2Factory getSmartFarming2Factory() {
		return (SmartFarming2Factory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		farmEClass = createEClass(FARM);
		createEReference(farmEClass, FARM__CRATE);
		createEReference(farmEClass, FARM__DRONE);
		createEReference(farmEClass, FARM__CAMERA);
		createEReference(farmEClass, FARM__OS);
		createEAttribute(farmEClass, FARM__MAX_CRATES);
		createEOperation(farmEClass, FARM___IS_SPACEA_AVAILABLE);
		createEOperation(farmEClass, FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP);

		crateEClass = createEClass(CRATE);
		createEReference(crateEClass, CRATE__LIGHT);
		createEReference(crateEClass, CRATE__SENSORS);
		createEReference(crateEClass, CRATE__CROP_TYPE);
		createEReference(crateEClass, CRATE__WORKING_OS);
		createEReference(crateEClass, CRATE__WORKING_DRONES);
		createEReference(crateEClass, CRATE__WORKING_CAMERAS);

		droneEClass = createEClass(DRONE);
		createEAttribute(droneEClass, DRONE__TURN_ON);
		createEAttribute(droneEClass, DRONE__DRONE_MONITORING);

		cameraEClass = createEClass(CAMERA);
		createEAttribute(cameraEClass, CAMERA__CAMERA_FOCUS);

		monitoringOSEClass = createEClass(MONITORING_OS);
		createEAttribute(monitoringOSEClass, MONITORING_OS__OSFOCUS_AREA);

		crateSensorsEClass = createEClass(CRATE_SENSORS);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__TEMPERATUREIN_DEGREE_CELCIUS);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__CRATE_TEMPERATURE);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__PLANT_TEMPERATURE);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__PH);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__SOIL_MOISTURE_IN_PERCENTAGE);
		createEAttribute(crateSensorsEClass, CRATE_SENSORS__HUMIDITY_VALUE_IN_PERCENTAGE);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___ARE_PLANTS_ALIVE);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___IS_SOILTOO_BASIC__DIAGNOSTICCHAIN_MAP);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___IS_HUMIDITYTOOLESS__DIAGNOSTICCHAIN_MAP);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___IS_HUMIDITYTOOMUCH__DIAGNOSTICCHAIN_MAP);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___IS_SOILTOO_ACIDIC__DIAGNOSTICCHAIN_MAP);
		createEOperation(crateSensorsEClass, CRATE_SENSORS___ARE_PLANTS_ALIVE__DIAGNOSTICCHAIN_MAP);

		lightEClass = createEClass(LIGHT);
		createEAttribute(lightEClass, LIGHT__TYPE_LIGHT);
		createEAttribute(lightEClass, LIGHT__TURN_ON);

		nameEClass = createEClass(NAME);
		createEAttribute(nameEClass, NAME__NAME);

		cropEClass = createEClass(CROP);
		createEAttribute(cropEClass, CROP__CROP);

		crateidEClass = createEClass(CRATEID);
		createEAttribute(crateidEClass, CRATEID__ID);

		// Create enums
		typelightEEnum = createEEnum(TYPELIGHT);
		focusAreaEEnum = createEEnum(FOCUS_AREA);
		cropTypeEEnum = createEEnum(CROP_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		farmEClass.getESuperTypes().add(this.getName_());
		crateEClass.getESuperTypes().add(this.getCrateid());
		droneEClass.getESuperTypes().add(this.getName_());
		cameraEClass.getESuperTypes().add(this.getName_());
		monitoringOSEClass.getESuperTypes().add(this.getName_());
		lightEClass.getESuperTypes().add(this.getName_());

		// Initialize classes, features, and operations; add parameters
		initEClass(farmEClass, Farm.class, "Farm", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFarm_Crate(), this.getCrate(), null, "crate", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Drone(), this.getDrone(), null, "drone", null, 1, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Camera(), this.getCamera(), null, "camera", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFarm_Os(), this.getMonitoringOS(), null, "os", null, 0, -1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFarm_MaxCrates(), ecorePackage.getEInt(), "MaxCrates", null, 1, 1, Farm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getFarm__IsSpaceaAvailable(), ecorePackage.getEBooleanObject(), "isSpaceaAvailable", 0, 1, IS_UNIQUE, IS_ORDERED);

		EOperation op = initEOperation(getFarm__SufficientSpace__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "SufficientSpace", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		EGenericType g1 = createEGenericType(ecorePackage.getEMap());
		EGenericType g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(crateEClass, Crate.class, "Crate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCrate_Light(), this.getLight(), null, "light", null, 1, -1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_Sensors(), this.getCrateSensors(), null, "sensors", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_CropType(), this.getCrop(), null, "CropType", null, 1, 1, Crate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCrate_WorkingOS(), this.getMonitoringOS(), null, "workingOS", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);
		initEReference(getCrate_WorkingDrones(), this.getDrone(), null, "workingDrones", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);
		initEReference(getCrate_WorkingCameras(), this.getCamera(), null, "workingCameras", null, 0, -1, Crate.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, !IS_ORDERED);

		initEClass(droneEClass, Drone.class, "Drone", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDrone_TurnOn(), ecorePackage.getEBoolean(), "TurnOn", null, 1, 1, Drone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDrone_DroneMonitoring(), this.getFocusArea(), "DroneMonitoring", null, 0, 1, Drone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cameraEClass, Camera.class, "Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCamera_CameraFocus(), this.getFocusArea(), "CameraFocus", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(monitoringOSEClass, MonitoringOS.class, "MonitoringOS", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMonitoringOS_OSfocusArea(), this.getFocusArea(), "OSfocusArea", null, 0, 1, MonitoringOS.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(crateSensorsEClass, CrateSensors.class, "CrateSensors", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCrateSensors_TemperatureinDegreeCelcius(), ecorePackage.getEBoolean(), "TemperatureinDegreeCelcius", null, 1, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCrateSensors_CrateTemperature(), ecorePackage.getEFloat(), "CrateTemperature", null, 1, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCrateSensors_PlantTemperature(), ecorePackage.getEFloat(), "PlantTemperature", null, 1, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCrateSensors_Ph(), ecorePackage.getEInt(), "ph", null, 1, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCrateSensors_SoilMoistureInPercentage(), ecorePackage.getEInt(), "SoilMoistureInPercentage", null, 1, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCrateSensors_HumidityValueInPercentage(), ecorePackage.getEFloat(), "HumidityValueInPercentage", null, 0, 1, CrateSensors.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getCrateSensors__ArePlantsAlive(), ecorePackage.getEBooleanObject(), "arePlantsAlive", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getCrateSensors__IsSoiltooBasic__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isSoiltooBasic", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getCrateSensors__IsHumiditytooless__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isHumiditytooless", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getCrateSensors__IsHumiditytoomuch__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isHumiditytoomuch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getCrateSensors__IsSoiltooAcidic__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "isSoiltooAcidic", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getCrateSensors__ArePlantsAlive__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "arePlantsAlive", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(lightEClass, Light.class, "Light", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLight_TypeLight(), this.gettypelight(), "TypeLight", null, 0, 1, Light.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLight_TurnOn(), ecorePackage.getEBoolean(), "TurnOn", null, 1, 1, Light.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(nameEClass, Name.class, "Name", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getName_Name(), ecorePackage.getEString(), "name", null, 1, 1, Name.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cropEClass, Crop.class, "Crop", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCrop_Crop(), this.getCropType(), "Crop", null, 0, 1, Crop.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(crateidEClass, Crateid.class, "Crateid", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCrateid_Id(), ecorePackage.getEString(), "id", null, 0, 1, Crateid.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(typelightEEnum, typelight.class, "typelight");
		addEEnumLiteral(typelightEEnum, typelight.UVLIGHT);
		addEEnumLiteral(typelightEEnum, typelight.BLUE_LIGHT);
		addEEnumLiteral(typelightEEnum, typelight.RED_LIGHT);
		addEEnumLiteral(typelightEEnum, typelight.GREEN_LIGHT);

		initEEnum(focusAreaEEnum, FocusArea.class, "FocusArea");
		addEEnumLiteral(focusAreaEEnum, FocusArea.CRATES);
		addEEnumLiteral(focusAreaEEnum, FocusArea.PLANTS);
		addEEnumLiteral(focusAreaEEnum, FocusArea.CAMERAS);
		addEEnumLiteral(focusAreaEEnum, FocusArea.DRONES);
		addEEnumLiteral(focusAreaEEnum, FocusArea.SENSORS);

		initEEnum(cropTypeEEnum, CropType.class, "CropType");
		addEEnumLiteral(cropTypeEEnum, CropType.TOMATO);
		addEEnumLiteral(cropTypeEEnum, CropType.CABBAGE);
		addEEnumLiteral(cropTypeEEnum, CropType.POTATO);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// http://www.eclipse.org/OCL/Collection
		createCollectionAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation
		  (this,
		   source,
		   new String[] {
		   });
		addAnnotation
		  (farmEClass,
		   source,
		   new String[] {
			   "constraints", "SufficientSpace"
		   });
		addAnnotation
		  (crateSensorsEClass,
		   source,
		   new String[] {
			   "constraints", "arePlantsAlive"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation
		  (getFarm__IsSpaceaAvailable(),
		   source,
		   new String[] {
			   "body", " self.MaxCrates>=crate->size()"
		   });
		addAnnotation
		  (getFarm__SufficientSpace__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.MaxCrates>=crate->size()"
		   });
		addAnnotation
		  (getCrateSensors__ArePlantsAlive(),
		   source,
		   new String[] {
			   "body", "self.PlantTemperature<=26"
		   });
		addAnnotation
		  (getCrateSensors__IsSoiltooBasic__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.ph<=10"
		   });
		addAnnotation
		  (getCrateSensors__IsHumiditytooless__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.HumidityValueInPercentage>=50"
		   });
		addAnnotation
		  (getCrateSensors__IsHumiditytoomuch__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.HumidityValueInPercentage<=90"
		   });
		addAnnotation
		  (getCrateSensors__IsSoiltooAcidic__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.ph>=4"
		   });
		addAnnotation
		  (getCrateSensors__ArePlantsAlive__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "\n\t\t\tself.CrateTemperature>=self.PlantTemperature"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Collection</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createCollectionAnnotations() {
		String source = "http://www.eclipse.org/OCL/Collection";
		addAnnotation
		  (getCrate_WorkingOS(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
		addAnnotation
		  (getCrate_WorkingDrones(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
		addAnnotation
		  (getCrate_WorkingCameras(),
		   source,
		   new String[] {
			   "nullFree", "false"
		   });
	}

} //SmartFarming2PackageImpl
