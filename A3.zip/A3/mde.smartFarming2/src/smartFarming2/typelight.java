/**
 */
package smartFarming2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>typelight</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see smartFarming2.SmartFarming2Package#gettypelight()
 * @model
 * @generated
 */
public enum typelight implements Enumerator {
	/**
	 * The '<em><b>UVlight</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UVLIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	UVLIGHT(1, "UVlight", "UVlight"),

	/**
	 * The '<em><b>Blue Light</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BLUE_LIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	BLUE_LIGHT(2, "BlueLight", "BlueLight"),

	/**
	 * The '<em><b>Red Light</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RED_LIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	RED_LIGHT(3, "RedLight", "RedLight"),

	/**
	 * The '<em><b>Green Light</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GREEN_LIGHT_VALUE
	 * @generated
	 * @ordered
	 */
	GREEN_LIGHT(0, "GreenLight", "GreenLight");

	/**
	 * The '<em><b>UVlight</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UVLIGHT
	 * @model name="UVlight"
	 * @generated
	 * @ordered
	 */
	public static final int UVLIGHT_VALUE = 1;

	/**
	 * The '<em><b>Blue Light</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BLUE_LIGHT
	 * @model name="BlueLight"
	 * @generated
	 * @ordered
	 */
	public static final int BLUE_LIGHT_VALUE = 2;

	/**
	 * The '<em><b>Red Light</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RED_LIGHT
	 * @model name="RedLight"
	 * @generated
	 * @ordered
	 */
	public static final int RED_LIGHT_VALUE = 3;

	/**
	 * The '<em><b>Green Light</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GREEN_LIGHT
	 * @model name="GreenLight"
	 * @generated
	 * @ordered
	 */
	public static final int GREEN_LIGHT_VALUE = 0;

	/**
	 * An array of all the '<em><b>typelight</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final typelight[] VALUES_ARRAY =
		new typelight[] {
			UVLIGHT,
			BLUE_LIGHT,
			RED_LIGHT,
			GREEN_LIGHT,
		};

	/**
	 * A public read-only list of all the '<em><b>typelight</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<typelight> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>typelight</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static typelight get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			typelight result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>typelight</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static typelight getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			typelight result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>typelight</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static typelight get(int value) {
		switch (value) {
			case UVLIGHT_VALUE: return UVLIGHT;
			case BLUE_LIGHT_VALUE: return BLUE_LIGHT;
			case RED_LIGHT_VALUE: return RED_LIGHT;
			case GREEN_LIGHT_VALUE: return GREEN_LIGHT;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private typelight(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //typelight
