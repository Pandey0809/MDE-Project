/**
 */
package smartFarming.util;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import smartFarming.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see smartFarming.SmartFarmingPackage
 * @generated
 */
public class SmartFarmingValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final SmartFarmingValidator INSTANCE = new SmartFarmingValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "smartFarming";

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Sufficient Space' of 'Farm'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int FARM__SUFFICIENT_SPACE = 1;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Are Plants Alive' of 'Temperature Sensosor'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int TEMPERATURE_SENSOSOR__ARE_PLANTS_ALIVE = 2;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Soiltoo Acidic' of 'Soil Sensor'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int SOIL_SENSOR__IS_SOILTOO_ACIDIC = 3;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Soiltoo Basic' of 'Soil Sensor'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int SOIL_SENSOR__IS_SOILTOO_BASIC = 4;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Humiditytooless' of 'Humidity Sensor'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int HUMIDITY_SENSOR__IS_HUMIDITYTOOLESS = 5;

	/**
	 * The {@link org.eclipse.emf.common.util.Diagnostic#getCode() code} for constraint 'Is Humiditytoomuch' of 'Humidity Sensor'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final int HUMIDITY_SENSOR__IS_HUMIDITYTOOMUCH = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 6;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartFarmingValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return SmartFarmingPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case SmartFarmingPackage.FARM:
				return validateFarm((Farm)value, diagnostics, context);
			case SmartFarmingPackage.CRATE:
				return validateCrate((Crate)value, diagnostics, context);
			case SmartFarmingPackage.DRONE:
				return validateDrone((Drone)value, diagnostics, context);
			case SmartFarmingPackage.CAMERA:
				return validateCamera((Camera)value, diagnostics, context);
			case SmartFarmingPackage.AI:
				return validateAI((AI)value, diagnostics, context);
			case SmartFarmingPackage.TEMPERATURE_SENSOSOR:
				return validateTemperatureSensosor((TemperatureSensosor)value, diagnostics, context);
			case SmartFarmingPackage.SOIL_SENSOR:
				return validateSoilSensor((SoilSensor)value, diagnostics, context);
			case SmartFarmingPackage.HUMIDITY_SENSOR:
				return validateHumiditySensor((HumiditySensor)value, diagnostics, context);
			case SmartFarmingPackage.LIGHT:
				return validateLight((Light)value, diagnostics, context);
			case SmartFarmingPackage.NAME:
				return validateName((Name)value, diagnostics, context);
			case SmartFarmingPackage.CROP:
				return validateCrop((Crop)value, diagnostics, context);
			case SmartFarmingPackage.CRATEID:
				return validateCrateid((Crateid)value, diagnostics, context);
			case SmartFarmingPackage.TYPELIGHT:
				return validatetypelight((typelight)value, diagnostics, context);
			case SmartFarmingPackage.FOCUS_AREA:
				return validateFocusArea((FocusArea)value, diagnostics, context);
			case SmartFarmingPackage.CROP_TYPE:
				return validateCropType((CropType)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFarm(Farm farm, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(farm, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(farm, diagnostics, context);
		if (result || diagnostics != null) result &= validateFarm_SufficientSpace(farm, diagnostics, context);
		return result;
	}

	/**
	 * Validates the SufficientSpace constraint of '<em>Farm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFarm_SufficientSpace(Farm farm, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return farm.SufficientSpace(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrate(Crate crate, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crate, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDrone(Drone drone, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(drone, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCamera(Camera camera, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(camera, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAI(AI ai, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(ai, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTemperatureSensosor(TemperatureSensosor temperatureSensosor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(temperatureSensosor, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(temperatureSensosor, diagnostics, context);
		if (result || diagnostics != null) result &= validateTemperatureSensosor_arePlantsAlive(temperatureSensosor, diagnostics, context);
		return result;
	}

	/**
	 * Validates the arePlantsAlive constraint of '<em>Temperature Sensosor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTemperatureSensosor_arePlantsAlive(TemperatureSensosor temperatureSensosor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return temperatureSensosor.arePlantsAlive(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSoilSensor(SoilSensor soilSensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(soilSensor, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validateSoilSensor_isSoiltooBasic(soilSensor, diagnostics, context);
		if (result || diagnostics != null) result &= validateSoilSensor_isSoiltooAcidic(soilSensor, diagnostics, context);
		return result;
	}

	/**
	 * Validates the isSoiltooBasic constraint of '<em>Soil Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSoilSensor_isSoiltooBasic(SoilSensor soilSensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return soilSensor.isSoiltooBasic(diagnostics, context);
	}

	/**
	 * Validates the isSoiltooAcidic constraint of '<em>Soil Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSoilSensor_isSoiltooAcidic(SoilSensor soilSensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return soilSensor.isSoiltooAcidic(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHumiditySensor(HumiditySensor humiditySensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(humiditySensor, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validateHumiditySensor_isHumiditytoomuch(humiditySensor, diagnostics, context);
		if (result || diagnostics != null) result &= validateHumiditySensor_isHumiditytooless(humiditySensor, diagnostics, context);
		return result;
	}

	/**
	 * Validates the isHumiditytoomuch constraint of '<em>Humidity Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHumiditySensor_isHumiditytoomuch(HumiditySensor humiditySensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return humiditySensor.isHumiditytoomuch(diagnostics, context);
	}

	/**
	 * Validates the isHumiditytooless constraint of '<em>Humidity Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHumiditySensor_isHumiditytooless(HumiditySensor humiditySensor, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return humiditySensor.isHumiditytooless(diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateLight(Light light, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(light, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateName(Name name, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(name, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrop(Crop crop, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crop, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCrateid(Crateid crateid, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crateid, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatetypelight(typelight typelight, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFocusArea(FocusArea focusArea, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCropType(CropType cropType, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //SmartFarmingValidator
