/**
 */
package smartFarming.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.IdResolver;

import org.eclipse.ocl.pivot.ids.IdResolver.IdResolverExtension;

import org.eclipse.ocl.pivot.library.classifier.ClassifierAllInstancesOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;

import org.eclipse.ocl.pivot.values.SetValue;

import smartFarming.AI;
import smartFarming.Camera;
import smartFarming.Crate;
import smartFarming.Crop;
import smartFarming.Drone;
import smartFarming.HumiditySensor;
import smartFarming.Light;
import smartFarming.SmartFarmingPackage;
import smartFarming.SmartFarmingTables;
import smartFarming.SoilSensor;
import smartFarming.TemperatureSensosor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.CrateImpl#getLight <em>Light</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getHumiditysensor <em>Humiditysensor</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getTemperaturesensor <em>Temperaturesensor</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getSoilsenor <em>Soilsenor</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getCropType <em>Crop Type</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getWorkingAI <em>Working AI</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getWorkingDrones <em>Working Drones</em>}</li>
 *   <li>{@link smartFarming.impl.CrateImpl#getWorkingCameras <em>Working Cameras</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CrateImpl extends CrateidImpl implements Crate {
	/**
	 * The cached value of the '{@link #getLight() <em>Light</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLight()
	 * @generated
	 * @ordered
	 */
	protected EList<Light> light;

	/**
	 * The cached value of the '{@link #getHumiditysensor() <em>Humiditysensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHumiditysensor()
	 * @generated
	 * @ordered
	 */
	protected HumiditySensor humiditysensor;

	/**
	 * The cached value of the '{@link #getTemperaturesensor() <em>Temperaturesensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemperaturesensor()
	 * @generated
	 * @ordered
	 */
	protected TemperatureSensosor temperaturesensor;

	/**
	 * The cached value of the '{@link #getSoilsenor() <em>Soilsenor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoilsenor()
	 * @generated
	 * @ordered
	 */
	protected SoilSensor soilsenor;

	/**
	 * The cached value of the '{@link #getCropType() <em>Crop Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCropType()
	 * @generated
	 * @ordered
	 */
	protected Crop cropType;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CrateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.CRATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Light> getLight() {
		if (light == null) {
			light = new EObjectContainmentEList<Light>(Light.class, this, SmartFarmingPackage.CRATE__LIGHT);
		}
		return light;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HumiditySensor getHumiditysensor() {
		return humiditysensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetHumiditysensor(HumiditySensor newHumiditysensor, NotificationChain msgs) {
		HumiditySensor oldHumiditysensor = humiditysensor;
		humiditysensor = newHumiditysensor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__HUMIDITYSENSOR, oldHumiditysensor, newHumiditysensor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHumiditysensor(HumiditySensor newHumiditysensor) {
		if (newHumiditysensor != humiditysensor) {
			NotificationChain msgs = null;
			if (humiditysensor != null)
				msgs = ((InternalEObject)humiditysensor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__HUMIDITYSENSOR, null, msgs);
			if (newHumiditysensor != null)
				msgs = ((InternalEObject)newHumiditysensor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__HUMIDITYSENSOR, null, msgs);
			msgs = basicSetHumiditysensor(newHumiditysensor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__HUMIDITYSENSOR, newHumiditysensor, newHumiditysensor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TemperatureSensosor getTemperaturesensor() {
		return temperaturesensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTemperaturesensor(TemperatureSensosor newTemperaturesensor, NotificationChain msgs) {
		TemperatureSensosor oldTemperaturesensor = temperaturesensor;
		temperaturesensor = newTemperaturesensor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__TEMPERATURESENSOR, oldTemperaturesensor, newTemperaturesensor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemperaturesensor(TemperatureSensosor newTemperaturesensor) {
		if (newTemperaturesensor != temperaturesensor) {
			NotificationChain msgs = null;
			if (temperaturesensor != null)
				msgs = ((InternalEObject)temperaturesensor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__TEMPERATURESENSOR, null, msgs);
			if (newTemperaturesensor != null)
				msgs = ((InternalEObject)newTemperaturesensor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__TEMPERATURESENSOR, null, msgs);
			msgs = basicSetTemperaturesensor(newTemperaturesensor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__TEMPERATURESENSOR, newTemperaturesensor, newTemperaturesensor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SoilSensor getSoilsenor() {
		return soilsenor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSoilsenor(SoilSensor newSoilsenor, NotificationChain msgs) {
		SoilSensor oldSoilsenor = soilsenor;
		soilsenor = newSoilsenor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__SOILSENOR, oldSoilsenor, newSoilsenor);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSoilsenor(SoilSensor newSoilsenor) {
		if (newSoilsenor != soilsenor) {
			NotificationChain msgs = null;
			if (soilsenor != null)
				msgs = ((InternalEObject)soilsenor).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__SOILSENOR, null, msgs);
			if (newSoilsenor != null)
				msgs = ((InternalEObject)newSoilsenor).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__SOILSENOR, null, msgs);
			msgs = basicSetSoilsenor(newSoilsenor, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__SOILSENOR, newSoilsenor, newSoilsenor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Crop getCropType() {
		return cropType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCropType(Crop newCropType, NotificationChain msgs) {
		Crop oldCropType = cropType;
		cropType = newCropType;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__CROP_TYPE, oldCropType, newCropType);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCropType(Crop newCropType) {
		if (newCropType != cropType) {
			NotificationChain msgs = null;
			if (cropType != null)
				msgs = ((InternalEObject)cropType).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__CROP_TYPE, null, msgs);
			if (newCropType != null)
				msgs = ((InternalEObject)newCropType).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.CRATE__CROP_TYPE, null, msgs);
			msgs = basicSetCropType(newCropType, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CRATE__CROP_TYPE, newCropType, newCropType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AI> getWorkingAI() {
		/**
		 * AI.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming_c_c_AI_0 = idResolver.getClass(SmartFarmingTables.CLSSid_AI, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarmingTables.SET_CLSSid_AI, TYP_smartFarming_c_c_AI_0);
		final /*@NonInvalid*/ List<AI> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(AI.class, allInstances);
		return (EList<AI>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drone> getWorkingDrones() {
		/**
		 * Drone.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming_c_c_Drone_0 = idResolver.getClass(SmartFarmingTables.CLSSid_Drone, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarmingTables.SET_CLSSid_Drone, TYP_smartFarming_c_c_Drone_0);
		final /*@NonInvalid*/ List<Drone> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(Drone.class, allInstances);
		return (EList<Drone>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Camera> getWorkingCameras() {
		/**
		 * Camera.allInstances()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_smartFarming_c_c_Camera_0 = idResolver.getClass(SmartFarmingTables.CLSSid_Camera, null);
		final /*@NonInvalid*/ SetValue allInstances = ClassifierAllInstancesOperation.INSTANCE.evaluate(executor, SmartFarmingTables.SET_CLSSid_Camera, TYP_smartFarming_c_c_Camera_0);
		final /*@NonInvalid*/ List<Camera> ECORE_allInstances = ((IdResolverExtension)idResolver).ecoreValueOfAll(Camera.class, allInstances);
		return (EList<Camera>)ECORE_allInstances;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmartFarmingPackage.CRATE__LIGHT:
				return ((InternalEList<?>)getLight()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.CRATE__HUMIDITYSENSOR:
				return basicSetHumiditysensor(null, msgs);
			case SmartFarmingPackage.CRATE__TEMPERATURESENSOR:
				return basicSetTemperaturesensor(null, msgs);
			case SmartFarmingPackage.CRATE__SOILSENOR:
				return basicSetSoilsenor(null, msgs);
			case SmartFarmingPackage.CRATE__CROP_TYPE:
				return basicSetCropType(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.CRATE__LIGHT:
				return getLight();
			case SmartFarmingPackage.CRATE__HUMIDITYSENSOR:
				return getHumiditysensor();
			case SmartFarmingPackage.CRATE__TEMPERATURESENSOR:
				return getTemperaturesensor();
			case SmartFarmingPackage.CRATE__SOILSENOR:
				return getSoilsenor();
			case SmartFarmingPackage.CRATE__CROP_TYPE:
				return getCropType();
			case SmartFarmingPackage.CRATE__WORKING_AI:
				return getWorkingAI();
			case SmartFarmingPackage.CRATE__WORKING_DRONES:
				return getWorkingDrones();
			case SmartFarmingPackage.CRATE__WORKING_CAMERAS:
				return getWorkingCameras();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.CRATE__LIGHT:
				getLight().clear();
				getLight().addAll((Collection<? extends Light>)newValue);
				return;
			case SmartFarmingPackage.CRATE__HUMIDITYSENSOR:
				setHumiditysensor((HumiditySensor)newValue);
				return;
			case SmartFarmingPackage.CRATE__TEMPERATURESENSOR:
				setTemperaturesensor((TemperatureSensosor)newValue);
				return;
			case SmartFarmingPackage.CRATE__SOILSENOR:
				setSoilsenor((SoilSensor)newValue);
				return;
			case SmartFarmingPackage.CRATE__CROP_TYPE:
				setCropType((Crop)newValue);
				return;
			case SmartFarmingPackage.CRATE__WORKING_AI:
				getWorkingAI().clear();
				getWorkingAI().addAll((Collection<? extends AI>)newValue);
				return;
			case SmartFarmingPackage.CRATE__WORKING_DRONES:
				getWorkingDrones().clear();
				getWorkingDrones().addAll((Collection<? extends Drone>)newValue);
				return;
			case SmartFarmingPackage.CRATE__WORKING_CAMERAS:
				getWorkingCameras().clear();
				getWorkingCameras().addAll((Collection<? extends Camera>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.CRATE__LIGHT:
				getLight().clear();
				return;
			case SmartFarmingPackage.CRATE__HUMIDITYSENSOR:
				setHumiditysensor((HumiditySensor)null);
				return;
			case SmartFarmingPackage.CRATE__TEMPERATURESENSOR:
				setTemperaturesensor((TemperatureSensosor)null);
				return;
			case SmartFarmingPackage.CRATE__SOILSENOR:
				setSoilsenor((SoilSensor)null);
				return;
			case SmartFarmingPackage.CRATE__CROP_TYPE:
				setCropType((Crop)null);
				return;
			case SmartFarmingPackage.CRATE__WORKING_AI:
				getWorkingAI().clear();
				return;
			case SmartFarmingPackage.CRATE__WORKING_DRONES:
				getWorkingDrones().clear();
				return;
			case SmartFarmingPackage.CRATE__WORKING_CAMERAS:
				getWorkingCameras().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.CRATE__LIGHT:
				return light != null && !light.isEmpty();
			case SmartFarmingPackage.CRATE__HUMIDITYSENSOR:
				return humiditysensor != null;
			case SmartFarmingPackage.CRATE__TEMPERATURESENSOR:
				return temperaturesensor != null;
			case SmartFarmingPackage.CRATE__SOILSENOR:
				return soilsenor != null;
			case SmartFarmingPackage.CRATE__CROP_TYPE:
				return cropType != null;
			case SmartFarmingPackage.CRATE__WORKING_AI:
				return !getWorkingAI().isEmpty();
			case SmartFarmingPackage.CRATE__WORKING_DRONES:
				return !getWorkingDrones().isEmpty();
			case SmartFarmingPackage.CRATE__WORKING_CAMERAS:
				return !getWorkingCameras().isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CrateImpl
