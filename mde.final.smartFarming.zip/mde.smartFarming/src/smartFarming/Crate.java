/**
 */
package smartFarming;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Crate#getLight <em>Light</em>}</li>
 *   <li>{@link smartFarming.Crate#getHumiditysensor <em>Humiditysensor</em>}</li>
 *   <li>{@link smartFarming.Crate#getTemperaturesensor <em>Temperaturesensor</em>}</li>
 *   <li>{@link smartFarming.Crate#getCamera <em>Camera</em>}</li>
 *   <li>{@link smartFarming.Crate#getSoilsenor <em>Soilsenor</em>}</li>
 *   <li>{@link smartFarming.Crate#getCropType <em>Crop Type</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getCrate()
 * @model
 * @generated
 */
public interface Crate extends Crateid {
	/**
	 * Returns the value of the '<em><b>Light</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming.Light}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Light</em>' containment reference list.
	 * @see smartFarming.SmartFarmingPackage#getCrate_Light()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Light> getLight();

	/**
	 * Returns the value of the '<em><b>Humiditysensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Humiditysensor</em>' containment reference.
	 * @see #setHumiditysensor(HumiditySensor)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Humiditysensor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	HumiditySensor getHumiditysensor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getHumiditysensor <em>Humiditysensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Humiditysensor</em>' containment reference.
	 * @see #getHumiditysensor()
	 * @generated
	 */
	void setHumiditysensor(HumiditySensor value);

	/**
	 * Returns the value of the '<em><b>Temperaturesensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Temperaturesensor</em>' containment reference.
	 * @see #setTemperaturesensor(TemperatureSensosr)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Temperaturesensor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	TemperatureSensosr getTemperaturesensor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getTemperaturesensor <em>Temperaturesensor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Temperaturesensor</em>' containment reference.
	 * @see #getTemperaturesensor()
	 * @generated
	 */
	void setTemperaturesensor(TemperatureSensosr value);

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' reference.
	 * @see #setCamera(Camera)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Camera()
	 * @model required="true"
	 * @generated
	 */
	Camera getCamera();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getCamera <em>Camera</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Camera</em>' reference.
	 * @see #getCamera()
	 * @generated
	 */
	void setCamera(Camera value);

	/**
	 * Returns the value of the '<em><b>Soilsenor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soilsenor</em>' containment reference.
	 * @see #setSoilsenor(SoilSensor)
	 * @see smartFarming.SmartFarmingPackage#getCrate_Soilsenor()
	 * @model containment="true" required="true"
	 * @generated
	 */
	SoilSensor getSoilsenor();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getSoilsenor <em>Soilsenor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Soilsenor</em>' containment reference.
	 * @see #getSoilsenor()
	 * @generated
	 */
	void setSoilsenor(SoilSensor value);

	/**
	 * Returns the value of the '<em><b>Crop Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crop Type</em>' containment reference.
	 * @see #setCropType(Crop)
	 * @see smartFarming.SmartFarmingPackage#getCrate_CropType()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Crop getCropType();

	/**
	 * Sets the value of the '{@link smartFarming.Crate#getCropType <em>Crop Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crop Type</em>' containment reference.
	 * @see #getCropType()
	 * @generated
	 */
	void setCropType(Crop value);

} // Crate
