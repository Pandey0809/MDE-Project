/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /mde.smartFarming/model/smartFarming.ecore
 * using:
 *   /mde.smartFarming/model/smartFarming.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package smartFarming;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.TemplateParameters;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.TypeUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;
// import smartFarming.SmartFarmingPackage;
// import smartFarming.SmartFarmingTables;

/**
 * SmartFarmingTables provides the dispatch tables for the smartFarming for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class SmartFarmingTables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(SmartFarmingPackage.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ RootPackageId PACKid_$metamodel$ = IdManager.getRootPackageId("$metamodel$");
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_example_org_s_smartFarming = IdManager.getNsURIPackageId("http://www.example.org/smartFarming", null, SmartFarmingPackage.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_AI = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("AI", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Camera = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Camera", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Class = SmartFarmingTables.PACKid_$metamodel$.getClassId("Class", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Crate = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Crate", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Crop = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Crop", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Drone = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Drone", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Farm = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Farm", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_HumiditySensor = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("HumiditySensor", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Light = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("Light", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_SoilSensor = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("SoilSensor", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_TemperatureSensosor = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getClassId("TemperatureSensosor", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EFloat = SmartFarmingTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EFloat", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = SmartFarmingTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_CropType = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getEnumerationId("CropType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_FocusArea = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getEnumerationId("FocusArea");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_typelight = SmartFarmingTables.PACKid_http_c_s_s_www_example_org_s_smartFarming.getEnumerationId("typelight");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_10 = ValueUtil.integerValueOf("10");
	public static final /*@NonInvalid*/ IntegerValue INT_26 = ValueUtil.integerValueOf("26");
	public static final /*@NonInvalid*/ IntegerValue INT_4 = ValueUtil.integerValueOf("4");
	public static final /*@NonInvalid*/ IntegerValue INT_50 = ValueUtil.integerValueOf("50");
	public static final /*@NonInvalid*/ IntegerValue INT_90 = ValueUtil.integerValueOf("90");
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Crate = TypeId.BAG.getSpecializedId(SmartFarmingTables.CLSSid_Crate);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_AI = TypeId.ORDERED_SET.getSpecializedId(SmartFarmingTables.CLSSid_AI);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Camera = TypeId.ORDERED_SET.getSpecializedId(SmartFarmingTables.CLSSid_Camera);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Crate = TypeId.ORDERED_SET.getSpecializedId(SmartFarmingTables.CLSSid_Crate);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Drone = TypeId.ORDERED_SET.getSpecializedId(SmartFarmingTables.CLSSid_Drone);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Light = TypeId.ORDERED_SET.getSpecializedId(SmartFarmingTables.CLSSid_Light);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_AI = TypeId.SET.getSpecializedId(SmartFarmingTables.CLSSid_AI);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Camera = TypeId.SET.getSpecializedId(SmartFarmingTables.CLSSid_Camera);
	public static final /*@NonInvalid*/ CollectionTypeId SET_CLSSid_Drone = TypeId.SET.getSpecializedId(SmartFarmingTables.CLSSid_Drone);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			SmartFarmingTables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _AI = new EcoreExecutorType(SmartFarmingPackage.Literals.AI, PACKAGE, 0);
		public static final EcoreExecutorType _Camera = new EcoreExecutorType(SmartFarmingPackage.Literals.CAMERA, PACKAGE, 0);
		public static final EcoreExecutorType _Crate = new EcoreExecutorType(SmartFarmingPackage.Literals.CRATE, PACKAGE, 0);
		public static final EcoreExecutorType _Crateid = new EcoreExecutorType(SmartFarmingPackage.Literals.CRATEID, PACKAGE, 0);
		public static final EcoreExecutorType _Crop = new EcoreExecutorType(SmartFarmingPackage.Literals.CROP, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _CropType = new EcoreExecutorEnumeration(SmartFarmingPackage.Literals.CROP_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _Drone = new EcoreExecutorType(SmartFarmingPackage.Literals.DRONE, PACKAGE, 0);
		public static final EcoreExecutorType _Farm = new EcoreExecutorType(SmartFarmingPackage.Literals.FARM, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _FocusArea = new EcoreExecutorEnumeration(SmartFarmingPackage.Literals.FOCUS_AREA, PACKAGE, 0);
		public static final EcoreExecutorType _HumiditySensor = new EcoreExecutorType(SmartFarmingPackage.Literals.HUMIDITY_SENSOR, PACKAGE, 0);
		public static final EcoreExecutorType _Light = new EcoreExecutorType(SmartFarmingPackage.Literals.LIGHT, PACKAGE, 0);
		public static final EcoreExecutorType _Name = new EcoreExecutorType(SmartFarmingPackage.Literals.NAME, PACKAGE, 0);
		public static final EcoreExecutorType _SoilSensor = new EcoreExecutorType(SmartFarmingPackage.Literals.SOIL_SENSOR, PACKAGE, 0);
		public static final EcoreExecutorType _TemperatureSensosor = new EcoreExecutorType(SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _typelight = new EcoreExecutorEnumeration(SmartFarmingPackage.Literals.TYPELIGHT, PACKAGE, 0);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_AI,
			_Camera,
			_Crate,
			_Crateid,
			_Crop,
			_CropType,
			_Drone,
			_Farm,
			_FocusArea,
			_HumiditySensor,
			_Light,
			_Name,
			_SoilSensor,
			_TemperatureSensosor,
			_typelight
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _AI__AI = new ExecutorFragment(Types._AI, SmartFarmingTables.Types._AI);
		private static final ExecutorFragment _AI__Name = new ExecutorFragment(Types._AI, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _AI__OclAny = new ExecutorFragment(Types._AI, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _AI__OclElement = new ExecutorFragment(Types._AI, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Camera__Camera = new ExecutorFragment(Types._Camera, SmartFarmingTables.Types._Camera);
		private static final ExecutorFragment _Camera__Name = new ExecutorFragment(Types._Camera, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _Camera__OclAny = new ExecutorFragment(Types._Camera, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Camera__OclElement = new ExecutorFragment(Types._Camera, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crate__Crate = new ExecutorFragment(Types._Crate, SmartFarmingTables.Types._Crate);
		private static final ExecutorFragment _Crate__Crateid = new ExecutorFragment(Types._Crate, SmartFarmingTables.Types._Crateid);
		private static final ExecutorFragment _Crate__OclAny = new ExecutorFragment(Types._Crate, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crate__OclElement = new ExecutorFragment(Types._Crate, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crateid__Crateid = new ExecutorFragment(Types._Crateid, SmartFarmingTables.Types._Crateid);
		private static final ExecutorFragment _Crateid__OclAny = new ExecutorFragment(Types._Crateid, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crateid__OclElement = new ExecutorFragment(Types._Crateid, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Crop__Crop = new ExecutorFragment(Types._Crop, SmartFarmingTables.Types._Crop);
		private static final ExecutorFragment _Crop__OclAny = new ExecutorFragment(Types._Crop, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Crop__OclElement = new ExecutorFragment(Types._Crop, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _CropType__CropType = new ExecutorFragment(Types._CropType, SmartFarmingTables.Types._CropType);
		private static final ExecutorFragment _CropType__OclAny = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _CropType__OclElement = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _CropType__OclEnumeration = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _CropType__OclType = new ExecutorFragment(Types._CropType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Drone__Drone = new ExecutorFragment(Types._Drone, SmartFarmingTables.Types._Drone);
		private static final ExecutorFragment _Drone__Name = new ExecutorFragment(Types._Drone, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _Drone__OclAny = new ExecutorFragment(Types._Drone, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Drone__OclElement = new ExecutorFragment(Types._Drone, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Farm__Farm = new ExecutorFragment(Types._Farm, SmartFarmingTables.Types._Farm);
		private static final ExecutorFragment _Farm__Name = new ExecutorFragment(Types._Farm, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _Farm__OclAny = new ExecutorFragment(Types._Farm, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Farm__OclElement = new ExecutorFragment(Types._Farm, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _FocusArea__FocusArea = new ExecutorFragment(Types._FocusArea, SmartFarmingTables.Types._FocusArea);
		private static final ExecutorFragment _FocusArea__OclAny = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _FocusArea__OclElement = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _FocusArea__OclEnumeration = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _FocusArea__OclType = new ExecutorFragment(Types._FocusArea, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _HumiditySensor__HumiditySensor = new ExecutorFragment(Types._HumiditySensor, SmartFarmingTables.Types._HumiditySensor);
		private static final ExecutorFragment _HumiditySensor__OclAny = new ExecutorFragment(Types._HumiditySensor, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _HumiditySensor__OclElement = new ExecutorFragment(Types._HumiditySensor, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Light__Light = new ExecutorFragment(Types._Light, SmartFarmingTables.Types._Light);
		private static final ExecutorFragment _Light__Name = new ExecutorFragment(Types._Light, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _Light__OclAny = new ExecutorFragment(Types._Light, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Light__OclElement = new ExecutorFragment(Types._Light, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Name__Name = new ExecutorFragment(Types._Name, SmartFarmingTables.Types._Name);
		private static final ExecutorFragment _Name__OclAny = new ExecutorFragment(Types._Name, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Name__OclElement = new ExecutorFragment(Types._Name, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _SoilSensor__OclAny = new ExecutorFragment(Types._SoilSensor, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _SoilSensor__OclElement = new ExecutorFragment(Types._SoilSensor, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _SoilSensor__SoilSensor = new ExecutorFragment(Types._SoilSensor, SmartFarmingTables.Types._SoilSensor);

		private static final ExecutorFragment _TemperatureSensosor__OclAny = new ExecutorFragment(Types._TemperatureSensosor, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _TemperatureSensosor__OclElement = new ExecutorFragment(Types._TemperatureSensosor, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _TemperatureSensosor__TemperatureSensosor = new ExecutorFragment(Types._TemperatureSensosor, SmartFarmingTables.Types._TemperatureSensosor);

		private static final ExecutorFragment _typelight__OclAny = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _typelight__OclElement = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _typelight__OclEnumeration = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _typelight__OclType = new ExecutorFragment(Types._typelight, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _typelight__typelight = new ExecutorFragment(Types._typelight, SmartFarmingTables.Types._typelight);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}


		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		public static final ExecutorOperation _Farm__isSpaceaAvailable = new ExecutorOperation("isSpaceaAvailable", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Farm,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _TemperatureSensosor__arePlantsAlive = new ExecutorOperation("arePlantsAlive", TypeUtil.EMPTY_PARAMETER_TYPES, Types._TemperatureSensosor,
			0, TemplateParameters.EMPTY_LIST, null);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _AI__AIMonitoring = new EcoreExecutorProperty(SmartFarmingPackage.Literals.AI__AI_MONITORING, Types._AI, 0);
		public static final ExecutorProperty _AI__Crate__workingAI = new ExecutorPropertyWithImplementation("Crate", Types._AI, 1, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__WORKING_AI));
		public static final ExecutorProperty _AI__Farm__ai = new ExecutorPropertyWithImplementation("Farm", Types._AI, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.FARM__AI));

		public static final ExecutorProperty _Camera__CameraFocus = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CAMERA__CAMERA_FOCUS, Types._Camera, 0);
		public static final ExecutorProperty _Camera__Crate__workingCameras = new ExecutorPropertyWithImplementation("Crate", Types._Camera, 1, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__WORKING_CAMERAS));
		public static final ExecutorProperty _Camera__Farm__camera = new ExecutorPropertyWithImplementation("Farm", Types._Camera, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.FARM__CAMERA));

		public static final ExecutorProperty _Crate__cropType = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__CROP_TYPE, Types._Crate, 0);
		public static final ExecutorProperty _Crate__humiditysensor = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__HUMIDITYSENSOR, Types._Crate, 1);
		public static final ExecutorProperty _Crate__light = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__LIGHT, Types._Crate, 2);
		public static final ExecutorProperty _Crate__soilsenor = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__SOILSENOR, Types._Crate, 3);
		public static final ExecutorProperty _Crate__temperaturesensor = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__TEMPERATURESENSOR, Types._Crate, 4);
		public static final ExecutorProperty _Crate__workingAI = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__WORKING_AI, Types._Crate, 5);
		public static final ExecutorProperty _Crate__workingCameras = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__WORKING_CAMERAS, Types._Crate, 6);
		public static final ExecutorProperty _Crate__workingDrones = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATE__WORKING_DRONES, Types._Crate, 7);
		public static final ExecutorProperty _Crate__Farm__crate = new ExecutorPropertyWithImplementation("Farm", Types._Crate, 8, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.FARM__CRATE));

		public static final ExecutorProperty _Crateid__id = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CRATEID__ID, Types._Crateid, 0);

		public static final ExecutorProperty _Crop__Crop = new EcoreExecutorProperty(SmartFarmingPackage.Literals.CROP__CROP, Types._Crop, 0);
		public static final ExecutorProperty _Crop__Crate__cropType = new ExecutorPropertyWithImplementation("Crate", Types._Crop, 1, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__CROP_TYPE));

		public static final ExecutorProperty _Drone__DroneMonitoring = new EcoreExecutorProperty(SmartFarmingPackage.Literals.DRONE__DRONE_MONITORING, Types._Drone, 0);
		public static final ExecutorProperty _Drone__TurnOn = new EcoreExecutorProperty(SmartFarmingPackage.Literals.DRONE__TURN_ON, Types._Drone, 1);
		public static final ExecutorProperty _Drone__Crate__workingDrones = new ExecutorPropertyWithImplementation("Crate", Types._Drone, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__WORKING_DRONES));
		public static final ExecutorProperty _Drone__Farm__drone = new ExecutorPropertyWithImplementation("Farm", Types._Drone, 3, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.FARM__DRONE));

		public static final ExecutorProperty _Farm__MaxCrates = new EcoreExecutorProperty(SmartFarmingPackage.Literals.FARM__MAX_CRATES, Types._Farm, 0);
		public static final ExecutorProperty _Farm__ai = new EcoreExecutorProperty(SmartFarmingPackage.Literals.FARM__AI, Types._Farm, 1);
		public static final ExecutorProperty _Farm__camera = new EcoreExecutorProperty(SmartFarmingPackage.Literals.FARM__CAMERA, Types._Farm, 2);
		public static final ExecutorProperty _Farm__crate = new EcoreExecutorProperty(SmartFarmingPackage.Literals.FARM__CRATE, Types._Farm, 3);
		public static final ExecutorProperty _Farm__drone = new EcoreExecutorProperty(SmartFarmingPackage.Literals.FARM__DRONE, Types._Farm, 4);

		public static final ExecutorProperty _HumiditySensor__HumidityValueInPercentage = new EcoreExecutorProperty(SmartFarmingPackage.Literals.HUMIDITY_SENSOR__HUMIDITY_VALUE_IN_PERCENTAGE, Types._HumiditySensor, 0);
		public static final ExecutorProperty _HumiditySensor__TurnOn = new EcoreExecutorProperty(SmartFarmingPackage.Literals.HUMIDITY_SENSOR__TURN_ON, Types._HumiditySensor, 1);
		public static final ExecutorProperty _HumiditySensor__Crate__humiditysensor = new ExecutorPropertyWithImplementation("Crate", Types._HumiditySensor, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__HUMIDITYSENSOR));

		public static final ExecutorProperty _Light__TurnOn = new EcoreExecutorProperty(SmartFarmingPackage.Literals.LIGHT__TURN_ON, Types._Light, 0);
		public static final ExecutorProperty _Light__TypeLight = new EcoreExecutorProperty(SmartFarmingPackage.Literals.LIGHT__TYPE_LIGHT, Types._Light, 1);
		public static final ExecutorProperty _Light__Crate__light = new ExecutorPropertyWithImplementation("Crate", Types._Light, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__LIGHT));

		public static final ExecutorProperty _Name__name = new EcoreExecutorProperty(SmartFarmingPackage.Literals.NAME__NAME, Types._Name, 0);

		public static final ExecutorProperty _SoilSensor__SoilMoistureInPercentage = new EcoreExecutorProperty(SmartFarmingPackage.Literals.SOIL_SENSOR__SOIL_MOISTURE_IN_PERCENTAGE, Types._SoilSensor, 0);
		public static final ExecutorProperty _SoilSensor__ph = new EcoreExecutorProperty(SmartFarmingPackage.Literals.SOIL_SENSOR__PH, Types._SoilSensor, 1);
		public static final ExecutorProperty _SoilSensor__Crate__soilsenor = new ExecutorPropertyWithImplementation("Crate", Types._SoilSensor, 2, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__SOILSENOR));

		public static final ExecutorProperty _TemperatureSensosor__CrateTemperature = new EcoreExecutorProperty(SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR__CRATE_TEMPERATURE, Types._TemperatureSensosor, 0);
		public static final ExecutorProperty _TemperatureSensosor__PlantTemperature = new EcoreExecutorProperty(SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR__PLANT_TEMPERATURE, Types._TemperatureSensosor, 1);
		public static final ExecutorProperty _TemperatureSensosor__TemperatureinDegreeCelcius = new EcoreExecutorProperty(SmartFarmingPackage.Literals.TEMPERATURE_SENSOSOR__TEMPERATUREIN_DEGREE_CELCIUS, Types._TemperatureSensosor, 2);
		public static final ExecutorProperty _TemperatureSensosor__Crate__temperaturesensor = new ExecutorPropertyWithImplementation("Crate", Types._TemperatureSensosor, 3, new EcoreLibraryOppositeProperty(SmartFarmingPackage.Literals.CRATE__TEMPERATURESENSOR));
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _AI =
			{
				Fragments._AI__OclAny /* 0 */,
				Fragments._AI__OclElement /* 1 */,
				Fragments._AI__Name /* 2 */,
				Fragments._AI__AI /* 3 */
			};
		private static final int /*@NonNull*/ [] __AI = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Camera =
			{
				Fragments._Camera__OclAny /* 0 */,
				Fragments._Camera__OclElement /* 1 */,
				Fragments._Camera__Name /* 2 */,
				Fragments._Camera__Camera /* 3 */
			};
		private static final int /*@NonNull*/ [] __Camera = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crate =
			{
				Fragments._Crate__OclAny /* 0 */,
				Fragments._Crate__OclElement /* 1 */,
				Fragments._Crate__Crateid /* 2 */,
				Fragments._Crate__Crate /* 3 */
			};
		private static final int /*@NonNull*/ [] __Crate = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crateid =
			{
				Fragments._Crateid__OclAny /* 0 */,
				Fragments._Crateid__OclElement /* 1 */,
				Fragments._Crateid__Crateid /* 2 */
			};
		private static final int /*@NonNull*/ [] __Crateid = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Crop =
			{
				Fragments._Crop__OclAny /* 0 */,
				Fragments._Crop__OclElement /* 1 */,
				Fragments._Crop__Crop /* 2 */
			};
		private static final int /*@NonNull*/ [] __Crop = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _CropType =
			{
				Fragments._CropType__OclAny /* 0 */,
				Fragments._CropType__OclElement /* 1 */,
				Fragments._CropType__OclType /* 2 */,
				Fragments._CropType__OclEnumeration /* 3 */,
				Fragments._CropType__CropType /* 4 */
			};
		private static final int /*@NonNull*/ [] __CropType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Drone =
			{
				Fragments._Drone__OclAny /* 0 */,
				Fragments._Drone__OclElement /* 1 */,
				Fragments._Drone__Name /* 2 */,
				Fragments._Drone__Drone /* 3 */
			};
		private static final int /*@NonNull*/ [] __Drone = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Farm =
			{
				Fragments._Farm__OclAny /* 0 */,
				Fragments._Farm__OclElement /* 1 */,
				Fragments._Farm__Name /* 2 */,
				Fragments._Farm__Farm /* 3 */
			};
		private static final int /*@NonNull*/ [] __Farm = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _FocusArea =
			{
				Fragments._FocusArea__OclAny /* 0 */,
				Fragments._FocusArea__OclElement /* 1 */,
				Fragments._FocusArea__OclType /* 2 */,
				Fragments._FocusArea__OclEnumeration /* 3 */,
				Fragments._FocusArea__FocusArea /* 4 */
			};
		private static final int /*@NonNull*/ [] __FocusArea = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _HumiditySensor =
			{
				Fragments._HumiditySensor__OclAny /* 0 */,
				Fragments._HumiditySensor__OclElement /* 1 */,
				Fragments._HumiditySensor__HumiditySensor /* 2 */
			};
		private static final int /*@NonNull*/ [] __HumiditySensor = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Light =
			{
				Fragments._Light__OclAny /* 0 */,
				Fragments._Light__OclElement /* 1 */,
				Fragments._Light__Name /* 2 */,
				Fragments._Light__Light /* 3 */
			};
		private static final int /*@NonNull*/ [] __Light = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Name =
			{
				Fragments._Name__OclAny /* 0 */,
				Fragments._Name__OclElement /* 1 */,
				Fragments._Name__Name /* 2 */
			};
		private static final int /*@NonNull*/ [] __Name = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _SoilSensor =
			{
				Fragments._SoilSensor__OclAny /* 0 */,
				Fragments._SoilSensor__OclElement /* 1 */,
				Fragments._SoilSensor__SoilSensor /* 2 */
			};
		private static final int /*@NonNull*/ [] __SoilSensor = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _TemperatureSensosor =
			{
				Fragments._TemperatureSensosor__OclAny /* 0 */,
				Fragments._TemperatureSensosor__OclElement /* 1 */,
				Fragments._TemperatureSensosor__TemperatureSensosor /* 2 */
			};
		private static final int /*@NonNull*/ [] __TemperatureSensosor = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _typelight =
			{
				Fragments._typelight__OclAny /* 0 */,
				Fragments._typelight__OclElement /* 1 */,
				Fragments._typelight__OclType /* 2 */,
				Fragments._typelight__OclEnumeration /* 3 */,
				Fragments._typelight__typelight /* 4 */
			};
		private static final int /*@NonNull*/ [] __typelight = { 1,1,1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._AI.initFragments(_AI, __AI);
			Types._Camera.initFragments(_Camera, __Camera);
			Types._Crate.initFragments(_Crate, __Crate);
			Types._Crateid.initFragments(_Crateid, __Crateid);
			Types._Crop.initFragments(_Crop, __Crop);
			Types._CropType.initFragments(_CropType, __CropType);
			Types._Drone.initFragments(_Drone, __Drone);
			Types._Farm.initFragments(_Farm, __Farm);
			Types._FocusArea.initFragments(_FocusArea, __FocusArea);
			Types._HumiditySensor.initFragments(_HumiditySensor, __HumiditySensor);
			Types._Light.initFragments(_Light, __Light);
			Types._Name.initFragments(_Name, __Name);
			Types._SoilSensor.initFragments(_SoilSensor, __SoilSensor);
			Types._TemperatureSensosor.initFragments(_TemperatureSensosor, __TemperatureSensosor);
			Types._typelight.initFragments(_typelight, __typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _AI__AI = {};
		private static final ExecutorOperation /*@NonNull*/ [] _AI__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _AI__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _AI__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Camera__Camera = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Camera__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crate__Crate = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__Crateid = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crate__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__Crateid = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crateid__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Crop__Crop = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Crop__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Crop__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _CropType__CropType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _CropType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Drone__Drone = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Drone__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Farm__Farm = {
			SmartFarmingTables.Operations._Farm__isSpaceaAvailable /* isSpaceaAvailable() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Farm__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__FocusArea = {};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _FocusArea__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _HumiditySensor__HumiditySensor = {};
		private static final ExecutorOperation /*@NonNull*/ [] _HumiditySensor__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _HumiditySensor__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Light__Light = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Light__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Name__Name = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Name__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Name__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _SoilSensor__SoilSensor = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SoilSensor__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _SoilSensor__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _TemperatureSensosor__TemperatureSensosor = {
			SmartFarmingTables.Operations._TemperatureSensosor__arePlantsAlive /* arePlantsAlive() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TemperatureSensosor__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _TemperatureSensosor__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _typelight__typelight = {};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _typelight__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._AI__AI.initOperations(_AI__AI);
			Fragments._AI__Name.initOperations(_AI__Name);
			Fragments._AI__OclAny.initOperations(_AI__OclAny);
			Fragments._AI__OclElement.initOperations(_AI__OclElement);

			Fragments._Camera__Camera.initOperations(_Camera__Camera);
			Fragments._Camera__Name.initOperations(_Camera__Name);
			Fragments._Camera__OclAny.initOperations(_Camera__OclAny);
			Fragments._Camera__OclElement.initOperations(_Camera__OclElement);

			Fragments._Crate__Crate.initOperations(_Crate__Crate);
			Fragments._Crate__Crateid.initOperations(_Crate__Crateid);
			Fragments._Crate__OclAny.initOperations(_Crate__OclAny);
			Fragments._Crate__OclElement.initOperations(_Crate__OclElement);

			Fragments._Crateid__Crateid.initOperations(_Crateid__Crateid);
			Fragments._Crateid__OclAny.initOperations(_Crateid__OclAny);
			Fragments._Crateid__OclElement.initOperations(_Crateid__OclElement);

			Fragments._Crop__Crop.initOperations(_Crop__Crop);
			Fragments._Crop__OclAny.initOperations(_Crop__OclAny);
			Fragments._Crop__OclElement.initOperations(_Crop__OclElement);

			Fragments._CropType__CropType.initOperations(_CropType__CropType);
			Fragments._CropType__OclAny.initOperations(_CropType__OclAny);
			Fragments._CropType__OclElement.initOperations(_CropType__OclElement);
			Fragments._CropType__OclEnumeration.initOperations(_CropType__OclEnumeration);
			Fragments._CropType__OclType.initOperations(_CropType__OclType);

			Fragments._Drone__Drone.initOperations(_Drone__Drone);
			Fragments._Drone__Name.initOperations(_Drone__Name);
			Fragments._Drone__OclAny.initOperations(_Drone__OclAny);
			Fragments._Drone__OclElement.initOperations(_Drone__OclElement);

			Fragments._Farm__Farm.initOperations(_Farm__Farm);
			Fragments._Farm__Name.initOperations(_Farm__Name);
			Fragments._Farm__OclAny.initOperations(_Farm__OclAny);
			Fragments._Farm__OclElement.initOperations(_Farm__OclElement);

			Fragments._FocusArea__FocusArea.initOperations(_FocusArea__FocusArea);
			Fragments._FocusArea__OclAny.initOperations(_FocusArea__OclAny);
			Fragments._FocusArea__OclElement.initOperations(_FocusArea__OclElement);
			Fragments._FocusArea__OclEnumeration.initOperations(_FocusArea__OclEnumeration);
			Fragments._FocusArea__OclType.initOperations(_FocusArea__OclType);

			Fragments._HumiditySensor__HumiditySensor.initOperations(_HumiditySensor__HumiditySensor);
			Fragments._HumiditySensor__OclAny.initOperations(_HumiditySensor__OclAny);
			Fragments._HumiditySensor__OclElement.initOperations(_HumiditySensor__OclElement);

			Fragments._Light__Light.initOperations(_Light__Light);
			Fragments._Light__Name.initOperations(_Light__Name);
			Fragments._Light__OclAny.initOperations(_Light__OclAny);
			Fragments._Light__OclElement.initOperations(_Light__OclElement);

			Fragments._Name__Name.initOperations(_Name__Name);
			Fragments._Name__OclAny.initOperations(_Name__OclAny);
			Fragments._Name__OclElement.initOperations(_Name__OclElement);

			Fragments._SoilSensor__OclAny.initOperations(_SoilSensor__OclAny);
			Fragments._SoilSensor__OclElement.initOperations(_SoilSensor__OclElement);
			Fragments._SoilSensor__SoilSensor.initOperations(_SoilSensor__SoilSensor);

			Fragments._TemperatureSensosor__OclAny.initOperations(_TemperatureSensosor__OclAny);
			Fragments._TemperatureSensosor__OclElement.initOperations(_TemperatureSensosor__OclElement);
			Fragments._TemperatureSensosor__TemperatureSensosor.initOperations(_TemperatureSensosor__TemperatureSensosor);

			Fragments._typelight__OclAny.initOperations(_typelight__OclAny);
			Fragments._typelight__OclElement.initOperations(_typelight__OclElement);
			Fragments._typelight__OclEnumeration.initOperations(_typelight__OclEnumeration);
			Fragments._typelight__OclType.initOperations(_typelight__OclType);
			Fragments._typelight__typelight.initOperations(_typelight__typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _AI = {
			SmartFarmingTables.Properties._AI__AIMonitoring,
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Camera = {
			SmartFarmingTables.Properties._Camera__CameraFocus,
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crate = {
			SmartFarmingTables.Properties._Crate__cropType,
			SmartFarmingTables.Properties._Crate__humiditysensor,
			SmartFarmingTables.Properties._Crateid__id,
			SmartFarmingTables.Properties._Crate__light,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			SmartFarmingTables.Properties._Crate__soilsenor,
			SmartFarmingTables.Properties._Crate__temperaturesensor,
			SmartFarmingTables.Properties._Crate__workingAI,
			SmartFarmingTables.Properties._Crate__workingCameras,
			SmartFarmingTables.Properties._Crate__workingDrones
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crateid = {
			SmartFarmingTables.Properties._Crateid__id,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Crop = {
			SmartFarmingTables.Properties._Crop__Crop,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _CropType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Drone = {
			SmartFarmingTables.Properties._Drone__DroneMonitoring,
			SmartFarmingTables.Properties._Drone__TurnOn,
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Farm = {
			SmartFarmingTables.Properties._Farm__MaxCrates,
			SmartFarmingTables.Properties._Farm__ai,
			SmartFarmingTables.Properties._Farm__camera,
			SmartFarmingTables.Properties._Farm__crate,
			SmartFarmingTables.Properties._Farm__drone,
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _FocusArea = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _HumiditySensor = {
			SmartFarmingTables.Properties._HumiditySensor__HumidityValueInPercentage,
			SmartFarmingTables.Properties._HumiditySensor__TurnOn,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Light = {
			SmartFarmingTables.Properties._Light__TurnOn,
			SmartFarmingTables.Properties._Light__TypeLight,
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Name = {
			SmartFarmingTables.Properties._Name__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _SoilSensor = {
			SmartFarmingTables.Properties._SoilSensor__SoilMoistureInPercentage,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			SmartFarmingTables.Properties._SoilSensor__ph
		};

		private static final ExecutorProperty /*@NonNull*/ [] _TemperatureSensosor = {
			SmartFarmingTables.Properties._TemperatureSensosor__CrateTemperature,
			SmartFarmingTables.Properties._TemperatureSensosor__PlantTemperature,
			SmartFarmingTables.Properties._TemperatureSensosor__TemperatureinDegreeCelcius,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _typelight = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._AI__AI.initProperties(_AI);
			Fragments._Camera__Camera.initProperties(_Camera);
			Fragments._Crate__Crate.initProperties(_Crate);
			Fragments._Crateid__Crateid.initProperties(_Crateid);
			Fragments._Crop__Crop.initProperties(_Crop);
			Fragments._CropType__CropType.initProperties(_CropType);
			Fragments._Drone__Drone.initProperties(_Drone);
			Fragments._Farm__Farm.initProperties(_Farm);
			Fragments._FocusArea__FocusArea.initProperties(_FocusArea);
			Fragments._HumiditySensor__HumiditySensor.initProperties(_HumiditySensor);
			Fragments._Light__Light.initProperties(_Light);
			Fragments._Name__Name.initProperties(_Name);
			Fragments._SoilSensor__SoilSensor.initProperties(_SoilSensor);
			Fragments._TemperatureSensosor__TemperatureSensosor.initProperties(_TemperatureSensosor);
			Fragments._typelight__typelight.initProperties(_typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _CropType__Tomato = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.CROP_TYPE.getEEnumLiteral("Tomato"), Types._CropType, 0);
		public static final EcoreExecutorEnumerationLiteral _CropType__Cabbage = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.CROP_TYPE.getEEnumLiteral("Cabbage"), Types._CropType, 1);
		public static final EcoreExecutorEnumerationLiteral _CropType__Potato = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.CROP_TYPE.getEEnumLiteral("Potato"), Types._CropType, 2);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _CropType = {
			_CropType__Tomato,
			_CropType__Cabbage,
			_CropType__Potato
		};

		public static final EcoreExecutorEnumerationLiteral _FocusArea__Crates = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.FOCUS_AREA.getEEnumLiteral("Crates"), Types._FocusArea, 0);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Plants = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.FOCUS_AREA.getEEnumLiteral("Plants"), Types._FocusArea, 1);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Cameras = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.FOCUS_AREA.getEEnumLiteral("Cameras"), Types._FocusArea, 2);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Drones = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.FOCUS_AREA.getEEnumLiteral("Drones"), Types._FocusArea, 3);
		public static final EcoreExecutorEnumerationLiteral _FocusArea__Sensors = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.FOCUS_AREA.getEEnumLiteral("Sensors"), Types._FocusArea, 4);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _FocusArea = {
			_FocusArea__Crates,
			_FocusArea__Plants,
			_FocusArea__Cameras,
			_FocusArea__Drones,
			_FocusArea__Sensors
		};

		public static final EcoreExecutorEnumerationLiteral _typelight__UVlight = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.TYPELIGHT.getEEnumLiteral("UVlight"), Types._typelight, 0);
		public static final EcoreExecutorEnumerationLiteral _typelight__BlueLight = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.TYPELIGHT.getEEnumLiteral("BlueLight"), Types._typelight, 1);
		public static final EcoreExecutorEnumerationLiteral _typelight__RedLight = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.TYPELIGHT.getEEnumLiteral("RedLight"), Types._typelight, 2);
		public static final EcoreExecutorEnumerationLiteral _typelight__GreenLight = new EcoreExecutorEnumerationLiteral(SmartFarmingPackage.Literals.TYPELIGHT.getEEnumLiteral("GreenLight"), Types._typelight, 3);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _typelight = {
			_typelight__UVlight,
			_typelight__BlueLight,
			_typelight__RedLight,
			_typelight__GreenLight
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._CropType.initLiterals(_CropType);
			Types._FocusArea.initLiterals(_FocusArea);
			Types._typelight.initLiterals(_typelight);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of SmartFarmingTables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new SmartFarmingTables();
	}

	private SmartFarmingTables() {
		super(SmartFarmingPackage.eNS_URI);
	}

	/*
	 * The EClasses whose instances should be cached to support allInstances().
	 */
	private static final EClass allInstancesEClasses /*@NonNull*/ [] = {
		SmartFarmingPackage.Literals.AI,
		SmartFarmingPackage.Literals.CAMERA,
		SmartFarmingPackage.Literals.DRONE
	};

	@Override
	public EClass /*@NonNull*/ [] basicGetAllInstancesClasses() {
		return allInstancesEClasses;
	}
}
