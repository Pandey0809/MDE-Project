package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Farm'", "'{'", "'MaxCrates'", "'crate'", "','", "'}'", "'drone'", "'camera'", "'ai'", "'Crate'", "'id'", "'light'", "'humiditysensor'", "'temperaturesensor'", "'soilsenor'", "'cropType'", "'TurnOn'", "'Drone'", "'DroneMonitoring'", "'Camera'", "'CameraFocus'", "'AI'", "'AIMonitoring'", "'-'", "'Light'", "'TypeLight'", "'HumiditySensor'", "'HumidityValueInPercentage'", "'TemperatureinDegreeCelcius'", "'TemperatureSensosor'", "'CrateTemperature'", "'PlantTemperature'", "'SoilSensor'", "'ph'", "'SoilMoistureInPercentage'", "'Crop'", "'.'", "'E'", "'e'", "'UVlight'", "'BlueLight'", "'RedLight'", "'GreenLight'", "'Tomato'", "'Cabbage'", "'Potato'", "'Crates'", "'Plants'", "'Cameras'", "'Drones'", "'Sensors'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Farm";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFarm"
    // InternalMyDsl.g:65:1: entryRuleFarm returns [EObject current=null] : iv_ruleFarm= ruleFarm EOF ;
    public final EObject entryRuleFarm() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFarm = null;


        try {
            // InternalMyDsl.g:65:45: (iv_ruleFarm= ruleFarm EOF )
            // InternalMyDsl.g:66:2: iv_ruleFarm= ruleFarm EOF
            {
             newCompositeNode(grammarAccess.getFarmRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFarm=ruleFarm();

            state._fsp--;

             current =iv_ruleFarm; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFarm"


    // $ANTLR start "ruleFarm"
    // InternalMyDsl.g:72:1: ruleFarm returns [EObject current=null] : (otherlv_0= 'Farm' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'MaxCrates' ( (lv_MaxCrates_4_0= ruleEInt ) ) (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )? otherlv_11= 'drone' otherlv_12= '{' ( (lv_drone_13_0= ruleDrone ) ) (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )* otherlv_16= '}' (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )? (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )? otherlv_29= '}' ) ;
    public final EObject ruleFarm() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_22=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token otherlv_26=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_MaxCrates_4_0 = null;

        EObject lv_crate_7_0 = null;

        EObject lv_crate_9_0 = null;

        EObject lv_drone_13_0 = null;

        EObject lv_drone_15_0 = null;

        EObject lv_camera_19_0 = null;

        EObject lv_camera_21_0 = null;

        EObject lv_ai_25_0 = null;

        EObject lv_ai_27_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:78:2: ( (otherlv_0= 'Farm' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'MaxCrates' ( (lv_MaxCrates_4_0= ruleEInt ) ) (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )? otherlv_11= 'drone' otherlv_12= '{' ( (lv_drone_13_0= ruleDrone ) ) (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )* otherlv_16= '}' (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )? (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )? otherlv_29= '}' ) )
            // InternalMyDsl.g:79:2: (otherlv_0= 'Farm' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'MaxCrates' ( (lv_MaxCrates_4_0= ruleEInt ) ) (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )? otherlv_11= 'drone' otherlv_12= '{' ( (lv_drone_13_0= ruleDrone ) ) (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )* otherlv_16= '}' (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )? (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )? otherlv_29= '}' )
            {
            // InternalMyDsl.g:79:2: (otherlv_0= 'Farm' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'MaxCrates' ( (lv_MaxCrates_4_0= ruleEInt ) ) (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )? otherlv_11= 'drone' otherlv_12= '{' ( (lv_drone_13_0= ruleDrone ) ) (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )* otherlv_16= '}' (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )? (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )? otherlv_29= '}' )
            // InternalMyDsl.g:80:3: otherlv_0= 'Farm' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'MaxCrates' ( (lv_MaxCrates_4_0= ruleEInt ) ) (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )? otherlv_11= 'drone' otherlv_12= '{' ( (lv_drone_13_0= ruleDrone ) ) (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )* otherlv_16= '}' (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )? (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )? otherlv_29= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getFarmAccess().getFarmKeyword_0());
            		
            // InternalMyDsl.g:84:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMyDsl.g:85:4: (lv_name_1_0= ruleEString )
            {
            // InternalMyDsl.g:85:4: (lv_name_1_0= ruleEString )
            // InternalMyDsl.g:86:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getFarmAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFarmRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.xtext.example.mydsl.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getFarmAccess().getMaxCratesKeyword_3());
            		
            // InternalMyDsl.g:111:3: ( (lv_MaxCrates_4_0= ruleEInt ) )
            // InternalMyDsl.g:112:4: (lv_MaxCrates_4_0= ruleEInt )
            {
            // InternalMyDsl.g:112:4: (lv_MaxCrates_4_0= ruleEInt )
            // InternalMyDsl.g:113:5: lv_MaxCrates_4_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getFarmAccess().getMaxCratesEIntParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_7);
            lv_MaxCrates_4_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFarmRule());
            					}
            					set(
            						current,
            						"MaxCrates",
            						lv_MaxCrates_4_0,
            						"org.xtext.example.mydsl.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:130:3: (otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:131:4: otherlv_5= 'crate' otherlv_6= '{' ( (lv_crate_7_0= ruleCrate ) ) (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,14,FOLLOW_4); 

                    				newLeafNode(otherlv_5, grammarAccess.getFarmAccess().getCrateKeyword_5_0());
                    			
                    otherlv_6=(Token)match(input,12,FOLLOW_8); 

                    				newLeafNode(otherlv_6, grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalMyDsl.g:139:4: ( (lv_crate_7_0= ruleCrate ) )
                    // InternalMyDsl.g:140:5: (lv_crate_7_0= ruleCrate )
                    {
                    // InternalMyDsl.g:140:5: (lv_crate_7_0= ruleCrate )
                    // InternalMyDsl.g:141:6: lv_crate_7_0= ruleCrate
                    {

                    						newCompositeNode(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_crate_7_0=ruleCrate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFarmRule());
                    						}
                    						add(
                    							current,
                    							"crate",
                    							lv_crate_7_0,
                    							"org.xtext.example.mydsl.MyDsl.Crate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:158:4: (otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==15) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalMyDsl.g:159:5: otherlv_8= ',' ( (lv_crate_9_0= ruleCrate ) )
                    	    {
                    	    otherlv_8=(Token)match(input,15,FOLLOW_8); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getFarmAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalMyDsl.g:163:5: ( (lv_crate_9_0= ruleCrate ) )
                    	    // InternalMyDsl.g:164:6: (lv_crate_9_0= ruleCrate )
                    	    {
                    	    // InternalMyDsl.g:164:6: (lv_crate_9_0= ruleCrate )
                    	    // InternalMyDsl.g:165:7: lv_crate_9_0= ruleCrate
                    	    {

                    	    							newCompositeNode(grammarAccess.getFarmAccess().getCrateCrateParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_crate_9_0=ruleCrate();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getFarmRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"crate",
                    	    								lv_crate_9_0,
                    	    								"org.xtext.example.mydsl.MyDsl.Crate");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,16,FOLLOW_10); 

                    				newLeafNode(otherlv_10, grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_11=(Token)match(input,17,FOLLOW_4); 

            			newLeafNode(otherlv_11, grammarAccess.getFarmAccess().getDroneKeyword_6());
            		
            otherlv_12=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_12, grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_7());
            		
            // InternalMyDsl.g:196:3: ( (lv_drone_13_0= ruleDrone ) )
            // InternalMyDsl.g:197:4: (lv_drone_13_0= ruleDrone )
            {
            // InternalMyDsl.g:197:4: (lv_drone_13_0= ruleDrone )
            // InternalMyDsl.g:198:5: lv_drone_13_0= ruleDrone
            {

            					newCompositeNode(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_9);
            lv_drone_13_0=ruleDrone();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFarmRule());
            					}
            					add(
            						current,
            						"drone",
            						lv_drone_13_0,
            						"org.xtext.example.mydsl.MyDsl.Drone");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:215:3: (otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==15) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyDsl.g:216:4: otherlv_14= ',' ( (lv_drone_15_0= ruleDrone ) )
            	    {
            	    otherlv_14=(Token)match(input,15,FOLLOW_11); 

            	    				newLeafNode(otherlv_14, grammarAccess.getFarmAccess().getCommaKeyword_9_0());
            	    			
            	    // InternalMyDsl.g:220:4: ( (lv_drone_15_0= ruleDrone ) )
            	    // InternalMyDsl.g:221:5: (lv_drone_15_0= ruleDrone )
            	    {
            	    // InternalMyDsl.g:221:5: (lv_drone_15_0= ruleDrone )
            	    // InternalMyDsl.g:222:6: lv_drone_15_0= ruleDrone
            	    {

            	    						newCompositeNode(grammarAccess.getFarmAccess().getDroneDroneParserRuleCall_9_1_0());
            	    					
            	    pushFollow(FOLLOW_9);
            	    lv_drone_15_0=ruleDrone();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getFarmRule());
            	    						}
            	    						add(
            	    							current,
            	    							"drone",
            	    							lv_drone_15_0,
            	    							"org.xtext.example.mydsl.MyDsl.Drone");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            otherlv_16=(Token)match(input,16,FOLLOW_12); 

            			newLeafNode(otherlv_16, grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_10());
            		
            // InternalMyDsl.g:244:3: (otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==18) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:245:4: otherlv_17= 'camera' otherlv_18= '{' ( (lv_camera_19_0= ruleCamera ) ) (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )* otherlv_22= '}'
                    {
                    otherlv_17=(Token)match(input,18,FOLLOW_4); 

                    				newLeafNode(otherlv_17, grammarAccess.getFarmAccess().getCameraKeyword_11_0());
                    			
                    otherlv_18=(Token)match(input,12,FOLLOW_13); 

                    				newLeafNode(otherlv_18, grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_11_1());
                    			
                    // InternalMyDsl.g:253:4: ( (lv_camera_19_0= ruleCamera ) )
                    // InternalMyDsl.g:254:5: (lv_camera_19_0= ruleCamera )
                    {
                    // InternalMyDsl.g:254:5: (lv_camera_19_0= ruleCamera )
                    // InternalMyDsl.g:255:6: lv_camera_19_0= ruleCamera
                    {

                    						newCompositeNode(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_2_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_camera_19_0=ruleCamera();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFarmRule());
                    						}
                    						add(
                    							current,
                    							"camera",
                    							lv_camera_19_0,
                    							"org.xtext.example.mydsl.MyDsl.Camera");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:272:4: (otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==15) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalMyDsl.g:273:5: otherlv_20= ',' ( (lv_camera_21_0= ruleCamera ) )
                    	    {
                    	    otherlv_20=(Token)match(input,15,FOLLOW_13); 

                    	    					newLeafNode(otherlv_20, grammarAccess.getFarmAccess().getCommaKeyword_11_3_0());
                    	    				
                    	    // InternalMyDsl.g:277:5: ( (lv_camera_21_0= ruleCamera ) )
                    	    // InternalMyDsl.g:278:6: (lv_camera_21_0= ruleCamera )
                    	    {
                    	    // InternalMyDsl.g:278:6: (lv_camera_21_0= ruleCamera )
                    	    // InternalMyDsl.g:279:7: lv_camera_21_0= ruleCamera
                    	    {

                    	    							newCompositeNode(grammarAccess.getFarmAccess().getCameraCameraParserRuleCall_11_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_camera_21_0=ruleCamera();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getFarmRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"camera",
                    	    								lv_camera_21_0,
                    	    								"org.xtext.example.mydsl.MyDsl.Camera");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    otherlv_22=(Token)match(input,16,FOLLOW_14); 

                    				newLeafNode(otherlv_22, grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_11_4());
                    			

                    }
                    break;

            }

            // InternalMyDsl.g:302:3: (otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==19) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:303:4: otherlv_23= 'ai' otherlv_24= '{' ( (lv_ai_25_0= ruleAI ) ) (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )* otherlv_28= '}'
                    {
                    otherlv_23=(Token)match(input,19,FOLLOW_4); 

                    				newLeafNode(otherlv_23, grammarAccess.getFarmAccess().getAiKeyword_12_0());
                    			
                    otherlv_24=(Token)match(input,12,FOLLOW_15); 

                    				newLeafNode(otherlv_24, grammarAccess.getFarmAccess().getLeftCurlyBracketKeyword_12_1());
                    			
                    // InternalMyDsl.g:311:4: ( (lv_ai_25_0= ruleAI ) )
                    // InternalMyDsl.g:312:5: (lv_ai_25_0= ruleAI )
                    {
                    // InternalMyDsl.g:312:5: (lv_ai_25_0= ruleAI )
                    // InternalMyDsl.g:313:6: lv_ai_25_0= ruleAI
                    {

                    						newCompositeNode(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_2_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_ai_25_0=ruleAI();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFarmRule());
                    						}
                    						add(
                    							current,
                    							"ai",
                    							lv_ai_25_0,
                    							"org.xtext.example.mydsl.MyDsl.AI");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:330:4: (otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==15) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalMyDsl.g:331:5: otherlv_26= ',' ( (lv_ai_27_0= ruleAI ) )
                    	    {
                    	    otherlv_26=(Token)match(input,15,FOLLOW_15); 

                    	    					newLeafNode(otherlv_26, grammarAccess.getFarmAccess().getCommaKeyword_12_3_0());
                    	    				
                    	    // InternalMyDsl.g:335:5: ( (lv_ai_27_0= ruleAI ) )
                    	    // InternalMyDsl.g:336:6: (lv_ai_27_0= ruleAI )
                    	    {
                    	    // InternalMyDsl.g:336:6: (lv_ai_27_0= ruleAI )
                    	    // InternalMyDsl.g:337:7: lv_ai_27_0= ruleAI
                    	    {

                    	    							newCompositeNode(grammarAccess.getFarmAccess().getAiAIParserRuleCall_12_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_ai_27_0=ruleAI();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getFarmRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"ai",
                    	    								lv_ai_27_0,
                    	    								"org.xtext.example.mydsl.MyDsl.AI");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    otherlv_28=(Token)match(input,16,FOLLOW_16); 

                    				newLeafNode(otherlv_28, grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_12_4());
                    			

                    }
                    break;

            }

            otherlv_29=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_29, grammarAccess.getFarmAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFarm"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:368:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyDsl.g:368:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyDsl.g:369:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:375:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:381:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyDsl.g:382:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyDsl.g:382:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_ID) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:383:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:391:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleCrate"
    // InternalMyDsl.g:402:1: entryRuleCrate returns [EObject current=null] : iv_ruleCrate= ruleCrate EOF ;
    public final EObject entryRuleCrate() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCrate = null;


        try {
            // InternalMyDsl.g:402:46: (iv_ruleCrate= ruleCrate EOF )
            // InternalMyDsl.g:403:2: iv_ruleCrate= ruleCrate EOF
            {
             newCompositeNode(grammarAccess.getCrateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCrate=ruleCrate();

            state._fsp--;

             current =iv_ruleCrate; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCrate"


    // $ANTLR start "ruleCrate"
    // InternalMyDsl.g:409:1: ruleCrate returns [EObject current=null] : (otherlv_0= 'Crate' otherlv_1= '{' (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )? otherlv_4= 'light' otherlv_5= '{' ( (lv_light_6_0= ruleLight ) ) (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )* otherlv_9= '}' otherlv_10= 'humiditysensor' ( (lv_humiditysensor_11_0= ruleHumiditySensor ) ) otherlv_12= 'temperaturesensor' ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) ) otherlv_14= 'soilsenor' ( (lv_soilsenor_15_0= ruleSoilSensor ) ) otherlv_16= 'cropType' ( (lv_cropType_17_0= ruleCrop ) ) otherlv_18= '}' ) ;
    public final EObject ruleCrate() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        AntlrDatatypeRuleToken lv_id_3_0 = null;

        EObject lv_light_6_0 = null;

        EObject lv_light_8_0 = null;

        EObject lv_humiditysensor_11_0 = null;

        EObject lv_temperaturesensor_13_0 = null;

        EObject lv_soilsenor_15_0 = null;

        EObject lv_cropType_17_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:415:2: ( (otherlv_0= 'Crate' otherlv_1= '{' (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )? otherlv_4= 'light' otherlv_5= '{' ( (lv_light_6_0= ruleLight ) ) (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )* otherlv_9= '}' otherlv_10= 'humiditysensor' ( (lv_humiditysensor_11_0= ruleHumiditySensor ) ) otherlv_12= 'temperaturesensor' ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) ) otherlv_14= 'soilsenor' ( (lv_soilsenor_15_0= ruleSoilSensor ) ) otherlv_16= 'cropType' ( (lv_cropType_17_0= ruleCrop ) ) otherlv_18= '}' ) )
            // InternalMyDsl.g:416:2: (otherlv_0= 'Crate' otherlv_1= '{' (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )? otherlv_4= 'light' otherlv_5= '{' ( (lv_light_6_0= ruleLight ) ) (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )* otherlv_9= '}' otherlv_10= 'humiditysensor' ( (lv_humiditysensor_11_0= ruleHumiditySensor ) ) otherlv_12= 'temperaturesensor' ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) ) otherlv_14= 'soilsenor' ( (lv_soilsenor_15_0= ruleSoilSensor ) ) otherlv_16= 'cropType' ( (lv_cropType_17_0= ruleCrop ) ) otherlv_18= '}' )
            {
            // InternalMyDsl.g:416:2: (otherlv_0= 'Crate' otherlv_1= '{' (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )? otherlv_4= 'light' otherlv_5= '{' ( (lv_light_6_0= ruleLight ) ) (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )* otherlv_9= '}' otherlv_10= 'humiditysensor' ( (lv_humiditysensor_11_0= ruleHumiditySensor ) ) otherlv_12= 'temperaturesensor' ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) ) otherlv_14= 'soilsenor' ( (lv_soilsenor_15_0= ruleSoilSensor ) ) otherlv_16= 'cropType' ( (lv_cropType_17_0= ruleCrop ) ) otherlv_18= '}' )
            // InternalMyDsl.g:417:3: otherlv_0= 'Crate' otherlv_1= '{' (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )? otherlv_4= 'light' otherlv_5= '{' ( (lv_light_6_0= ruleLight ) ) (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )* otherlv_9= '}' otherlv_10= 'humiditysensor' ( (lv_humiditysensor_11_0= ruleHumiditySensor ) ) otherlv_12= 'temperaturesensor' ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) ) otherlv_14= 'soilsenor' ( (lv_soilsenor_15_0= ruleSoilSensor ) ) otherlv_16= 'cropType' ( (lv_cropType_17_0= ruleCrop ) ) otherlv_18= '}'
            {
            otherlv_0=(Token)match(input,20,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getCrateAccess().getCrateKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_17); 

            			newLeafNode(otherlv_1, grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyDsl.g:425:3: (otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==21) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:426:4: otherlv_2= 'id' ( (lv_id_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,21,FOLLOW_3); 

                    				newLeafNode(otherlv_2, grammarAccess.getCrateAccess().getIdKeyword_2_0());
                    			
                    // InternalMyDsl.g:430:4: ( (lv_id_3_0= ruleEString ) )
                    // InternalMyDsl.g:431:5: (lv_id_3_0= ruleEString )
                    {
                    // InternalMyDsl.g:431:5: (lv_id_3_0= ruleEString )
                    // InternalMyDsl.g:432:6: lv_id_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getCrateAccess().getIdEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_id_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCrateRule());
                    						}
                    						set(
                    							current,
                    							"id",
                    							lv_id_3_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,22,FOLLOW_4); 

            			newLeafNode(otherlv_4, grammarAccess.getCrateAccess().getLightKeyword_3());
            		
            otherlv_5=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_5, grammarAccess.getCrateAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalMyDsl.g:458:3: ( (lv_light_6_0= ruleLight ) )
            // InternalMyDsl.g:459:4: (lv_light_6_0= ruleLight )
            {
            // InternalMyDsl.g:459:4: (lv_light_6_0= ruleLight )
            // InternalMyDsl.g:460:5: lv_light_6_0= ruleLight
            {

            					newCompositeNode(grammarAccess.getCrateAccess().getLightLightParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_9);
            lv_light_6_0=ruleLight();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCrateRule());
            					}
            					add(
            						current,
            						"light",
            						lv_light_6_0,
            						"org.xtext.example.mydsl.MyDsl.Light");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:477:3: (otherlv_7= ',' ( (lv_light_8_0= ruleLight ) ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==15) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalMyDsl.g:478:4: otherlv_7= ',' ( (lv_light_8_0= ruleLight ) )
            	    {
            	    otherlv_7=(Token)match(input,15,FOLLOW_11); 

            	    				newLeafNode(otherlv_7, grammarAccess.getCrateAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalMyDsl.g:482:4: ( (lv_light_8_0= ruleLight ) )
            	    // InternalMyDsl.g:483:5: (lv_light_8_0= ruleLight )
            	    {
            	    // InternalMyDsl.g:483:5: (lv_light_8_0= ruleLight )
            	    // InternalMyDsl.g:484:6: lv_light_8_0= ruleLight
            	    {

            	    						newCompositeNode(grammarAccess.getCrateAccess().getLightLightParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_9);
            	    lv_light_8_0=ruleLight();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getCrateRule());
            	    						}
            	    						add(
            	    							current,
            	    							"light",
            	    							lv_light_8_0,
            	    							"org.xtext.example.mydsl.MyDsl.Light");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            otherlv_9=(Token)match(input,16,FOLLOW_19); 

            			newLeafNode(otherlv_9, grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_7());
            		
            otherlv_10=(Token)match(input,23,FOLLOW_11); 

            			newLeafNode(otherlv_10, grammarAccess.getCrateAccess().getHumiditysensorKeyword_8());
            		
            // InternalMyDsl.g:510:3: ( (lv_humiditysensor_11_0= ruleHumiditySensor ) )
            // InternalMyDsl.g:511:4: (lv_humiditysensor_11_0= ruleHumiditySensor )
            {
            // InternalMyDsl.g:511:4: (lv_humiditysensor_11_0= ruleHumiditySensor )
            // InternalMyDsl.g:512:5: lv_humiditysensor_11_0= ruleHumiditySensor
            {

            					newCompositeNode(grammarAccess.getCrateAccess().getHumiditysensorHumiditySensorParserRuleCall_9_0());
            				
            pushFollow(FOLLOW_20);
            lv_humiditysensor_11_0=ruleHumiditySensor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCrateRule());
            					}
            					set(
            						current,
            						"humiditysensor",
            						lv_humiditysensor_11_0,
            						"org.xtext.example.mydsl.MyDsl.HumiditySensor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_12=(Token)match(input,24,FOLLOW_21); 

            			newLeafNode(otherlv_12, grammarAccess.getCrateAccess().getTemperaturesensorKeyword_10());
            		
            // InternalMyDsl.g:533:3: ( (lv_temperaturesensor_13_0= ruleTemperatureSensosor ) )
            // InternalMyDsl.g:534:4: (lv_temperaturesensor_13_0= ruleTemperatureSensosor )
            {
            // InternalMyDsl.g:534:4: (lv_temperaturesensor_13_0= ruleTemperatureSensosor )
            // InternalMyDsl.g:535:5: lv_temperaturesensor_13_0= ruleTemperatureSensosor
            {

            					newCompositeNode(grammarAccess.getCrateAccess().getTemperaturesensorTemperatureSensosorParserRuleCall_11_0());
            				
            pushFollow(FOLLOW_22);
            lv_temperaturesensor_13_0=ruleTemperatureSensosor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCrateRule());
            					}
            					set(
            						current,
            						"temperaturesensor",
            						lv_temperaturesensor_13_0,
            						"org.xtext.example.mydsl.MyDsl.TemperatureSensosor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_14=(Token)match(input,25,FOLLOW_23); 

            			newLeafNode(otherlv_14, grammarAccess.getCrateAccess().getSoilsenorKeyword_12());
            		
            // InternalMyDsl.g:556:3: ( (lv_soilsenor_15_0= ruleSoilSensor ) )
            // InternalMyDsl.g:557:4: (lv_soilsenor_15_0= ruleSoilSensor )
            {
            // InternalMyDsl.g:557:4: (lv_soilsenor_15_0= ruleSoilSensor )
            // InternalMyDsl.g:558:5: lv_soilsenor_15_0= ruleSoilSensor
            {

            					newCompositeNode(grammarAccess.getCrateAccess().getSoilsenorSoilSensorParserRuleCall_13_0());
            				
            pushFollow(FOLLOW_24);
            lv_soilsenor_15_0=ruleSoilSensor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCrateRule());
            					}
            					set(
            						current,
            						"soilsenor",
            						lv_soilsenor_15_0,
            						"org.xtext.example.mydsl.MyDsl.SoilSensor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_16=(Token)match(input,26,FOLLOW_25); 

            			newLeafNode(otherlv_16, grammarAccess.getCrateAccess().getCropTypeKeyword_14());
            		
            // InternalMyDsl.g:579:3: ( (lv_cropType_17_0= ruleCrop ) )
            // InternalMyDsl.g:580:4: (lv_cropType_17_0= ruleCrop )
            {
            // InternalMyDsl.g:580:4: (lv_cropType_17_0= ruleCrop )
            // InternalMyDsl.g:581:5: lv_cropType_17_0= ruleCrop
            {

            					newCompositeNode(grammarAccess.getCrateAccess().getCropTypeCropParserRuleCall_15_0());
            				
            pushFollow(FOLLOW_16);
            lv_cropType_17_0=ruleCrop();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCrateRule());
            					}
            					set(
            						current,
            						"cropType",
            						lv_cropType_17_0,
            						"org.xtext.example.mydsl.MyDsl.Crop");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_18=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getCrateAccess().getRightCurlyBracketKeyword_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCrate"


    // $ANTLR start "entryRuleDrone"
    // InternalMyDsl.g:606:1: entryRuleDrone returns [EObject current=null] : iv_ruleDrone= ruleDrone EOF ;
    public final EObject entryRuleDrone() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDrone = null;


        try {
            // InternalMyDsl.g:606:46: (iv_ruleDrone= ruleDrone EOF )
            // InternalMyDsl.g:607:2: iv_ruleDrone= ruleDrone EOF
            {
             newCompositeNode(grammarAccess.getDroneRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDrone=ruleDrone();

            state._fsp--;

             current =iv_ruleDrone; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDrone"


    // $ANTLR start "ruleDrone"
    // InternalMyDsl.g:613:1: ruleDrone returns [EObject current=null] : ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Drone' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) ;
    public final EObject ruleDrone() throws RecognitionException {
        EObject current = null;

        Token lv_TurnOn_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        Enumerator lv_DroneMonitoring_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:619:2: ( ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Drone' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) )
            // InternalMyDsl.g:620:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Drone' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            {
            // InternalMyDsl.g:620:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Drone' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            // InternalMyDsl.g:621:3: ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Drone' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}'
            {
            // InternalMyDsl.g:621:3: ( (lv_TurnOn_0_0= 'TurnOn' ) )
            // InternalMyDsl.g:622:4: (lv_TurnOn_0_0= 'TurnOn' )
            {
            // InternalMyDsl.g:622:4: (lv_TurnOn_0_0= 'TurnOn' )
            // InternalMyDsl.g:623:5: lv_TurnOn_0_0= 'TurnOn'
            {
            lv_TurnOn_0_0=(Token)match(input,27,FOLLOW_26); 

            					newLeafNode(lv_TurnOn_0_0, grammarAccess.getDroneAccess().getTurnOnTurnOnKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getDroneRule());
            					}
            					setWithLastConsumed(current, "TurnOn", lv_TurnOn_0_0 != null, "TurnOn");
            				

            }


            }

            otherlv_1=(Token)match(input,28,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getDroneAccess().getDroneKeyword_1());
            		
            // InternalMyDsl.g:639:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:640:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:640:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:641:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getDroneAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDroneRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_27); 

            			newLeafNode(otherlv_3, grammarAccess.getDroneAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:662:3: (otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==29) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:663:4: otherlv_4= 'DroneMonitoring' ( (lv_DroneMonitoring_5_0= ruleFocusArea ) )
                    {
                    otherlv_4=(Token)match(input,29,FOLLOW_28); 

                    				newLeafNode(otherlv_4, grammarAccess.getDroneAccess().getDroneMonitoringKeyword_4_0());
                    			
                    // InternalMyDsl.g:667:4: ( (lv_DroneMonitoring_5_0= ruleFocusArea ) )
                    // InternalMyDsl.g:668:5: (lv_DroneMonitoring_5_0= ruleFocusArea )
                    {
                    // InternalMyDsl.g:668:5: (lv_DroneMonitoring_5_0= ruleFocusArea )
                    // InternalMyDsl.g:669:6: lv_DroneMonitoring_5_0= ruleFocusArea
                    {

                    						newCompositeNode(grammarAccess.getDroneAccess().getDroneMonitoringFocusAreaEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_DroneMonitoring_5_0=ruleFocusArea();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDroneRule());
                    						}
                    						set(
                    							current,
                    							"DroneMonitoring",
                    							lv_DroneMonitoring_5_0,
                    							"org.xtext.example.mydsl.MyDsl.FocusArea");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getDroneAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDrone"


    // $ANTLR start "entryRuleCamera"
    // InternalMyDsl.g:695:1: entryRuleCamera returns [EObject current=null] : iv_ruleCamera= ruleCamera EOF ;
    public final EObject entryRuleCamera() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCamera = null;


        try {
            // InternalMyDsl.g:695:47: (iv_ruleCamera= ruleCamera EOF )
            // InternalMyDsl.g:696:2: iv_ruleCamera= ruleCamera EOF
            {
             newCompositeNode(grammarAccess.getCameraRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCamera=ruleCamera();

            state._fsp--;

             current =iv_ruleCamera; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCamera"


    // $ANTLR start "ruleCamera"
    // InternalMyDsl.g:702:1: ruleCamera returns [EObject current=null] : ( () otherlv_1= 'Camera' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) ;
    public final EObject ruleCamera() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        Enumerator lv_CameraFocus_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:708:2: ( ( () otherlv_1= 'Camera' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) )
            // InternalMyDsl.g:709:2: ( () otherlv_1= 'Camera' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            {
            // InternalMyDsl.g:709:2: ( () otherlv_1= 'Camera' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            // InternalMyDsl.g:710:3: () otherlv_1= 'Camera' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )? otherlv_6= '}'
            {
            // InternalMyDsl.g:710:3: ()
            // InternalMyDsl.g:711:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCameraAccess().getCameraAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,30,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getCameraAccess().getCameraKeyword_1());
            		
            // InternalMyDsl.g:721:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:722:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:722:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:723:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getCameraAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCameraRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_29); 

            			newLeafNode(otherlv_3, grammarAccess.getCameraAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:744:3: (otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==31) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:745:4: otherlv_4= 'CameraFocus' ( (lv_CameraFocus_5_0= ruleFocusArea ) )
                    {
                    otherlv_4=(Token)match(input,31,FOLLOW_28); 

                    				newLeafNode(otherlv_4, grammarAccess.getCameraAccess().getCameraFocusKeyword_4_0());
                    			
                    // InternalMyDsl.g:749:4: ( (lv_CameraFocus_5_0= ruleFocusArea ) )
                    // InternalMyDsl.g:750:5: (lv_CameraFocus_5_0= ruleFocusArea )
                    {
                    // InternalMyDsl.g:750:5: (lv_CameraFocus_5_0= ruleFocusArea )
                    // InternalMyDsl.g:751:6: lv_CameraFocus_5_0= ruleFocusArea
                    {

                    						newCompositeNode(grammarAccess.getCameraAccess().getCameraFocusFocusAreaEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_CameraFocus_5_0=ruleFocusArea();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCameraRule());
                    						}
                    						set(
                    							current,
                    							"CameraFocus",
                    							lv_CameraFocus_5_0,
                    							"org.xtext.example.mydsl.MyDsl.FocusArea");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getCameraAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCamera"


    // $ANTLR start "entryRuleAI"
    // InternalMyDsl.g:777:1: entryRuleAI returns [EObject current=null] : iv_ruleAI= ruleAI EOF ;
    public final EObject entryRuleAI() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAI = null;


        try {
            // InternalMyDsl.g:777:43: (iv_ruleAI= ruleAI EOF )
            // InternalMyDsl.g:778:2: iv_ruleAI= ruleAI EOF
            {
             newCompositeNode(grammarAccess.getAIRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAI=ruleAI();

            state._fsp--;

             current =iv_ruleAI; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAI"


    // $ANTLR start "ruleAI"
    // InternalMyDsl.g:784:1: ruleAI returns [EObject current=null] : ( () otherlv_1= 'AI' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) ;
    public final EObject ruleAI() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        Enumerator lv_AIMonitoring_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:790:2: ( ( () otherlv_1= 'AI' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' ) )
            // InternalMyDsl.g:791:2: ( () otherlv_1= 'AI' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            {
            // InternalMyDsl.g:791:2: ( () otherlv_1= 'AI' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}' )
            // InternalMyDsl.g:792:3: () otherlv_1= 'AI' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )? otherlv_6= '}'
            {
            // InternalMyDsl.g:792:3: ()
            // InternalMyDsl.g:793:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAIAccess().getAIAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,32,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getAIAccess().getAIKeyword_1());
            		
            // InternalMyDsl.g:803:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:804:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:804:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:805:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAIAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAIRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_30); 

            			newLeafNode(otherlv_3, grammarAccess.getAIAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:826:3: (otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==33) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:827:4: otherlv_4= 'AIMonitoring' ( (lv_AIMonitoring_5_0= ruleFocusArea ) )
                    {
                    otherlv_4=(Token)match(input,33,FOLLOW_28); 

                    				newLeafNode(otherlv_4, grammarAccess.getAIAccess().getAIMonitoringKeyword_4_0());
                    			
                    // InternalMyDsl.g:831:4: ( (lv_AIMonitoring_5_0= ruleFocusArea ) )
                    // InternalMyDsl.g:832:5: (lv_AIMonitoring_5_0= ruleFocusArea )
                    {
                    // InternalMyDsl.g:832:5: (lv_AIMonitoring_5_0= ruleFocusArea )
                    // InternalMyDsl.g:833:6: lv_AIMonitoring_5_0= ruleFocusArea
                    {

                    						newCompositeNode(grammarAccess.getAIAccess().getAIMonitoringFocusAreaEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_AIMonitoring_5_0=ruleFocusArea();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAIRule());
                    						}
                    						set(
                    							current,
                    							"AIMonitoring",
                    							lv_AIMonitoring_5_0,
                    							"org.xtext.example.mydsl.MyDsl.FocusArea");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getAIAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAI"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:859:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMyDsl.g:859:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMyDsl.g:860:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:866:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:872:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMyDsl.g:873:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMyDsl.g:873:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMyDsl.g:874:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMyDsl.g:874:3: (kw= '-' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==34) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:875:4: kw= '-'
                    {
                    kw=(Token)match(input,34,FOLLOW_31); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleLight"
    // InternalMyDsl.g:892:1: entryRuleLight returns [EObject current=null] : iv_ruleLight= ruleLight EOF ;
    public final EObject entryRuleLight() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLight = null;


        try {
            // InternalMyDsl.g:892:46: (iv_ruleLight= ruleLight EOF )
            // InternalMyDsl.g:893:2: iv_ruleLight= ruleLight EOF
            {
             newCompositeNode(grammarAccess.getLightRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLight=ruleLight();

            state._fsp--;

             current =iv_ruleLight; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLight"


    // $ANTLR start "ruleLight"
    // InternalMyDsl.g:899:1: ruleLight returns [EObject current=null] : ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Light' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )? otherlv_6= '}' ) ;
    public final EObject ruleLight() throws RecognitionException {
        EObject current = null;

        Token lv_TurnOn_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        Enumerator lv_TypeLight_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:905:2: ( ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Light' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )? otherlv_6= '}' ) )
            // InternalMyDsl.g:906:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Light' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )? otherlv_6= '}' )
            {
            // InternalMyDsl.g:906:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Light' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )? otherlv_6= '}' )
            // InternalMyDsl.g:907:3: ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'Light' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )? otherlv_6= '}'
            {
            // InternalMyDsl.g:907:3: ( (lv_TurnOn_0_0= 'TurnOn' ) )
            // InternalMyDsl.g:908:4: (lv_TurnOn_0_0= 'TurnOn' )
            {
            // InternalMyDsl.g:908:4: (lv_TurnOn_0_0= 'TurnOn' )
            // InternalMyDsl.g:909:5: lv_TurnOn_0_0= 'TurnOn'
            {
            lv_TurnOn_0_0=(Token)match(input,27,FOLLOW_32); 

            					newLeafNode(lv_TurnOn_0_0, grammarAccess.getLightAccess().getTurnOnTurnOnKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLightRule());
            					}
            					setWithLastConsumed(current, "TurnOn", lv_TurnOn_0_0 != null, "TurnOn");
            				

            }


            }

            otherlv_1=(Token)match(input,35,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getLightAccess().getLightKeyword_1());
            		
            // InternalMyDsl.g:925:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:926:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:926:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:927:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getLightAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLightRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.xtext.example.mydsl.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_33); 

            			newLeafNode(otherlv_3, grammarAccess.getLightAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalMyDsl.g:948:3: (otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==36) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:949:4: otherlv_4= 'TypeLight' ( (lv_TypeLight_5_0= ruletypelight ) )
                    {
                    otherlv_4=(Token)match(input,36,FOLLOW_34); 

                    				newLeafNode(otherlv_4, grammarAccess.getLightAccess().getTypeLightKeyword_4_0());
                    			
                    // InternalMyDsl.g:953:4: ( (lv_TypeLight_5_0= ruletypelight ) )
                    // InternalMyDsl.g:954:5: (lv_TypeLight_5_0= ruletypelight )
                    {
                    // InternalMyDsl.g:954:5: (lv_TypeLight_5_0= ruletypelight )
                    // InternalMyDsl.g:955:6: lv_TypeLight_5_0= ruletypelight
                    {

                    						newCompositeNode(grammarAccess.getLightAccess().getTypeLightTypelightEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_TypeLight_5_0=ruletypelight();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLightRule());
                    						}
                    						set(
                    							current,
                    							"TypeLight",
                    							lv_TypeLight_5_0,
                    							"org.xtext.example.mydsl.MyDsl.typelight");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getLightAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLight"


    // $ANTLR start "entryRuleHumiditySensor"
    // InternalMyDsl.g:981:1: entryRuleHumiditySensor returns [EObject current=null] : iv_ruleHumiditySensor= ruleHumiditySensor EOF ;
    public final EObject entryRuleHumiditySensor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHumiditySensor = null;


        try {
            // InternalMyDsl.g:981:55: (iv_ruleHumiditySensor= ruleHumiditySensor EOF )
            // InternalMyDsl.g:982:2: iv_ruleHumiditySensor= ruleHumiditySensor EOF
            {
             newCompositeNode(grammarAccess.getHumiditySensorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHumiditySensor=ruleHumiditySensor();

            state._fsp--;

             current =iv_ruleHumiditySensor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHumiditySensor"


    // $ANTLR start "ruleHumiditySensor"
    // InternalMyDsl.g:988:1: ruleHumiditySensor returns [EObject current=null] : ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'HumiditySensor' otherlv_2= '{' otherlv_3= 'HumidityValueInPercentage' ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) ) otherlv_5= '}' ) ;
    public final EObject ruleHumiditySensor() throws RecognitionException {
        EObject current = null;

        Token lv_TurnOn_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_HumidityValueInPercentage_4_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:994:2: ( ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'HumiditySensor' otherlv_2= '{' otherlv_3= 'HumidityValueInPercentage' ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) ) otherlv_5= '}' ) )
            // InternalMyDsl.g:995:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'HumiditySensor' otherlv_2= '{' otherlv_3= 'HumidityValueInPercentage' ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) ) otherlv_5= '}' )
            {
            // InternalMyDsl.g:995:2: ( ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'HumiditySensor' otherlv_2= '{' otherlv_3= 'HumidityValueInPercentage' ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) ) otherlv_5= '}' )
            // InternalMyDsl.g:996:3: ( (lv_TurnOn_0_0= 'TurnOn' ) ) otherlv_1= 'HumiditySensor' otherlv_2= '{' otherlv_3= 'HumidityValueInPercentage' ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) ) otherlv_5= '}'
            {
            // InternalMyDsl.g:996:3: ( (lv_TurnOn_0_0= 'TurnOn' ) )
            // InternalMyDsl.g:997:4: (lv_TurnOn_0_0= 'TurnOn' )
            {
            // InternalMyDsl.g:997:4: (lv_TurnOn_0_0= 'TurnOn' )
            // InternalMyDsl.g:998:5: lv_TurnOn_0_0= 'TurnOn'
            {
            lv_TurnOn_0_0=(Token)match(input,27,FOLLOW_35); 

            					newLeafNode(lv_TurnOn_0_0, grammarAccess.getHumiditySensorAccess().getTurnOnTurnOnKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getHumiditySensorRule());
            					}
            					setWithLastConsumed(current, "TurnOn", lv_TurnOn_0_0 != null, "TurnOn");
            				

            }


            }

            otherlv_1=(Token)match(input,37,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getHumiditySensorAccess().getHumiditySensorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_36); 

            			newLeafNode(otherlv_2, grammarAccess.getHumiditySensorAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,38,FOLLOW_37); 

            			newLeafNode(otherlv_3, grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageKeyword_3());
            		
            // InternalMyDsl.g:1022:3: ( (lv_HumidityValueInPercentage_4_0= ruleEFloat ) )
            // InternalMyDsl.g:1023:4: (lv_HumidityValueInPercentage_4_0= ruleEFloat )
            {
            // InternalMyDsl.g:1023:4: (lv_HumidityValueInPercentage_4_0= ruleEFloat )
            // InternalMyDsl.g:1024:5: lv_HumidityValueInPercentage_4_0= ruleEFloat
            {

            					newCompositeNode(grammarAccess.getHumiditySensorAccess().getHumidityValueInPercentageEFloatParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_16);
            lv_HumidityValueInPercentage_4_0=ruleEFloat();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getHumiditySensorRule());
            					}
            					set(
            						current,
            						"HumidityValueInPercentage",
            						lv_HumidityValueInPercentage_4_0,
            						"org.xtext.example.mydsl.MyDsl.EFloat");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getHumiditySensorAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHumiditySensor"


    // $ANTLR start "entryRuleTemperatureSensosor"
    // InternalMyDsl.g:1049:1: entryRuleTemperatureSensosor returns [EObject current=null] : iv_ruleTemperatureSensosor= ruleTemperatureSensosor EOF ;
    public final EObject entryRuleTemperatureSensosor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTemperatureSensosor = null;


        try {
            // InternalMyDsl.g:1049:60: (iv_ruleTemperatureSensosor= ruleTemperatureSensosor EOF )
            // InternalMyDsl.g:1050:2: iv_ruleTemperatureSensosor= ruleTemperatureSensosor EOF
            {
             newCompositeNode(grammarAccess.getTemperatureSensosorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTemperatureSensosor=ruleTemperatureSensosor();

            state._fsp--;

             current =iv_ruleTemperatureSensosor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTemperatureSensosor"


    // $ANTLR start "ruleTemperatureSensosor"
    // InternalMyDsl.g:1056:1: ruleTemperatureSensosor returns [EObject current=null] : ( ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) ) otherlv_1= 'TemperatureSensosor' otherlv_2= '{' otherlv_3= 'CrateTemperature' ( (lv_CrateTemperature_4_0= ruleEFloat ) ) otherlv_5= 'PlantTemperature' ( (lv_PlantTemperature_6_0= ruleEFloat ) ) otherlv_7= '}' ) ;
    public final EObject ruleTemperatureSensosor() throws RecognitionException {
        EObject current = null;

        Token lv_TemperatureinDegreeCelcius_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        AntlrDatatypeRuleToken lv_CrateTemperature_4_0 = null;

        AntlrDatatypeRuleToken lv_PlantTemperature_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1062:2: ( ( ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) ) otherlv_1= 'TemperatureSensosor' otherlv_2= '{' otherlv_3= 'CrateTemperature' ( (lv_CrateTemperature_4_0= ruleEFloat ) ) otherlv_5= 'PlantTemperature' ( (lv_PlantTemperature_6_0= ruleEFloat ) ) otherlv_7= '}' ) )
            // InternalMyDsl.g:1063:2: ( ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) ) otherlv_1= 'TemperatureSensosor' otherlv_2= '{' otherlv_3= 'CrateTemperature' ( (lv_CrateTemperature_4_0= ruleEFloat ) ) otherlv_5= 'PlantTemperature' ( (lv_PlantTemperature_6_0= ruleEFloat ) ) otherlv_7= '}' )
            {
            // InternalMyDsl.g:1063:2: ( ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) ) otherlv_1= 'TemperatureSensosor' otherlv_2= '{' otherlv_3= 'CrateTemperature' ( (lv_CrateTemperature_4_0= ruleEFloat ) ) otherlv_5= 'PlantTemperature' ( (lv_PlantTemperature_6_0= ruleEFloat ) ) otherlv_7= '}' )
            // InternalMyDsl.g:1064:3: ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) ) otherlv_1= 'TemperatureSensosor' otherlv_2= '{' otherlv_3= 'CrateTemperature' ( (lv_CrateTemperature_4_0= ruleEFloat ) ) otherlv_5= 'PlantTemperature' ( (lv_PlantTemperature_6_0= ruleEFloat ) ) otherlv_7= '}'
            {
            // InternalMyDsl.g:1064:3: ( (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' ) )
            // InternalMyDsl.g:1065:4: (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' )
            {
            // InternalMyDsl.g:1065:4: (lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius' )
            // InternalMyDsl.g:1066:5: lv_TemperatureinDegreeCelcius_0_0= 'TemperatureinDegreeCelcius'
            {
            lv_TemperatureinDegreeCelcius_0_0=(Token)match(input,39,FOLLOW_38); 

            					newLeafNode(lv_TemperatureinDegreeCelcius_0_0, grammarAccess.getTemperatureSensosorAccess().getTemperatureinDegreeCelciusTemperatureinDegreeCelciusKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getTemperatureSensosorRule());
            					}
            					setWithLastConsumed(current, "TemperatureinDegreeCelcius", lv_TemperatureinDegreeCelcius_0_0 != null, "TemperatureinDegreeCelcius");
            				

            }


            }

            otherlv_1=(Token)match(input,40,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getTemperatureSensosorAccess().getTemperatureSensosorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_39); 

            			newLeafNode(otherlv_2, grammarAccess.getTemperatureSensosorAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,41,FOLLOW_37); 

            			newLeafNode(otherlv_3, grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureKeyword_3());
            		
            // InternalMyDsl.g:1090:3: ( (lv_CrateTemperature_4_0= ruleEFloat ) )
            // InternalMyDsl.g:1091:4: (lv_CrateTemperature_4_0= ruleEFloat )
            {
            // InternalMyDsl.g:1091:4: (lv_CrateTemperature_4_0= ruleEFloat )
            // InternalMyDsl.g:1092:5: lv_CrateTemperature_4_0= ruleEFloat
            {

            					newCompositeNode(grammarAccess.getTemperatureSensosorAccess().getCrateTemperatureEFloatParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_40);
            lv_CrateTemperature_4_0=ruleEFloat();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTemperatureSensosorRule());
            					}
            					set(
            						current,
            						"CrateTemperature",
            						lv_CrateTemperature_4_0,
            						"org.xtext.example.mydsl.MyDsl.EFloat");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,42,FOLLOW_37); 

            			newLeafNode(otherlv_5, grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureKeyword_5());
            		
            // InternalMyDsl.g:1113:3: ( (lv_PlantTemperature_6_0= ruleEFloat ) )
            // InternalMyDsl.g:1114:4: (lv_PlantTemperature_6_0= ruleEFloat )
            {
            // InternalMyDsl.g:1114:4: (lv_PlantTemperature_6_0= ruleEFloat )
            // InternalMyDsl.g:1115:5: lv_PlantTemperature_6_0= ruleEFloat
            {

            					newCompositeNode(grammarAccess.getTemperatureSensosorAccess().getPlantTemperatureEFloatParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_16);
            lv_PlantTemperature_6_0=ruleEFloat();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTemperatureSensosorRule());
            					}
            					set(
            						current,
            						"PlantTemperature",
            						lv_PlantTemperature_6_0,
            						"org.xtext.example.mydsl.MyDsl.EFloat");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getTemperatureSensosorAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTemperatureSensosor"


    // $ANTLR start "entryRuleSoilSensor"
    // InternalMyDsl.g:1140:1: entryRuleSoilSensor returns [EObject current=null] : iv_ruleSoilSensor= ruleSoilSensor EOF ;
    public final EObject entryRuleSoilSensor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSoilSensor = null;


        try {
            // InternalMyDsl.g:1140:51: (iv_ruleSoilSensor= ruleSoilSensor EOF )
            // InternalMyDsl.g:1141:2: iv_ruleSoilSensor= ruleSoilSensor EOF
            {
             newCompositeNode(grammarAccess.getSoilSensorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSoilSensor=ruleSoilSensor();

            state._fsp--;

             current =iv_ruleSoilSensor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSoilSensor"


    // $ANTLR start "ruleSoilSensor"
    // InternalMyDsl.g:1147:1: ruleSoilSensor returns [EObject current=null] : (otherlv_0= 'SoilSensor' otherlv_1= '{' otherlv_2= 'ph' ( (lv_ph_3_0= ruleEInt ) ) otherlv_4= 'SoilMoistureInPercentage' ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) ) otherlv_6= '}' ) ;
    public final EObject ruleSoilSensor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        AntlrDatatypeRuleToken lv_ph_3_0 = null;

        AntlrDatatypeRuleToken lv_SoilMoistureInPercentage_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1153:2: ( (otherlv_0= 'SoilSensor' otherlv_1= '{' otherlv_2= 'ph' ( (lv_ph_3_0= ruleEInt ) ) otherlv_4= 'SoilMoistureInPercentage' ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) ) otherlv_6= '}' ) )
            // InternalMyDsl.g:1154:2: (otherlv_0= 'SoilSensor' otherlv_1= '{' otherlv_2= 'ph' ( (lv_ph_3_0= ruleEInt ) ) otherlv_4= 'SoilMoistureInPercentage' ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) ) otherlv_6= '}' )
            {
            // InternalMyDsl.g:1154:2: (otherlv_0= 'SoilSensor' otherlv_1= '{' otherlv_2= 'ph' ( (lv_ph_3_0= ruleEInt ) ) otherlv_4= 'SoilMoistureInPercentage' ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) ) otherlv_6= '}' )
            // InternalMyDsl.g:1155:3: otherlv_0= 'SoilSensor' otherlv_1= '{' otherlv_2= 'ph' ( (lv_ph_3_0= ruleEInt ) ) otherlv_4= 'SoilMoistureInPercentage' ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) ) otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,43,FOLLOW_4); 

            			newLeafNode(otherlv_0, grammarAccess.getSoilSensorAccess().getSoilSensorKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_41); 

            			newLeafNode(otherlv_1, grammarAccess.getSoilSensorAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,44,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getSoilSensorAccess().getPhKeyword_2());
            		
            // InternalMyDsl.g:1167:3: ( (lv_ph_3_0= ruleEInt ) )
            // InternalMyDsl.g:1168:4: (lv_ph_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1168:4: (lv_ph_3_0= ruleEInt )
            // InternalMyDsl.g:1169:5: lv_ph_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getSoilSensorAccess().getPhEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_42);
            lv_ph_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSoilSensorRule());
            					}
            					set(
            						current,
            						"ph",
            						lv_ph_3_0,
            						"org.xtext.example.mydsl.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,45,FOLLOW_6); 

            			newLeafNode(otherlv_4, grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageKeyword_4());
            		
            // InternalMyDsl.g:1190:3: ( (lv_SoilMoistureInPercentage_5_0= ruleEInt ) )
            // InternalMyDsl.g:1191:4: (lv_SoilMoistureInPercentage_5_0= ruleEInt )
            {
            // InternalMyDsl.g:1191:4: (lv_SoilMoistureInPercentage_5_0= ruleEInt )
            // InternalMyDsl.g:1192:5: lv_SoilMoistureInPercentage_5_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getSoilSensorAccess().getSoilMoistureInPercentageEIntParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_16);
            lv_SoilMoistureInPercentage_5_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSoilSensorRule());
            					}
            					set(
            						current,
            						"SoilMoistureInPercentage",
            						lv_SoilMoistureInPercentage_5_0,
            						"org.xtext.example.mydsl.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getSoilSensorAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSoilSensor"


    // $ANTLR start "entryRuleCrop"
    // InternalMyDsl.g:1217:1: entryRuleCrop returns [EObject current=null] : iv_ruleCrop= ruleCrop EOF ;
    public final EObject entryRuleCrop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCrop = null;


        try {
            // InternalMyDsl.g:1217:45: (iv_ruleCrop= ruleCrop EOF )
            // InternalMyDsl.g:1218:2: iv_ruleCrop= ruleCrop EOF
            {
             newCompositeNode(grammarAccess.getCropRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCrop=ruleCrop();

            state._fsp--;

             current =iv_ruleCrop; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCrop"


    // $ANTLR start "ruleCrop"
    // InternalMyDsl.g:1224:1: ruleCrop returns [EObject current=null] : ( () otherlv_1= 'Crop' otherlv_2= '{' (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )? otherlv_5= '}' ) ;
    public final EObject ruleCrop() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Enumerator lv_Crop_4_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1230:2: ( ( () otherlv_1= 'Crop' otherlv_2= '{' (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )? otherlv_5= '}' ) )
            // InternalMyDsl.g:1231:2: ( () otherlv_1= 'Crop' otherlv_2= '{' (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )? otherlv_5= '}' )
            {
            // InternalMyDsl.g:1231:2: ( () otherlv_1= 'Crop' otherlv_2= '{' (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )? otherlv_5= '}' )
            // InternalMyDsl.g:1232:3: () otherlv_1= 'Crop' otherlv_2= '{' (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )? otherlv_5= '}'
            {
            // InternalMyDsl.g:1232:3: ()
            // InternalMyDsl.g:1233:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCropAccess().getCropAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,46,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getCropAccess().getCropKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_43); 

            			newLeafNode(otherlv_2, grammarAccess.getCropAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:1247:3: (otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==46) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:1248:4: otherlv_3= 'Crop' ( (lv_Crop_4_0= ruleCropType ) )
                    {
                    otherlv_3=(Token)match(input,46,FOLLOW_44); 

                    				newLeafNode(otherlv_3, grammarAccess.getCropAccess().getCropKeyword_3_0());
                    			
                    // InternalMyDsl.g:1252:4: ( (lv_Crop_4_0= ruleCropType ) )
                    // InternalMyDsl.g:1253:5: (lv_Crop_4_0= ruleCropType )
                    {
                    // InternalMyDsl.g:1253:5: (lv_Crop_4_0= ruleCropType )
                    // InternalMyDsl.g:1254:6: lv_Crop_4_0= ruleCropType
                    {

                    						newCompositeNode(grammarAccess.getCropAccess().getCropCropTypeEnumRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_Crop_4_0=ruleCropType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCropRule());
                    						}
                    						set(
                    							current,
                    							"Crop",
                    							lv_Crop_4_0,
                    							"org.xtext.example.mydsl.MyDsl.CropType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getCropAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCrop"


    // $ANTLR start "entryRuleEFloat"
    // InternalMyDsl.g:1280:1: entryRuleEFloat returns [String current=null] : iv_ruleEFloat= ruleEFloat EOF ;
    public final String entryRuleEFloat() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEFloat = null;


        try {
            // InternalMyDsl.g:1280:46: (iv_ruleEFloat= ruleEFloat EOF )
            // InternalMyDsl.g:1281:2: iv_ruleEFloat= ruleEFloat EOF
            {
             newCompositeNode(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEFloat=ruleEFloat();

            state._fsp--;

             current =iv_ruleEFloat.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalMyDsl.g:1287:1: ruleEFloat returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEFloat() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1293:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalMyDsl.g:1294:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalMyDsl.g:1294:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalMyDsl.g:1295:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalMyDsl.g:1295:3: (kw= '-' )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==34) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:1296:4: kw= '-'
                    {
                    kw=(Token)match(input,34,FOLLOW_45); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalMyDsl.g:1302:3: (this_INT_1= RULE_INT )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_INT) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:1303:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_46); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,47,FOLLOW_31); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEFloatAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_47); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3());
            		
            // InternalMyDsl.g:1323:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( ((LA21_0>=48 && LA21_0<=49)) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalMyDsl.g:1324:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalMyDsl.g:1324:4: (kw= 'E' | kw= 'e' )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==48) ) {
                        alt19=1;
                    }
                    else if ( (LA19_0==49) ) {
                        alt19=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalMyDsl.g:1325:5: kw= 'E'
                            {
                            kw=(Token)match(input,48,FOLLOW_6); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalMyDsl.g:1331:5: kw= 'e'
                            {
                            kw=(Token)match(input,49,FOLLOW_6); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalMyDsl.g:1337:4: (kw= '-' )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==34) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalMyDsl.g:1338:5: kw= '-'
                            {
                            kw=(Token)match(input,34,FOLLOW_31); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "ruletypelight"
    // InternalMyDsl.g:1356:1: ruletypelight returns [Enumerator current=null] : ( (enumLiteral_0= 'UVlight' ) | (enumLiteral_1= 'BlueLight' ) | (enumLiteral_2= 'RedLight' ) | (enumLiteral_3= 'GreenLight' ) ) ;
    public final Enumerator ruletypelight() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1362:2: ( ( (enumLiteral_0= 'UVlight' ) | (enumLiteral_1= 'BlueLight' ) | (enumLiteral_2= 'RedLight' ) | (enumLiteral_3= 'GreenLight' ) ) )
            // InternalMyDsl.g:1363:2: ( (enumLiteral_0= 'UVlight' ) | (enumLiteral_1= 'BlueLight' ) | (enumLiteral_2= 'RedLight' ) | (enumLiteral_3= 'GreenLight' ) )
            {
            // InternalMyDsl.g:1363:2: ( (enumLiteral_0= 'UVlight' ) | (enumLiteral_1= 'BlueLight' ) | (enumLiteral_2= 'RedLight' ) | (enumLiteral_3= 'GreenLight' ) )
            int alt22=4;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt22=1;
                }
                break;
            case 51:
                {
                alt22=2;
                }
                break;
            case 52:
                {
                alt22=3;
                }
                break;
            case 53:
                {
                alt22=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // InternalMyDsl.g:1364:3: (enumLiteral_0= 'UVlight' )
                    {
                    // InternalMyDsl.g:1364:3: (enumLiteral_0= 'UVlight' )
                    // InternalMyDsl.g:1365:4: enumLiteral_0= 'UVlight'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getTypelightAccess().getUVlightEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getTypelightAccess().getUVlightEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1372:3: (enumLiteral_1= 'BlueLight' )
                    {
                    // InternalMyDsl.g:1372:3: (enumLiteral_1= 'BlueLight' )
                    // InternalMyDsl.g:1373:4: enumLiteral_1= 'BlueLight'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getTypelightAccess().getBlueLightEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getTypelightAccess().getBlueLightEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1380:3: (enumLiteral_2= 'RedLight' )
                    {
                    // InternalMyDsl.g:1380:3: (enumLiteral_2= 'RedLight' )
                    // InternalMyDsl.g:1381:4: enumLiteral_2= 'RedLight'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getTypelightAccess().getRedLightEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getTypelightAccess().getRedLightEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1388:3: (enumLiteral_3= 'GreenLight' )
                    {
                    // InternalMyDsl.g:1388:3: (enumLiteral_3= 'GreenLight' )
                    // InternalMyDsl.g:1389:4: enumLiteral_3= 'GreenLight'
                    {
                    enumLiteral_3=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getTypelightAccess().getGreenLightEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getTypelightAccess().getGreenLightEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruletypelight"


    // $ANTLR start "ruleCropType"
    // InternalMyDsl.g:1399:1: ruleCropType returns [Enumerator current=null] : ( (enumLiteral_0= 'Tomato' ) | (enumLiteral_1= 'Cabbage' ) | (enumLiteral_2= 'Potato' ) ) ;
    public final Enumerator ruleCropType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1405:2: ( ( (enumLiteral_0= 'Tomato' ) | (enumLiteral_1= 'Cabbage' ) | (enumLiteral_2= 'Potato' ) ) )
            // InternalMyDsl.g:1406:2: ( (enumLiteral_0= 'Tomato' ) | (enumLiteral_1= 'Cabbage' ) | (enumLiteral_2= 'Potato' ) )
            {
            // InternalMyDsl.g:1406:2: ( (enumLiteral_0= 'Tomato' ) | (enumLiteral_1= 'Cabbage' ) | (enumLiteral_2= 'Potato' ) )
            int alt23=3;
            switch ( input.LA(1) ) {
            case 54:
                {
                alt23=1;
                }
                break;
            case 55:
                {
                alt23=2;
                }
                break;
            case 56:
                {
                alt23=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalMyDsl.g:1407:3: (enumLiteral_0= 'Tomato' )
                    {
                    // InternalMyDsl.g:1407:3: (enumLiteral_0= 'Tomato' )
                    // InternalMyDsl.g:1408:4: enumLiteral_0= 'Tomato'
                    {
                    enumLiteral_0=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getCropTypeAccess().getTomatoEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCropTypeAccess().getTomatoEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1415:3: (enumLiteral_1= 'Cabbage' )
                    {
                    // InternalMyDsl.g:1415:3: (enumLiteral_1= 'Cabbage' )
                    // InternalMyDsl.g:1416:4: enumLiteral_1= 'Cabbage'
                    {
                    enumLiteral_1=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getCropTypeAccess().getCabbageEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCropTypeAccess().getCabbageEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1423:3: (enumLiteral_2= 'Potato' )
                    {
                    // InternalMyDsl.g:1423:3: (enumLiteral_2= 'Potato' )
                    // InternalMyDsl.g:1424:4: enumLiteral_2= 'Potato'
                    {
                    enumLiteral_2=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getCropTypeAccess().getPotatoEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCropTypeAccess().getPotatoEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCropType"


    // $ANTLR start "ruleFocusArea"
    // InternalMyDsl.g:1434:1: ruleFocusArea returns [Enumerator current=null] : ( (enumLiteral_0= 'Crates' ) | (enumLiteral_1= 'Plants' ) | (enumLiteral_2= 'Cameras' ) | (enumLiteral_3= 'Drones' ) | (enumLiteral_4= 'Sensors' ) ) ;
    public final Enumerator ruleFocusArea() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1440:2: ( ( (enumLiteral_0= 'Crates' ) | (enumLiteral_1= 'Plants' ) | (enumLiteral_2= 'Cameras' ) | (enumLiteral_3= 'Drones' ) | (enumLiteral_4= 'Sensors' ) ) )
            // InternalMyDsl.g:1441:2: ( (enumLiteral_0= 'Crates' ) | (enumLiteral_1= 'Plants' ) | (enumLiteral_2= 'Cameras' ) | (enumLiteral_3= 'Drones' ) | (enumLiteral_4= 'Sensors' ) )
            {
            // InternalMyDsl.g:1441:2: ( (enumLiteral_0= 'Crates' ) | (enumLiteral_1= 'Plants' ) | (enumLiteral_2= 'Cameras' ) | (enumLiteral_3= 'Drones' ) | (enumLiteral_4= 'Sensors' ) )
            int alt24=5;
            switch ( input.LA(1) ) {
            case 57:
                {
                alt24=1;
                }
                break;
            case 58:
                {
                alt24=2;
                }
                break;
            case 59:
                {
                alt24=3;
                }
                break;
            case 60:
                {
                alt24=4;
                }
                break;
            case 61:
                {
                alt24=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalMyDsl.g:1442:3: (enumLiteral_0= 'Crates' )
                    {
                    // InternalMyDsl.g:1442:3: (enumLiteral_0= 'Crates' )
                    // InternalMyDsl.g:1443:4: enumLiteral_0= 'Crates'
                    {
                    enumLiteral_0=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getFocusAreaAccess().getCratesEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getFocusAreaAccess().getCratesEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1450:3: (enumLiteral_1= 'Plants' )
                    {
                    // InternalMyDsl.g:1450:3: (enumLiteral_1= 'Plants' )
                    // InternalMyDsl.g:1451:4: enumLiteral_1= 'Plants'
                    {
                    enumLiteral_1=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getFocusAreaAccess().getPlantsEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getFocusAreaAccess().getPlantsEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1458:3: (enumLiteral_2= 'Cameras' )
                    {
                    // InternalMyDsl.g:1458:3: (enumLiteral_2= 'Cameras' )
                    // InternalMyDsl.g:1459:4: enumLiteral_2= 'Cameras'
                    {
                    enumLiteral_2=(Token)match(input,59,FOLLOW_2); 

                    				current = grammarAccess.getFocusAreaAccess().getCamerasEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getFocusAreaAccess().getCamerasEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1466:3: (enumLiteral_3= 'Drones' )
                    {
                    // InternalMyDsl.g:1466:3: (enumLiteral_3= 'Drones' )
                    // InternalMyDsl.g:1467:4: enumLiteral_3= 'Drones'
                    {
                    enumLiteral_3=(Token)match(input,60,FOLLOW_2); 

                    				current = grammarAccess.getFocusAreaAccess().getDronesEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getFocusAreaAccess().getDronesEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:1474:3: (enumLiteral_4= 'Sensors' )
                    {
                    // InternalMyDsl.g:1474:3: (enumLiteral_4= 'Sensors' )
                    // InternalMyDsl.g:1475:4: enumLiteral_4= 'Sensors'
                    {
                    enumLiteral_4=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getFocusAreaAccess().getSensorsEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getFocusAreaAccess().getSensorsEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFocusArea"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000400000040L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000024000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000000000D0000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000600000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000020010000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x3E00000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000080010000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000200010000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000001000010000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x003C000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000800400000040L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000400000010000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x01C0000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000800000000040L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0003000000000002L});

}