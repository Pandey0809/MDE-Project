/**
 */
package smartFarming;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crop</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Crop#getCrop <em>Crop</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getCrop()
 * @model
 * @generated
 */
public interface Crop extends EObject {
	/**
	 * Returns the value of the '<em><b>Crop</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming.CropType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crop</em>' attribute.
	 * @see smartFarming.CropType
	 * @see #setCrop(CropType)
	 * @see smartFarming.SmartFarmingPackage#getCrop_Crop()
	 * @model
	 * @generated
	 */
	CropType getCrop();

	/**
	 * Sets the value of the '{@link smartFarming.Crop#getCrop <em>Crop</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crop</em>' attribute.
	 * @see smartFarming.CropType
	 * @see #getCrop()
	 * @generated
	 */
	void setCrop(CropType value);

} // Crop
