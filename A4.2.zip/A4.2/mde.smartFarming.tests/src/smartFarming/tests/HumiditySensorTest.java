/**
 */
package smartFarming.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import smartFarming.HumiditySensor;
import smartFarming.SmartFarmingFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Humidity Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link smartFarming.HumiditySensor#isHumiditytooless(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytooless</em>}</li>
 *   <li>{@link smartFarming.HumiditySensor#isHumiditytoomuch(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytoomuch</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class HumiditySensorTest extends TestCase {

	/**
	 * The fixture for this Humidity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HumiditySensor fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(HumiditySensorTest.class);
	}

	/**
	 * Constructs a new Humidity Sensor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HumiditySensorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Humidity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(HumiditySensor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Humidity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HumiditySensor getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmartFarmingFactory.eINSTANCE.createHumiditySensor());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link smartFarming.HumiditySensor#isHumiditytooless(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytooless</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.HumiditySensor#isHumiditytooless(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testIsHumiditytooless__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link smartFarming.HumiditySensor#isHumiditytoomuch(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Humiditytoomuch</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.HumiditySensor#isHumiditytoomuch(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testIsHumiditytoomuch__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //HumiditySensorTest
