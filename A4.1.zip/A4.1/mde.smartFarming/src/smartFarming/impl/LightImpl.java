/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming.Light;
import smartFarming.SmartFarmingPackage;
import smartFarming.typelight;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Light</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.LightImpl#getTypeLight <em>Type Light</em>}</li>
 *   <li>{@link smartFarming.impl.LightImpl#isTurnOn <em>Turn On</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LightImpl extends NameImpl implements Light {
	/**
	 * The default value of the '{@link #getTypeLight() <em>Type Light</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeLight()
	 * @generated
	 * @ordered
	 */
	protected static final typelight TYPE_LIGHT_EDEFAULT = typelight.UVLIGHT;

	/**
	 * The cached value of the '{@link #getTypeLight() <em>Type Light</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTypeLight()
	 * @generated
	 * @ordered
	 */
	protected typelight typeLight = TYPE_LIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TURN_ON_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected boolean turnOn = TURN_ON_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LightImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.LIGHT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public typelight getTypeLight() {
		return typeLight;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTypeLight(typelight newTypeLight) {
		typelight oldTypeLight = typeLight;
		typeLight = newTypeLight == null ? TYPE_LIGHT_EDEFAULT : newTypeLight;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.LIGHT__TYPE_LIGHT, oldTypeLight, typeLight));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTurnOn() {
		return turnOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTurnOn(boolean newTurnOn) {
		boolean oldTurnOn = turnOn;
		turnOn = newTurnOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.LIGHT__TURN_ON, oldTurnOn, turnOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.LIGHT__TYPE_LIGHT:
				return getTypeLight();
			case SmartFarmingPackage.LIGHT__TURN_ON:
				return isTurnOn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.LIGHT__TYPE_LIGHT:
				setTypeLight((typelight)newValue);
				return;
			case SmartFarmingPackage.LIGHT__TURN_ON:
				setTurnOn((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.LIGHT__TYPE_LIGHT:
				setTypeLight(TYPE_LIGHT_EDEFAULT);
				return;
			case SmartFarmingPackage.LIGHT__TURN_ON:
				setTurnOn(TURN_ON_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.LIGHT__TYPE_LIGHT:
				return typeLight != TYPE_LIGHT_EDEFAULT;
			case SmartFarmingPackage.LIGHT__TURN_ON:
				return turnOn != TURN_ON_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TypeLight: ");
		result.append(typeLight);
		result.append(", TurnOn: ");
		result.append(turnOn);
		result.append(')');
		return result.toString();
	}

} //LightImpl
