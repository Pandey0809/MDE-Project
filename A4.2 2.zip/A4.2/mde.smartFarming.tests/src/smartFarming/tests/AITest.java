/**
 */
package smartFarming.tests;

import junit.textui.TestRunner;

import smartFarming.AI;
import smartFarming.SmartFarmingFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>AI</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class AITest extends NameTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(AITest.class);
	}

	/**
	 * Constructs a new AI test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AITest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this AI test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected AI getFixture() {
		return (AI)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmartFarmingFactory.eINSTANCE.createAI());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //AITest
