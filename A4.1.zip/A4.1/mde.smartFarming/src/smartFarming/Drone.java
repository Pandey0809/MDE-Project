/**
 */
package smartFarming;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Drone</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.Drone#isTurnOn <em>Turn On</em>}</li>
 *   <li>{@link smartFarming.Drone#getDroneMonitoring <em>Drone Monitoring</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getDrone()
 * @model
 * @generated
 */
public interface Drone extends Name {
	/**
	 * Returns the value of the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Turn On</em>' attribute.
	 * @see #setTurnOn(boolean)
	 * @see smartFarming.SmartFarmingPackage#getDrone_TurnOn()
	 * @model required="true"
	 * @generated
	 */
	boolean isTurnOn();

	/**
	 * Sets the value of the '{@link smartFarming.Drone#isTurnOn <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Turn On</em>' attribute.
	 * @see #isTurnOn()
	 * @generated
	 */
	void setTurnOn(boolean value);

	/**
	 * Returns the value of the '<em><b>Drone Monitoring</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming.FocusArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drone Monitoring</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #setDroneMonitoring(FocusArea)
	 * @see smartFarming.SmartFarmingPackage#getDrone_DroneMonitoring()
	 * @model
	 * @generated
	 */
	FocusArea getDroneMonitoring();

	/**
	 * Sets the value of the '{@link smartFarming.Drone#getDroneMonitoring <em>Drone Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Drone Monitoring</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #getDroneMonitoring()
	 * @generated
	 */
	void setDroneMonitoring(FocusArea value);

} // Drone
