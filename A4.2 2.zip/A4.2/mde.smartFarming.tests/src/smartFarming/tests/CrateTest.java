/**
 */
package smartFarming.tests;

import junit.textui.TestRunner;

import smartFarming.Crate;
import smartFarming.SmartFarmingFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class CrateTest extends CrateidTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(CrateTest.class);
	}

	/**
	 * Constructs a new Crate test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CrateTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Crate test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Crate getFixture() {
		return (Crate)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmartFarmingFactory.eINSTANCE.createCrate());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //CrateTest
