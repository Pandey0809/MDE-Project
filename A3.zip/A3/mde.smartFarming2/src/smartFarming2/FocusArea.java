/**
 */
package smartFarming2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Focus Area</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see smartFarming2.SmartFarming2Package#getFocusArea()
 * @model
 * @generated
 */
public enum FocusArea implements Enumerator {
	/**
	 * The '<em><b>Crates</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CRATES_VALUE
	 * @generated
	 * @ordered
	 */
	CRATES(1, "Crates", "Crates"),

	/**
	 * The '<em><b>Plants</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PLANTS_VALUE
	 * @generated
	 * @ordered
	 */
	PLANTS(2, "Plants", "Plants"),

	/**
	 * The '<em><b>Cameras</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAMERAS_VALUE
	 * @generated
	 * @ordered
	 */
	CAMERAS(3, "Cameras", "Cameras"),

	/**
	 * The '<em><b>Drones</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DRONES_VALUE
	 * @generated
	 * @ordered
	 */
	DRONES(4, "Drones", "Drones"),

	/**
	 * The '<em><b>Sensors</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SENSORS_VALUE
	 * @generated
	 * @ordered
	 */
	SENSORS(5, "Sensors", "Sensors");

	/**
	 * The '<em><b>Crates</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CRATES
	 * @model name="Crates"
	 * @generated
	 * @ordered
	 */
	public static final int CRATES_VALUE = 1;

	/**
	 * The '<em><b>Plants</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PLANTS
	 * @model name="Plants"
	 * @generated
	 * @ordered
	 */
	public static final int PLANTS_VALUE = 2;

	/**
	 * The '<em><b>Cameras</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAMERAS
	 * @model name="Cameras"
	 * @generated
	 * @ordered
	 */
	public static final int CAMERAS_VALUE = 3;

	/**
	 * The '<em><b>Drones</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DRONES
	 * @model name="Drones"
	 * @generated
	 * @ordered
	 */
	public static final int DRONES_VALUE = 4;

	/**
	 * The '<em><b>Sensors</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SENSORS
	 * @model name="Sensors"
	 * @generated
	 * @ordered
	 */
	public static final int SENSORS_VALUE = 5;

	/**
	 * An array of all the '<em><b>Focus Area</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final FocusArea[] VALUES_ARRAY =
		new FocusArea[] {
			CRATES,
			PLANTS,
			CAMERAS,
			DRONES,
			SENSORS,
		};

	/**
	 * A public read-only list of all the '<em><b>Focus Area</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<FocusArea> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Focus Area</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static FocusArea get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			FocusArea result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Focus Area</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static FocusArea getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			FocusArea result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Focus Area</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static FocusArea get(int value) {
		switch (value) {
			case CRATES_VALUE: return CRATES;
			case PLANTS_VALUE: return PLANTS;
			case CAMERAS_VALUE: return CAMERAS;
			case DRONES_VALUE: return DRONES;
			case SENSORS_VALUE: return SENSORS;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private FocusArea(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //FocusArea
