/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming.Camera;
import smartFarming.FocusArea;
import smartFarming.SmartFarmingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.CameraImpl#getCameraFocus <em>Camera Focus</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CameraImpl extends NameImpl implements Camera {
	/**
	 * The default value of the '{@link #getCameraFocus() <em>Camera Focus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCameraFocus()
	 * @generated
	 * @ordered
	 */
	protected static final FocusArea CAMERA_FOCUS_EDEFAULT = FocusArea.CRATES;

	/**
	 * The cached value of the '{@link #getCameraFocus() <em>Camera Focus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCameraFocus()
	 * @generated
	 * @ordered
	 */
	protected FocusArea cameraFocus = CAMERA_FOCUS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CameraImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.CAMERA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea getCameraFocus() {
		return cameraFocus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCameraFocus(FocusArea newCameraFocus) {
		FocusArea oldCameraFocus = cameraFocus;
		cameraFocus = newCameraFocus == null ? CAMERA_FOCUS_EDEFAULT : newCameraFocus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.CAMERA__CAMERA_FOCUS, oldCameraFocus, cameraFocus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.CAMERA__CAMERA_FOCUS:
				return getCameraFocus();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.CAMERA__CAMERA_FOCUS:
				setCameraFocus((FocusArea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.CAMERA__CAMERA_FOCUS:
				setCameraFocus(CAMERA_FOCUS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.CAMERA__CAMERA_FOCUS:
				return cameraFocus != CAMERA_FOCUS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (CameraFocus: ");
		result.append(cameraFocus);
		result.append(')');
		return result.toString();
	}

} //CameraImpl
