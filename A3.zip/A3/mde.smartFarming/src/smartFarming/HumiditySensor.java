/**
 */
package smartFarming;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Humidity Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.HumiditySensor#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}</li>
 *   <li>{@link smartFarming.HumiditySensor#isTurnOn <em>Turn On</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getHumiditySensor()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='isHumiditytoomuch'"
 * @generated
 */
public interface HumiditySensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Humidity Value In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Humidity Value In Percentage</em>' attribute.
	 * @see #setHumidityValueInPercentage(float)
	 * @see smartFarming.SmartFarmingPackage#getHumiditySensor_HumidityValueInPercentage()
	 * @model required="true"
	 * @generated
	 */
	float getHumidityValueInPercentage();

	/**
	 * Sets the value of the '{@link smartFarming.HumiditySensor#getHumidityValueInPercentage <em>Humidity Value In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Humidity Value In Percentage</em>' attribute.
	 * @see #getHumidityValueInPercentage()
	 * @generated
	 */
	void setHumidityValueInPercentage(float value);

	/**
	 * Returns the value of the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Turn On</em>' attribute.
	 * @see #setTurnOn(boolean)
	 * @see smartFarming.SmartFarmingPackage#getHumiditySensor_TurnOn()
	 * @model required="true"
	 * @generated
	 */
	boolean isTurnOn();

	/**
	 * Sets the value of the '{@link smartFarming.HumiditySensor#isTurnOn <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Turn On</em>' attribute.
	 * @see #isTurnOn()
	 * @generated
	 */
	void setTurnOn(boolean value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.HumidityValueInPercentage&gt;=50'"
	 * @generated
	 */
	boolean isHumiditytooless(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.HumidityValueInPercentage&lt;=90'"
	 * @generated
	 */
	boolean isHumiditytoomuch(DiagnosticChain diagnostics, Map<Object, Object> context);

} // HumiditySensor
