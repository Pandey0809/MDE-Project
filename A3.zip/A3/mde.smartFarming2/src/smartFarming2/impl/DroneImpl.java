/**
 */
package smartFarming2.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming2.Drone;
import smartFarming2.FocusArea;
import smartFarming2.SmartFarming2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Drone</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.impl.DroneImpl#isTurnOn <em>Turn On</em>}</li>
 *   <li>{@link smartFarming2.impl.DroneImpl#getDroneMonitoring <em>Drone Monitoring</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DroneImpl extends NameImpl implements Drone {
	/**
	 * The default value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TURN_ON_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTurnOn() <em>Turn On</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTurnOn()
	 * @generated
	 * @ordered
	 */
	protected boolean turnOn = TURN_ON_EDEFAULT;

	/**
	 * The default value of the '{@link #getDroneMonitoring() <em>Drone Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDroneMonitoring()
	 * @generated
	 * @ordered
	 */
	protected static final FocusArea DRONE_MONITORING_EDEFAULT = FocusArea.CRATES;

	/**
	 * The cached value of the '{@link #getDroneMonitoring() <em>Drone Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDroneMonitoring()
	 * @generated
	 * @ordered
	 */
	protected FocusArea droneMonitoring = DRONE_MONITORING_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DroneImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarming2Package.Literals.DRONE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTurnOn() {
		return turnOn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTurnOn(boolean newTurnOn) {
		boolean oldTurnOn = turnOn;
		turnOn = newTurnOn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.DRONE__TURN_ON, oldTurnOn, turnOn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea getDroneMonitoring() {
		return droneMonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDroneMonitoring(FocusArea newDroneMonitoring) {
		FocusArea oldDroneMonitoring = droneMonitoring;
		droneMonitoring = newDroneMonitoring == null ? DRONE_MONITORING_EDEFAULT : newDroneMonitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.DRONE__DRONE_MONITORING, oldDroneMonitoring, droneMonitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarming2Package.DRONE__TURN_ON:
				return isTurnOn();
			case SmartFarming2Package.DRONE__DRONE_MONITORING:
				return getDroneMonitoring();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarming2Package.DRONE__TURN_ON:
				setTurnOn((Boolean)newValue);
				return;
			case SmartFarming2Package.DRONE__DRONE_MONITORING:
				setDroneMonitoring((FocusArea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.DRONE__TURN_ON:
				setTurnOn(TURN_ON_EDEFAULT);
				return;
			case SmartFarming2Package.DRONE__DRONE_MONITORING:
				setDroneMonitoring(DRONE_MONITORING_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.DRONE__TURN_ON:
				return turnOn != TURN_ON_EDEFAULT;
			case SmartFarming2Package.DRONE__DRONE_MONITORING:
				return droneMonitoring != DRONE_MONITORING_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TurnOn: ");
		result.append(turnOn);
		result.append(", DroneMonitoring: ");
		result.append(droneMonitoring);
		result.append(')');
		return result.toString();
	}

} //DroneImpl
