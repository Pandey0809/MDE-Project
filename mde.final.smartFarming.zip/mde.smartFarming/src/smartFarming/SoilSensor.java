/**
 */
package smartFarming;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Soil Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.SoilSensor#getPh <em>Ph</em>}</li>
 *   <li>{@link smartFarming.SoilSensor#getSoilMoisture <em>Soil Moisture</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getSoilSensor()
 * @model
 * @generated
 */
public interface SoilSensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Ph</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ph</em>' attribute.
	 * @see #setPh(int)
	 * @see smartFarming.SmartFarmingPackage#getSoilSensor_Ph()
	 * @model
	 * @generated
	 */
	int getPh();

	/**
	 * Sets the value of the '{@link smartFarming.SoilSensor#getPh <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ph</em>' attribute.
	 * @see #getPh()
	 * @generated
	 */
	void setPh(int value);

	/**
	 * Returns the value of the '<em><b>Soil Moisture</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soil Moisture</em>' attribute.
	 * @see #setSoilMoisture(int)
	 * @see smartFarming.SmartFarmingPackage#getSoilSensor_SoilMoisture()
	 * @model
	 * @generated
	 */
	int getSoilMoisture();

	/**
	 * Sets the value of the '{@link smartFarming.SoilSensor#getSoilMoisture <em>Soil Moisture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Soil Moisture</em>' attribute.
	 * @see #getSoilMoisture()
	 * @generated
	 */
	void setSoilMoisture(int value);

} // SoilSensor
