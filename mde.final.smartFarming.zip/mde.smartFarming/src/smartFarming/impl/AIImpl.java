/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming.AI;
import smartFarming.FocusArea;
import smartFarming.SmartFarmingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AI</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.AIImpl#getAIfocus <em>AIfocus</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AIImpl extends NameImpl implements AI {
	/**
	 * The default value of the '{@link #getAIfocus() <em>AIfocus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAIfocus()
	 * @generated
	 * @ordered
	 */
	protected static final FocusArea AIFOCUS_EDEFAULT = FocusArea.CRATES;

	/**
	 * The cached value of the '{@link #getAIfocus() <em>AIfocus</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAIfocus()
	 * @generated
	 * @ordered
	 */
	protected FocusArea aIfocus = AIFOCUS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AIImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.AI;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea getAIfocus() {
		return aIfocus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAIfocus(FocusArea newAIfocus) {
		FocusArea oldAIfocus = aIfocus;
		aIfocus = newAIfocus == null ? AIFOCUS_EDEFAULT : newAIfocus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.AI__AIFOCUS, oldAIfocus, aIfocus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AIFOCUS:
				return getAIfocus();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AIFOCUS:
				setAIfocus((FocusArea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AIFOCUS:
				setAIfocus(AIFOCUS_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AIFOCUS:
				return aIfocus != AIFOCUS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (AIfocus: ");
		result.append(aIfocus);
		result.append(')');
		return result.toString();
	}

} //AIImpl
