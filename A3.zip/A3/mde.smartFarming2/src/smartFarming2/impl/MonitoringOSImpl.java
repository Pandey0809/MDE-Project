/**
 */
package smartFarming2.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming2.FocusArea;
import smartFarming2.MonitoringOS;
import smartFarming2.SmartFarming2Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Monitoring OS</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.impl.MonitoringOSImpl#getOSfocusArea <em>OSfocus Area</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MonitoringOSImpl extends NameImpl implements MonitoringOS {
	/**
	 * The default value of the '{@link #getOSfocusArea() <em>OSfocus Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOSfocusArea()
	 * @generated
	 * @ordered
	 */
	protected static final FocusArea OSFOCUS_AREA_EDEFAULT = FocusArea.CRATES;

	/**
	 * The cached value of the '{@link #getOSfocusArea() <em>OSfocus Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOSfocusArea()
	 * @generated
	 * @ordered
	 */
	protected FocusArea oSfocusArea = OSFOCUS_AREA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MonitoringOSImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarming2Package.Literals.MONITORING_OS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea getOSfocusArea() {
		return oSfocusArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOSfocusArea(FocusArea newOSfocusArea) {
		FocusArea oldOSfocusArea = oSfocusArea;
		oSfocusArea = newOSfocusArea == null ? OSFOCUS_AREA_EDEFAULT : newOSfocusArea;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarming2Package.MONITORING_OS__OSFOCUS_AREA, oldOSfocusArea, oSfocusArea));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarming2Package.MONITORING_OS__OSFOCUS_AREA:
				return getOSfocusArea();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarming2Package.MONITORING_OS__OSFOCUS_AREA:
				setOSfocusArea((FocusArea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.MONITORING_OS__OSFOCUS_AREA:
				setOSfocusArea(OSFOCUS_AREA_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarming2Package.MONITORING_OS__OSFOCUS_AREA:
				return oSfocusArea != OSFOCUS_AREA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (OSfocusArea: ");
		result.append(oSfocusArea);
		result.append(')');
		return result.toString();
	}

} //MonitoringOSImpl
