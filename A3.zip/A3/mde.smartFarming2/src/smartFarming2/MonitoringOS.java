/**
 */
package smartFarming2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Monitoring OS</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.MonitoringOS#getOSfocusArea <em>OSfocus Area</em>}</li>
 * </ul>
 *
 * @see smartFarming2.SmartFarming2Package#getMonitoringOS()
 * @model
 * @generated
 */
public interface MonitoringOS extends Name {
	/**
	 * Returns the value of the '<em><b>OSfocus Area</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming2.FocusArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>OSfocus Area</em>' attribute.
	 * @see smartFarming2.FocusArea
	 * @see #setOSfocusArea(FocusArea)
	 * @see smartFarming2.SmartFarming2Package#getMonitoringOS_OSfocusArea()
	 * @model
	 * @generated
	 */
	FocusArea getOSfocusArea();

	/**
	 * Sets the value of the '{@link smartFarming2.MonitoringOS#getOSfocusArea <em>OSfocus Area</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>OSfocus Area</em>' attribute.
	 * @see smartFarming2.FocusArea
	 * @see #getOSfocusArea()
	 * @generated
	 */
	void setOSfocusArea(FocusArea value);

} // MonitoringOS
