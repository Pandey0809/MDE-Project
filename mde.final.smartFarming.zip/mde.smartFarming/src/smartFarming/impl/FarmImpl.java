/**
 */
package smartFarming.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import smartFarming.AI;
import smartFarming.Camera;
import smartFarming.Crate;
import smartFarming.Drone;
import smartFarming.Farm;
import smartFarming.SmartFarmingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Farm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.FarmImpl#getCrate <em>Crate</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getDrone <em>Drone</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getAi <em>Ai</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FarmImpl extends NameImpl implements Farm {
	/**
	 * The cached value of the '{@link #getCrate() <em>Crate</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrate()
	 * @generated
	 * @ordered
	 */
	protected EList<Crate> crate;

	/**
	 * The cached value of the '{@link #getDrone() <em>Drone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrone()
	 * @generated
	 * @ordered
	 */
	protected EList<Drone> drone;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected EList<Camera> camera;

	/**
	 * The cached value of the '{@link #getAi() <em>Ai</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAi()
	 * @generated
	 * @ordered
	 */
	protected AI ai;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.FARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Crate> getCrate() {
		if (crate == null) {
			crate = new EObjectContainmentEList<Crate>(Crate.class, this, SmartFarmingPackage.FARM__CRATE);
		}
		return crate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drone> getDrone() {
		if (drone == null) {
			drone = new EObjectContainmentEList<Drone>(Drone.class, this, SmartFarmingPackage.FARM__DRONE);
		}
		return drone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Camera> getCamera() {
		if (camera == null) {
			camera = new EObjectContainmentEList<Camera>(Camera.class, this, SmartFarmingPackage.FARM__CAMERA);
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AI getAi() {
		return ai;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAi(AI newAi, NotificationChain msgs) {
		AI oldAi = ai;
		ai = newAi;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.FARM__AI, oldAi, newAi);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAi(AI newAi) {
		if (newAi != ai) {
			NotificationChain msgs = null;
			if (ai != null)
				msgs = ((InternalEObject)ai).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.FARM__AI, null, msgs);
			if (newAi != null)
				msgs = ((InternalEObject)newAi).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - SmartFarmingPackage.FARM__AI, null, msgs);
			msgs = basicSetAi(newAi, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.FARM__AI, newAi, newAi));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return ((InternalEList<?>)getCrate()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__DRONE:
				return ((InternalEList<?>)getDrone()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__CAMERA:
				return ((InternalEList<?>)getCamera()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__AI:
				return basicSetAi(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return getCrate();
			case SmartFarmingPackage.FARM__DRONE:
				return getDrone();
			case SmartFarmingPackage.FARM__CAMERA:
				return getCamera();
			case SmartFarmingPackage.FARM__AI:
				return getAi();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				getCrate().clear();
				getCrate().addAll((Collection<? extends Crate>)newValue);
				return;
			case SmartFarmingPackage.FARM__DRONE:
				getDrone().clear();
				getDrone().addAll((Collection<? extends Drone>)newValue);
				return;
			case SmartFarmingPackage.FARM__CAMERA:
				getCamera().clear();
				getCamera().addAll((Collection<? extends Camera>)newValue);
				return;
			case SmartFarmingPackage.FARM__AI:
				setAi((AI)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				getCrate().clear();
				return;
			case SmartFarmingPackage.FARM__DRONE:
				getDrone().clear();
				return;
			case SmartFarmingPackage.FARM__CAMERA:
				getCamera().clear();
				return;
			case SmartFarmingPackage.FARM__AI:
				setAi((AI)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return crate != null && !crate.isEmpty();
			case SmartFarmingPackage.FARM__DRONE:
				return drone != null && !drone.isEmpty();
			case SmartFarmingPackage.FARM__CAMERA:
				return camera != null && !camera.isEmpty();
			case SmartFarmingPackage.FARM__AI:
				return ai != null;
		}
		return super.eIsSet(featureID);
	}

} //FarmImpl
