/**
 */
package smartFarming;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AI</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.AI#getAIMonitoring <em>AI Monitoring</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getAI()
 * @model
 * @generated
 */
public interface AI extends Name {
	/**
	 * Returns the value of the '<em><b>AI Monitoring</b></em>' attribute.
	 * The literals are from the enumeration {@link smartFarming.FocusArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>AI Monitoring</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #setAIMonitoring(FocusArea)
	 * @see smartFarming.SmartFarmingPackage#getAI_AIMonitoring()
	 * @model
	 * @generated
	 */
	FocusArea getAIMonitoring();

	/**
	 * Sets the value of the '{@link smartFarming.AI#getAIMonitoring <em>AI Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>AI Monitoring</em>' attribute.
	 * @see smartFarming.FocusArea
	 * @see #getAIMonitoring()
	 * @generated
	 */
	void setAIMonitoring(FocusArea value);

} // AI
