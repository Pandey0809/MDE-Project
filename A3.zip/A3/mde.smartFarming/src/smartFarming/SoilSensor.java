/**
 */
package smartFarming;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Soil Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.SoilSensor#getPh <em>Ph</em>}</li>
 *   <li>{@link smartFarming.SoilSensor#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}</li>
 * </ul>
 *
 * @see smartFarming.SmartFarmingPackage#getSoilSensor()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='isSoiltooBasic'"
 * @generated
 */
public interface SoilSensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Ph</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ph</em>' attribute.
	 * @see #setPh(int)
	 * @see smartFarming.SmartFarmingPackage#getSoilSensor_Ph()
	 * @model required="true"
	 * @generated
	 */
	int getPh();

	/**
	 * Sets the value of the '{@link smartFarming.SoilSensor#getPh <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ph</em>' attribute.
	 * @see #getPh()
	 * @generated
	 */
	void setPh(int value);

	/**
	 * Returns the value of the '<em><b>Soil Moisture In Percentage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Soil Moisture In Percentage</em>' attribute.
	 * @see #setSoilMoistureInPercentage(int)
	 * @see smartFarming.SmartFarmingPackage#getSoilSensor_SoilMoistureInPercentage()
	 * @model required="true"
	 * @generated
	 */
	int getSoilMoistureInPercentage();

	/**
	 * Sets the value of the '{@link smartFarming.SoilSensor#getSoilMoistureInPercentage <em>Soil Moisture In Percentage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Soil Moisture In Percentage</em>' attribute.
	 * @see #getSoilMoistureInPercentage()
	 * @generated
	 */
	void setSoilMoistureInPercentage(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.ph&gt;=4'"
	 * @generated
	 */
	boolean isSoiltooAcidic(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tself.ph&lt;=10'"
	 * @generated
	 */
	boolean isSoiltooBasic(DiagnosticChain diagnostics, Map<Object, Object> context);

} // SoilSensor
