/**
 */
package smartFarming.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.collection.CollectionSizeOperation;

import org.eclipse.ocl.pivot.library.oclany.OclComparableGreaterThanEqualOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.OrderedSetValue;

import smartFarming.AI;
import smartFarming.Camera;
import smartFarming.Crate;
import smartFarming.Drone;
import smartFarming.Farm;
import smartFarming.SmartFarmingPackage;
import smartFarming.SmartFarmingTables;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Farm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.FarmImpl#getCrate <em>Crate</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getDrone <em>Drone</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getAi <em>Ai</em>}</li>
 *   <li>{@link smartFarming.impl.FarmImpl#getMaxCrates <em>Max Crates</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FarmImpl extends NameImpl implements Farm {
	/**
	 * The cached value of the '{@link #getCrate() <em>Crate</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrate()
	 * @generated
	 * @ordered
	 */
	protected EList<Crate> crate;

	/**
	 * The cached value of the '{@link #getDrone() <em>Drone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDrone()
	 * @generated
	 * @ordered
	 */
	protected EList<Drone> drone;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected EList<Camera> camera;

	/**
	 * The cached value of the '{@link #getAi() <em>Ai</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAi()
	 * @generated
	 * @ordered
	 */
	protected EList<AI> ai;

	/**
	 * The default value of the '{@link #getMaxCrates() <em>Max Crates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxCrates()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_CRATES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMaxCrates() <em>Max Crates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxCrates()
	 * @generated
	 * @ordered
	 */
	protected int maxCrates = MAX_CRATES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.FARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Crate> getCrate() {
		if (crate == null) {
			crate = new EObjectContainmentEList<Crate>(Crate.class, this, SmartFarmingPackage.FARM__CRATE);
		}
		return crate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Drone> getDrone() {
		if (drone == null) {
			drone = new EObjectContainmentEList<Drone>(Drone.class, this, SmartFarmingPackage.FARM__DRONE);
		}
		return drone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Camera> getCamera() {
		if (camera == null) {
			camera = new EObjectContainmentEList<Camera>(Camera.class, this, SmartFarmingPackage.FARM__CAMERA);
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AI> getAi() {
		if (ai == null) {
			ai = new EObjectContainmentEList<AI>(AI.class, this, SmartFarmingPackage.FARM__AI);
		}
		return ai;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxCrates() {
		return maxCrates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxCrates(int newMaxCrates) {
		int oldMaxCrates = maxCrates;
		maxCrates = newMaxCrates;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.FARM__MAX_CRATES, oldMaxCrates, maxCrates));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isSpaceaAvailable() {
		/**
		 * self.MaxCrates >= crate->size()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ int MaxCrates = this.getMaxCrates();
		final /*@NonInvalid*/ IntegerValue BOXED_MaxCrates = ValueUtil.integerValueOf(MaxCrates);
		final /*@NonInvalid*/ List<Crate> crate = this.getCrate();
		final /*@NonInvalid*/ OrderedSetValue BOXED_crate = idResolver.createOrderedSetOfAll(SmartFarmingTables.ORD_CLSSid_Crate, crate);
		final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(BOXED_crate);
		final /*@NonInvalid*/ boolean ge = OclComparableGreaterThanEqualOperation.INSTANCE.evaluate(executor, BOXED_MaxCrates, size).booleanValue();
		return ge;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean SufficientSpace(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Farm::SufficientSpace";
		try {
			/**
			 *
			 * inv SufficientSpace:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = self.MaxCrates >= crate->size()
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor, SmartFarmingPackage.Literals.FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE.evaluate(executor, severity_0, SmartFarmingTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean symbol_0;
			if (le) {
				symbol_0 = true;
			}
			else {
				final /*@NonInvalid*/ int MaxCrates = this.getMaxCrates();
				final /*@NonInvalid*/ IntegerValue BOXED_MaxCrates = ValueUtil.integerValueOf(MaxCrates);
				final /*@NonInvalid*/ List<Crate> crate = this.getCrate();
				final /*@NonInvalid*/ OrderedSetValue BOXED_crate = idResolver.createOrderedSetOfAll(SmartFarmingTables.ORD_CLSSid_Crate, crate);
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(BOXED_crate);
				final /*@NonInvalid*/ boolean result = OclComparableGreaterThanEqualOperation.INSTANCE.evaluate(executor, BOXED_MaxCrates, size).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object)null, diagnostics, context, (Object)null, severity_0, result, SmartFarmingTables.INT_0).booleanValue();
				symbol_0 = logDiagnostic;
			}
			return symbol_0;
		}
		catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return ((InternalEList<?>)getCrate()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__DRONE:
				return ((InternalEList<?>)getDrone()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__CAMERA:
				return ((InternalEList<?>)getCamera()).basicRemove(otherEnd, msgs);
			case SmartFarmingPackage.FARM__AI:
				return ((InternalEList<?>)getAi()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return getCrate();
			case SmartFarmingPackage.FARM__DRONE:
				return getDrone();
			case SmartFarmingPackage.FARM__CAMERA:
				return getCamera();
			case SmartFarmingPackage.FARM__AI:
				return getAi();
			case SmartFarmingPackage.FARM__MAX_CRATES:
				return getMaxCrates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				getCrate().clear();
				getCrate().addAll((Collection<? extends Crate>)newValue);
				return;
			case SmartFarmingPackage.FARM__DRONE:
				getDrone().clear();
				getDrone().addAll((Collection<? extends Drone>)newValue);
				return;
			case SmartFarmingPackage.FARM__CAMERA:
				getCamera().clear();
				getCamera().addAll((Collection<? extends Camera>)newValue);
				return;
			case SmartFarmingPackage.FARM__AI:
				getAi().clear();
				getAi().addAll((Collection<? extends AI>)newValue);
				return;
			case SmartFarmingPackage.FARM__MAX_CRATES:
				setMaxCrates((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				getCrate().clear();
				return;
			case SmartFarmingPackage.FARM__DRONE:
				getDrone().clear();
				return;
			case SmartFarmingPackage.FARM__CAMERA:
				getCamera().clear();
				return;
			case SmartFarmingPackage.FARM__AI:
				getAi().clear();
				return;
			case SmartFarmingPackage.FARM__MAX_CRATES:
				setMaxCrates(MAX_CRATES_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.FARM__CRATE:
				return crate != null && !crate.isEmpty();
			case SmartFarmingPackage.FARM__DRONE:
				return drone != null && !drone.isEmpty();
			case SmartFarmingPackage.FARM__CAMERA:
				return camera != null && !camera.isEmpty();
			case SmartFarmingPackage.FARM__AI:
				return ai != null && !ai.isEmpty();
			case SmartFarmingPackage.FARM__MAX_CRATES:
				return maxCrates != MAX_CRATES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SmartFarmingPackage.FARM___IS_SPACEA_AVAILABLE:
				return isSpaceaAvailable();
			case SmartFarmingPackage.FARM___SUFFICIENT_SPACE__DIAGNOSTICCHAIN_MAP:
				return SufficientSpace((DiagnosticChain)arguments.get(0), (Map<Object, Object>)arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (MaxCrates: ");
		result.append(maxCrates);
		result.append(')');
		return result.toString();
	}

} //FarmImpl
