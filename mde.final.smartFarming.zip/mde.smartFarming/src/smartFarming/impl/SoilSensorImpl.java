/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import smartFarming.SmartFarmingPackage;
import smartFarming.SoilSensor;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Soil Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.SoilSensorImpl#getPh <em>Ph</em>}</li>
 *   <li>{@link smartFarming.impl.SoilSensorImpl#getSoilMoisture <em>Soil Moisture</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SoilSensorImpl extends MinimalEObjectImpl.Container implements SoilSensor {
	/**
	 * The default value of the '{@link #getPh() <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPh()
	 * @generated
	 * @ordered
	 */
	protected static final int PH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPh() <em>Ph</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPh()
	 * @generated
	 * @ordered
	 */
	protected int ph = PH_EDEFAULT;

	/**
	 * The default value of the '{@link #getSoilMoisture() <em>Soil Moisture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoilMoisture()
	 * @generated
	 * @ordered
	 */
	protected static final int SOIL_MOISTURE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSoilMoisture() <em>Soil Moisture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSoilMoisture()
	 * @generated
	 * @ordered
	 */
	protected int soilMoisture = SOIL_MOISTURE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SoilSensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.SOIL_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPh() {
		return ph;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPh(int newPh) {
		int oldPh = ph;
		ph = newPh;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.SOIL_SENSOR__PH, oldPh, ph));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSoilMoisture() {
		return soilMoisture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSoilMoisture(int newSoilMoisture) {
		int oldSoilMoisture = soilMoisture;
		soilMoisture = newSoilMoisture;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE, oldSoilMoisture, soilMoisture));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				return getPh();
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE:
				return getSoilMoisture();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				setPh((Integer)newValue);
				return;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE:
				setSoilMoisture((Integer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				setPh(PH_EDEFAULT);
				return;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE:
				setSoilMoisture(SOIL_MOISTURE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.SOIL_SENSOR__PH:
				return ph != PH_EDEFAULT;
			case SmartFarmingPackage.SOIL_SENSOR__SOIL_MOISTURE:
				return soilMoisture != SOIL_MOISTURE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ph: ");
		result.append(ph);
		result.append(", SoilMoisture: ");
		result.append(soilMoisture);
		result.append(')');
		return result.toString();
	}

} //SoilSensorImpl
