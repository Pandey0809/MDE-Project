/**
 */
package smartFarming.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import smartFarming.SmartFarmingFactory;
import smartFarming.SoilSensor;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Soil Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link smartFarming.SoilSensor#isSoiltooAcidic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Acidic</em>}</li>
 *   <li>{@link smartFarming.SoilSensor#isSoiltooBasic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Basic</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class SoilSensorTest extends TestCase {

	/**
	 * The fixture for this Soil Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SoilSensor fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(SoilSensorTest.class);
	}

	/**
	 * Constructs a new Soil Sensor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SoilSensorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Soil Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(SoilSensor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Soil Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SoilSensor getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmartFarmingFactory.eINSTANCE.createSoilSensor());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link smartFarming.SoilSensor#isSoiltooAcidic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Acidic</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.SoilSensor#isSoiltooAcidic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testIsSoiltooAcidic__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link smartFarming.SoilSensor#isSoiltooBasic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Is Soiltoo Basic</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.SoilSensor#isSoiltooBasic(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testIsSoiltooBasic__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //SoilSensorTest
