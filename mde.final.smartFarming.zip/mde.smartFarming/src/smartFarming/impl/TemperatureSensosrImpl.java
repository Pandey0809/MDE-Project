/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import smartFarming.SmartFarmingPackage;
import smartFarming.TemperatureSensosr;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Temperature Sensosr</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.TemperatureSensosrImpl#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}</li>
 *   <li>{@link smartFarming.impl.TemperatureSensosrImpl#getCrateTemperature <em>Crate Temperature</em>}</li>
 *   <li>{@link smartFarming.impl.TemperatureSensosrImpl#getPlantTemperature <em>Plant Temperature</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TemperatureSensosrImpl extends MinimalEObjectImpl.Container implements TemperatureSensosr {
	/**
	 * The default value of the '{@link #isTemperatureinDegreeCelcius() <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTemperatureinDegreeCelcius() <em>Temperaturein Degree Celcius</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTemperatureinDegreeCelcius()
	 * @generated
	 * @ordered
	 */
	protected boolean temperatureinDegreeCelcius = TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT;

	/**
	 * The default value of the '{@link #getCrateTemperature() <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrateTemperature()
	 * @generated
	 * @ordered
	 */
	protected static final float CRATE_TEMPERATURE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getCrateTemperature() <em>Crate Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrateTemperature()
	 * @generated
	 * @ordered
	 */
	protected float crateTemperature = CRATE_TEMPERATURE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPlantTemperature() <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlantTemperature()
	 * @generated
	 * @ordered
	 */
	protected static final float PLANT_TEMPERATURE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPlantTemperature() <em>Plant Temperature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlantTemperature()
	 * @generated
	 * @ordered
	 */
	protected float plantTemperature = PLANT_TEMPERATURE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TemperatureSensosrImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.TEMPERATURE_SENSOSR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isTemperatureinDegreeCelcius() {
		return temperatureinDegreeCelcius;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTemperatureinDegreeCelcius(boolean newTemperatureinDegreeCelcius) {
		boolean oldTemperatureinDegreeCelcius = temperatureinDegreeCelcius;
		temperatureinDegreeCelcius = newTemperatureinDegreeCelcius;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS, oldTemperatureinDegreeCelcius, temperatureinDegreeCelcius));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getCrateTemperature() {
		return crateTemperature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCrateTemperature(float newCrateTemperature) {
		float oldCrateTemperature = crateTemperature;
		crateTemperature = newCrateTemperature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSR__CRATE_TEMPERATURE, oldCrateTemperature, crateTemperature));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getPlantTemperature() {
		return plantTemperature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlantTemperature(float newPlantTemperature) {
		float oldPlantTemperature = plantTemperature;
		plantTemperature = newPlantTemperature;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.TEMPERATURE_SENSOSR__PLANT_TEMPERATURE, oldPlantTemperature, plantTemperature));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS:
				return isTemperatureinDegreeCelcius();
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__CRATE_TEMPERATURE:
				return getCrateTemperature();
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__PLANT_TEMPERATURE:
				return getPlantTemperature();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS:
				setTemperatureinDegreeCelcius((Boolean)newValue);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__CRATE_TEMPERATURE:
				setCrateTemperature((Float)newValue);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__PLANT_TEMPERATURE:
				setPlantTemperature((Float)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS:
				setTemperatureinDegreeCelcius(TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__CRATE_TEMPERATURE:
				setCrateTemperature(CRATE_TEMPERATURE_EDEFAULT);
				return;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__PLANT_TEMPERATURE:
				setPlantTemperature(PLANT_TEMPERATURE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS:
				return temperatureinDegreeCelcius != TEMPERATUREIN_DEGREE_CELCIUS_EDEFAULT;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__CRATE_TEMPERATURE:
				return crateTemperature != CRATE_TEMPERATURE_EDEFAULT;
			case SmartFarmingPackage.TEMPERATURE_SENSOSR__PLANT_TEMPERATURE:
				return plantTemperature != PLANT_TEMPERATURE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TemperatureinDegreeCelcius: ");
		result.append(temperatureinDegreeCelcius);
		result.append(", CrateTemperature: ");
		result.append(crateTemperature);
		result.append(", PlantTemperature: ");
		result.append(plantTemperature);
		result.append(')');
		return result.toString();
	}

} //TemperatureSensosrImpl
