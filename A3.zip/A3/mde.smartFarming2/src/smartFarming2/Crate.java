/**
 */
package smartFarming2;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crate</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smartFarming2.Crate#getLight <em>Light</em>}</li>
 *   <li>{@link smartFarming2.Crate#getSensors <em>Sensors</em>}</li>
 *   <li>{@link smartFarming2.Crate#getCropType <em>Crop Type</em>}</li>
 *   <li>{@link smartFarming2.Crate#getWorkingOS <em>Working OS</em>}</li>
 *   <li>{@link smartFarming2.Crate#getWorkingDrones <em>Working Drones</em>}</li>
 *   <li>{@link smartFarming2.Crate#getWorkingCameras <em>Working Cameras</em>}</li>
 * </ul>
 *
 * @see smartFarming2.SmartFarming2Package#getCrate()
 * @model
 * @generated
 */
public interface Crate extends Crateid {
	/**
	 * Returns the value of the '<em><b>Light</b></em>' containment reference list.
	 * The list contents are of type {@link smartFarming2.Light}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Light</em>' containment reference list.
	 * @see smartFarming2.SmartFarming2Package#getCrate_Light()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Light> getLight();

	/**
	 * Returns the value of the '<em><b>Sensors</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensors</em>' containment reference.
	 * @see #setSensors(CrateSensors)
	 * @see smartFarming2.SmartFarming2Package#getCrate_Sensors()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CrateSensors getSensors();

	/**
	 * Sets the value of the '{@link smartFarming2.Crate#getSensors <em>Sensors</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensors</em>' containment reference.
	 * @see #getSensors()
	 * @generated
	 */
	void setSensors(CrateSensors value);

	/**
	 * Returns the value of the '<em><b>Crop Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crop Type</em>' containment reference.
	 * @see #setCropType(Crop)
	 * @see smartFarming2.SmartFarming2Package#getCrate_CropType()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Crop getCropType();

	/**
	 * Sets the value of the '{@link smartFarming2.Crate#getCropType <em>Crop Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Crop Type</em>' containment reference.
	 * @see #getCropType()
	 * @generated
	 */
	void setCropType(Crop value);

	/**
	 * Returns the value of the '<em><b>Working OS</b></em>' reference list.
	 * The list contents are of type {@link smartFarming2.MonitoringOS}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Working OS</em>' reference list.
	 * @see smartFarming2.SmartFarming2Package#getCrate_WorkingOS()
	 * @model volatile="true" derived="true" ordered="false"
	 *        annotation="http://www.eclipse.org/OCL/Collection nullFree='false'"
	 * @generated
	 */
	EList<MonitoringOS> getWorkingOS();

	/**
	 * Returns the value of the '<em><b>Working Drones</b></em>' reference list.
	 * The list contents are of type {@link smartFarming2.Drone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Working Drones</em>' reference list.
	 * @see smartFarming2.SmartFarming2Package#getCrate_WorkingDrones()
	 * @model volatile="true" derived="true" ordered="false"
	 *        annotation="http://www.eclipse.org/OCL/Collection nullFree='false'"
	 * @generated
	 */
	EList<Drone> getWorkingDrones();

	/**
	 * Returns the value of the '<em><b>Working Cameras</b></em>' reference list.
	 * The list contents are of type {@link smartFarming2.Camera}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Working Cameras</em>' reference list.
	 * @see smartFarming2.SmartFarming2Package#getCrate_WorkingCameras()
	 * @model volatile="true" derived="true" ordered="false"
	 *        annotation="http://www.eclipse.org/OCL/Collection nullFree='false'"
	 * @generated
	 */
	EList<Camera> getWorkingCameras();

} // Crate
