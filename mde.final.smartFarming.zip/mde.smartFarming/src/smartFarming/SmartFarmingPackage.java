/**
 */
package smartFarming;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see smartFarming.SmartFarmingFactory
 * @model kind="package"
 * @generated
 */
public interface SmartFarmingPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "smartFarming";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/smartFarming";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "smartFarming";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SmartFarmingPackage eINSTANCE = smartFarming.impl.SmartFarmingPackageImpl.init();

	/**
	 * The meta object id for the '{@link smartFarming.impl.NameImpl <em>Name</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.NameImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getName_()
	 * @generated
	 */
	int NAME = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME__NAME = 0;

	/**
	 * The number of structural features of the '<em>Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.FarmImpl <em>Farm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.FarmImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getFarm()
	 * @generated
	 */
	int FARM = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Crate</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__CRATE = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Drone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__DRONE = NAME_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__CAMERA = NAME_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Ai</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM__AI = NAME_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Farm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM_FEATURE_COUNT = NAME_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Farm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARM_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.CrateidImpl <em>Crateid</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.CrateidImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrateid()
	 * @generated
	 */
	int CRATEID = 11;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID__ID = 0;

	/**
	 * The number of structural features of the '<em>Crateid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Crateid</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATEID_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.CrateImpl <em>Crate</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.CrateImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrate()
	 * @generated
	 */
	int CRATE = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__ID = CRATEID__ID;

	/**
	 * The feature id for the '<em><b>Light</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__LIGHT = CRATEID_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Humiditysensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__HUMIDITYSENSOR = CRATEID_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Temperaturesensor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__TEMPERATURESENSOR = CRATEID_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__CAMERA = CRATEID_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Soilsenor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__SOILSENOR = CRATEID_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Crop Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE__CROP_TYPE = CRATEID_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Crate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_FEATURE_COUNT = CRATEID_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Crate</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRATE_OPERATION_COUNT = CRATEID_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.DroneImpl <em>Drone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.DroneImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getDrone()
	 * @generated
	 */
	int DRONE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__TURN_ON = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Drone Focus</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE__DRONE_FOCUS = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Drone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE_FEATURE_COUNT = NAME_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Drone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRONE_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.CameraImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Camera Focus</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__CAMERA_FOCUS = NAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.AIImpl <em>AI</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.AIImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getAI()
	 * @generated
	 */
	int AI = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AI__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>AIfocus</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AI__AIFOCUS = NAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>AI</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AI_FEATURE_COUNT = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>AI</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AI_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.TemperatureSensosrImpl <em>Temperature Sensosr</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.TemperatureSensosrImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getTemperatureSensosr()
	 * @generated
	 */
	int TEMPERATURE_SENSOSR = 5;

	/**
	 * The feature id for the '<em><b>Temperaturein Degree Celcius</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS = 0;

	/**
	 * The feature id for the '<em><b>Crate Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOSR__CRATE_TEMPERATURE = 1;

	/**
	 * The feature id for the '<em><b>Plant Temperature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOSR__PLANT_TEMPERATURE = 2;

	/**
	 * The number of structural features of the '<em>Temperature Sensosr</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOSR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Temperature Sensosr</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEMPERATURE_SENSOSR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.SoilSensorImpl <em>Soil Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.SoilSensorImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getSoilSensor()
	 * @generated
	 */
	int SOIL_SENSOR = 6;

	/**
	 * The feature id for the '<em><b>Ph</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOIL_SENSOR__PH = 0;

	/**
	 * The feature id for the '<em><b>Soil Moisture</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOIL_SENSOR__SOIL_MOISTURE = 1;

	/**
	 * The number of structural features of the '<em>Soil Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOIL_SENSOR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Soil Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOIL_SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.HumiditySensorImpl <em>Humidity Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.HumiditySensorImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getHumiditySensor()
	 * @generated
	 */
	int HUMIDITY_SENSOR = 7;

	/**
	 * The feature id for the '<em><b>Humidity Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMIDITY_SENSOR__HUMIDITY_VALUE = 0;

	/**
	 * The feature id for the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMIDITY_SENSOR__TURN_ON = 1;

	/**
	 * The number of structural features of the '<em>Humidity Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMIDITY_SENSOR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Humidity Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HUMIDITY_SENSOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.LightImpl <em>Light</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.LightImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getLight()
	 * @generated
	 */
	int LIGHT = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__NAME = NAME__NAME;

	/**
	 * The feature id for the '<em><b>Type Light</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__TYPE_LIGHT = NAME_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Turn On</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT__TURN_ON = NAME_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_FEATURE_COUNT = NAME_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Light</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_OPERATION_COUNT = NAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smartFarming.impl.CropImpl <em>Crop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.impl.CropImpl
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrop()
	 * @generated
	 */
	int CROP = 10;

	/**
	 * The feature id for the '<em><b>Crop</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP__CROP = 0;

	/**
	 * The number of structural features of the '<em>Crop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Crop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smartFarming.typelight <em>typelight</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.typelight
	 * @see smartFarming.impl.SmartFarmingPackageImpl#gettypelight()
	 * @generated
	 */
	int TYPELIGHT = 12;

	/**
	 * The meta object id for the '{@link smartFarming.FocusArea <em>Focus Area</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.FocusArea
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getFocusArea()
	 * @generated
	 */
	int FOCUS_AREA = 13;

	/**
	 * The meta object id for the '{@link smartFarming.CropType <em>Crop Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smartFarming.CropType
	 * @see smartFarming.impl.SmartFarmingPackageImpl#getCropType()
	 * @generated
	 */
	int CROP_TYPE = 14;


	/**
	 * Returns the meta object for class '{@link smartFarming.Farm <em>Farm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Farm</em>'.
	 * @see smartFarming.Farm
	 * @generated
	 */
	EClass getFarm();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming.Farm#getCrate <em>Crate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Crate</em>'.
	 * @see smartFarming.Farm#getCrate()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Crate();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming.Farm#getDrone <em>Drone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Drone</em>'.
	 * @see smartFarming.Farm#getDrone()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Drone();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming.Farm#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Camera</em>'.
	 * @see smartFarming.Farm#getCamera()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Camera();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming.Farm#getAi <em>Ai</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Ai</em>'.
	 * @see smartFarming.Farm#getAi()
	 * @see #getFarm()
	 * @generated
	 */
	EReference getFarm_Ai();

	/**
	 * Returns the meta object for class '{@link smartFarming.Crate <em>Crate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crate</em>'.
	 * @see smartFarming.Crate
	 * @generated
	 */
	EClass getCrate();

	/**
	 * Returns the meta object for the containment reference list '{@link smartFarming.Crate#getLight <em>Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Light</em>'.
	 * @see smartFarming.Crate#getLight()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Light();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming.Crate#getHumiditysensor <em>Humiditysensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Humiditysensor</em>'.
	 * @see smartFarming.Crate#getHumiditysensor()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Humiditysensor();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming.Crate#getTemperaturesensor <em>Temperaturesensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Temperaturesensor</em>'.
	 * @see smartFarming.Crate#getTemperaturesensor()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Temperaturesensor();

	/**
	 * Returns the meta object for the reference '{@link smartFarming.Crate#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Camera</em>'.
	 * @see smartFarming.Crate#getCamera()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Camera();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming.Crate#getSoilsenor <em>Soilsenor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Soilsenor</em>'.
	 * @see smartFarming.Crate#getSoilsenor()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_Soilsenor();

	/**
	 * Returns the meta object for the containment reference '{@link smartFarming.Crate#getCropType <em>Crop Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Crop Type</em>'.
	 * @see smartFarming.Crate#getCropType()
	 * @see #getCrate()
	 * @generated
	 */
	EReference getCrate_CropType();

	/**
	 * Returns the meta object for class '{@link smartFarming.Drone <em>Drone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Drone</em>'.
	 * @see smartFarming.Drone
	 * @generated
	 */
	EClass getDrone();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Drone#isTurnOn <em>Turn On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn On</em>'.
	 * @see smartFarming.Drone#isTurnOn()
	 * @see #getDrone()
	 * @generated
	 */
	EAttribute getDrone_TurnOn();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Drone#getDroneFocus <em>Drone Focus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Drone Focus</em>'.
	 * @see smartFarming.Drone#getDroneFocus()
	 * @see #getDrone()
	 * @generated
	 */
	EAttribute getDrone_DroneFocus();

	/**
	 * Returns the meta object for class '{@link smartFarming.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see smartFarming.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Camera#getCameraFocus <em>Camera Focus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Camera Focus</em>'.
	 * @see smartFarming.Camera#getCameraFocus()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_CameraFocus();

	/**
	 * Returns the meta object for class '{@link smartFarming.AI <em>AI</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>AI</em>'.
	 * @see smartFarming.AI
	 * @generated
	 */
	EClass getAI();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.AI#getAIfocus <em>AIfocus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>AIfocus</em>'.
	 * @see smartFarming.AI#getAIfocus()
	 * @see #getAI()
	 * @generated
	 */
	EAttribute getAI_AIfocus();

	/**
	 * Returns the meta object for class '{@link smartFarming.TemperatureSensosr <em>Temperature Sensosr</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Temperature Sensosr</em>'.
	 * @see smartFarming.TemperatureSensosr
	 * @generated
	 */
	EClass getTemperatureSensosr();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.TemperatureSensosr#isTemperatureinDegreeCelcius <em>Temperaturein Degree Celcius</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Temperaturein Degree Celcius</em>'.
	 * @see smartFarming.TemperatureSensosr#isTemperatureinDegreeCelcius()
	 * @see #getTemperatureSensosr()
	 * @generated
	 */
	EAttribute getTemperatureSensosr_TemperatureinDegreeCelcius();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.TemperatureSensosr#getCrateTemperature <em>Crate Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Crate Temperature</em>'.
	 * @see smartFarming.TemperatureSensosr#getCrateTemperature()
	 * @see #getTemperatureSensosr()
	 * @generated
	 */
	EAttribute getTemperatureSensosr_CrateTemperature();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.TemperatureSensosr#getPlantTemperature <em>Plant Temperature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Plant Temperature</em>'.
	 * @see smartFarming.TemperatureSensosr#getPlantTemperature()
	 * @see #getTemperatureSensosr()
	 * @generated
	 */
	EAttribute getTemperatureSensosr_PlantTemperature();

	/**
	 * Returns the meta object for class '{@link smartFarming.SoilSensor <em>Soil Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Soil Sensor</em>'.
	 * @see smartFarming.SoilSensor
	 * @generated
	 */
	EClass getSoilSensor();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.SoilSensor#getPh <em>Ph</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ph</em>'.
	 * @see smartFarming.SoilSensor#getPh()
	 * @see #getSoilSensor()
	 * @generated
	 */
	EAttribute getSoilSensor_Ph();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.SoilSensor#getSoilMoisture <em>Soil Moisture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Soil Moisture</em>'.
	 * @see smartFarming.SoilSensor#getSoilMoisture()
	 * @see #getSoilSensor()
	 * @generated
	 */
	EAttribute getSoilSensor_SoilMoisture();

	/**
	 * Returns the meta object for class '{@link smartFarming.HumiditySensor <em>Humidity Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Humidity Sensor</em>'.
	 * @see smartFarming.HumiditySensor
	 * @generated
	 */
	EClass getHumiditySensor();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.HumiditySensor#getHumidityValue <em>Humidity Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Humidity Value</em>'.
	 * @see smartFarming.HumiditySensor#getHumidityValue()
	 * @see #getHumiditySensor()
	 * @generated
	 */
	EAttribute getHumiditySensor_HumidityValue();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.HumiditySensor#isTurnOn <em>Turn On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn On</em>'.
	 * @see smartFarming.HumiditySensor#isTurnOn()
	 * @see #getHumiditySensor()
	 * @generated
	 */
	EAttribute getHumiditySensor_TurnOn();

	/**
	 * Returns the meta object for class '{@link smartFarming.Light <em>Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Light</em>'.
	 * @see smartFarming.Light
	 * @generated
	 */
	EClass getLight();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Light#getTypeLight <em>Type Light</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Light</em>'.
	 * @see smartFarming.Light#getTypeLight()
	 * @see #getLight()
	 * @generated
	 */
	EAttribute getLight_TypeLight();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Light#isTurnOn <em>Turn On</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn On</em>'.
	 * @see smartFarming.Light#isTurnOn()
	 * @see #getLight()
	 * @generated
	 */
	EAttribute getLight_TurnOn();

	/**
	 * Returns the meta object for class '{@link smartFarming.Name <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Name</em>'.
	 * @see smartFarming.Name
	 * @generated
	 */
	EClass getName_();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Name#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see smartFarming.Name#getName()
	 * @see #getName_()
	 * @generated
	 */
	EAttribute getName_Name();

	/**
	 * Returns the meta object for class '{@link smartFarming.Crop <em>Crop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crop</em>'.
	 * @see smartFarming.Crop
	 * @generated
	 */
	EClass getCrop();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Crop#getCrop <em>Crop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Crop</em>'.
	 * @see smartFarming.Crop#getCrop()
	 * @see #getCrop()
	 * @generated
	 */
	EAttribute getCrop_Crop();

	/**
	 * Returns the meta object for class '{@link smartFarming.Crateid <em>Crateid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Crateid</em>'.
	 * @see smartFarming.Crateid
	 * @generated
	 */
	EClass getCrateid();

	/**
	 * Returns the meta object for the attribute '{@link smartFarming.Crateid#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see smartFarming.Crateid#getId()
	 * @see #getCrateid()
	 * @generated
	 */
	EAttribute getCrateid_Id();

	/**
	 * Returns the meta object for enum '{@link smartFarming.typelight <em>typelight</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>typelight</em>'.
	 * @see smartFarming.typelight
	 * @generated
	 */
	EEnum gettypelight();

	/**
	 * Returns the meta object for enum '{@link smartFarming.FocusArea <em>Focus Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Focus Area</em>'.
	 * @see smartFarming.FocusArea
	 * @generated
	 */
	EEnum getFocusArea();

	/**
	 * Returns the meta object for enum '{@link smartFarming.CropType <em>Crop Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Crop Type</em>'.
	 * @see smartFarming.CropType
	 * @generated
	 */
	EEnum getCropType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SmartFarmingFactory getSmartFarmingFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link smartFarming.impl.FarmImpl <em>Farm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.FarmImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getFarm()
		 * @generated
		 */
		EClass FARM = eINSTANCE.getFarm();

		/**
		 * The meta object literal for the '<em><b>Crate</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__CRATE = eINSTANCE.getFarm_Crate();

		/**
		 * The meta object literal for the '<em><b>Drone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__DRONE = eINSTANCE.getFarm_Drone();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__CAMERA = eINSTANCE.getFarm_Camera();

		/**
		 * The meta object literal for the '<em><b>Ai</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARM__AI = eINSTANCE.getFarm_Ai();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.CrateImpl <em>Crate</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.CrateImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrate()
		 * @generated
		 */
		EClass CRATE = eINSTANCE.getCrate();

		/**
		 * The meta object literal for the '<em><b>Light</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__LIGHT = eINSTANCE.getCrate_Light();

		/**
		 * The meta object literal for the '<em><b>Humiditysensor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__HUMIDITYSENSOR = eINSTANCE.getCrate_Humiditysensor();

		/**
		 * The meta object literal for the '<em><b>Temperaturesensor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__TEMPERATURESENSOR = eINSTANCE.getCrate_Temperaturesensor();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__CAMERA = eINSTANCE.getCrate_Camera();

		/**
		 * The meta object literal for the '<em><b>Soilsenor</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__SOILSENOR = eINSTANCE.getCrate_Soilsenor();

		/**
		 * The meta object literal for the '<em><b>Crop Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CRATE__CROP_TYPE = eINSTANCE.getCrate_CropType();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.DroneImpl <em>Drone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.DroneImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getDrone()
		 * @generated
		 */
		EClass DRONE = eINSTANCE.getDrone();

		/**
		 * The meta object literal for the '<em><b>Turn On</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRONE__TURN_ON = eINSTANCE.getDrone_TurnOn();

		/**
		 * The meta object literal for the '<em><b>Drone Focus</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRONE__DRONE_FOCUS = eINSTANCE.getDrone_DroneFocus();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.CameraImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Camera Focus</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__CAMERA_FOCUS = eINSTANCE.getCamera_CameraFocus();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.AIImpl <em>AI</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.AIImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getAI()
		 * @generated
		 */
		EClass AI = eINSTANCE.getAI();

		/**
		 * The meta object literal for the '<em><b>AIfocus</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AI__AIFOCUS = eINSTANCE.getAI_AIfocus();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.TemperatureSensosrImpl <em>Temperature Sensosr</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.TemperatureSensosrImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getTemperatureSensosr()
		 * @generated
		 */
		EClass TEMPERATURE_SENSOSR = eINSTANCE.getTemperatureSensosr();

		/**
		 * The meta object literal for the '<em><b>Temperaturein Degree Celcius</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPERATURE_SENSOSR__TEMPERATUREIN_DEGREE_CELCIUS = eINSTANCE.getTemperatureSensosr_TemperatureinDegreeCelcius();

		/**
		 * The meta object literal for the '<em><b>Crate Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPERATURE_SENSOSR__CRATE_TEMPERATURE = eINSTANCE.getTemperatureSensosr_CrateTemperature();

		/**
		 * The meta object literal for the '<em><b>Plant Temperature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEMPERATURE_SENSOSR__PLANT_TEMPERATURE = eINSTANCE.getTemperatureSensosr_PlantTemperature();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.SoilSensorImpl <em>Soil Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.SoilSensorImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getSoilSensor()
		 * @generated
		 */
		EClass SOIL_SENSOR = eINSTANCE.getSoilSensor();

		/**
		 * The meta object literal for the '<em><b>Ph</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOIL_SENSOR__PH = eINSTANCE.getSoilSensor_Ph();

		/**
		 * The meta object literal for the '<em><b>Soil Moisture</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOIL_SENSOR__SOIL_MOISTURE = eINSTANCE.getSoilSensor_SoilMoisture();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.HumiditySensorImpl <em>Humidity Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.HumiditySensorImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getHumiditySensor()
		 * @generated
		 */
		EClass HUMIDITY_SENSOR = eINSTANCE.getHumiditySensor();

		/**
		 * The meta object literal for the '<em><b>Humidity Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HUMIDITY_SENSOR__HUMIDITY_VALUE = eINSTANCE.getHumiditySensor_HumidityValue();

		/**
		 * The meta object literal for the '<em><b>Turn On</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HUMIDITY_SENSOR__TURN_ON = eINSTANCE.getHumiditySensor_TurnOn();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.LightImpl <em>Light</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.LightImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getLight()
		 * @generated
		 */
		EClass LIGHT = eINSTANCE.getLight();

		/**
		 * The meta object literal for the '<em><b>Type Light</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT__TYPE_LIGHT = eINSTANCE.getLight_TypeLight();

		/**
		 * The meta object literal for the '<em><b>Turn On</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT__TURN_ON = eINSTANCE.getLight_TurnOn();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.NameImpl <em>Name</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.NameImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getName_()
		 * @generated
		 */
		EClass NAME = eINSTANCE.getName_();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAME__NAME = eINSTANCE.getName_Name();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.CropImpl <em>Crop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.CropImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrop()
		 * @generated
		 */
		EClass CROP = eINSTANCE.getCrop();

		/**
		 * The meta object literal for the '<em><b>Crop</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CROP__CROP = eINSTANCE.getCrop_Crop();

		/**
		 * The meta object literal for the '{@link smartFarming.impl.CrateidImpl <em>Crateid</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.impl.CrateidImpl
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getCrateid()
		 * @generated
		 */
		EClass CRATEID = eINSTANCE.getCrateid();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CRATEID__ID = eINSTANCE.getCrateid_Id();

		/**
		 * The meta object literal for the '{@link smartFarming.typelight <em>typelight</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.typelight
		 * @see smartFarming.impl.SmartFarmingPackageImpl#gettypelight()
		 * @generated
		 */
		EEnum TYPELIGHT = eINSTANCE.gettypelight();

		/**
		 * The meta object literal for the '{@link smartFarming.FocusArea <em>Focus Area</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.FocusArea
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getFocusArea()
		 * @generated
		 */
		EEnum FOCUS_AREA = eINSTANCE.getFocusArea();

		/**
		 * The meta object literal for the '{@link smartFarming.CropType <em>Crop Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smartFarming.CropType
		 * @see smartFarming.impl.SmartFarmingPackageImpl#getCropType()
		 * @generated
		 */
		EEnum CROP_TYPE = eINSTANCE.getCropType();

	}

} //SmartFarmingPackage
