/**
 */
package smartFarming.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smartFarming.AI;
import smartFarming.FocusArea;
import smartFarming.SmartFarmingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AI</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smartFarming.impl.AIImpl#getAIMonitoring <em>AI Monitoring</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AIImpl extends NameImpl implements AI {
	/**
	 * The default value of the '{@link #getAIMonitoring() <em>AI Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAIMonitoring()
	 * @generated
	 * @ordered
	 */
	protected static final FocusArea AI_MONITORING_EDEFAULT = FocusArea.CRATES;

	/**
	 * The cached value of the '{@link #getAIMonitoring() <em>AI Monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAIMonitoring()
	 * @generated
	 * @ordered
	 */
	protected FocusArea aiMonitoring = AI_MONITORING_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AIImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmartFarmingPackage.Literals.AI;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FocusArea getAIMonitoring() {
		return aiMonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAIMonitoring(FocusArea newAIMonitoring) {
		FocusArea oldAIMonitoring = aiMonitoring;
		aiMonitoring = newAIMonitoring == null ? AI_MONITORING_EDEFAULT : newAIMonitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmartFarmingPackage.AI__AI_MONITORING, oldAIMonitoring, aiMonitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AI_MONITORING:
				return getAIMonitoring();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AI_MONITORING:
				setAIMonitoring((FocusArea)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AI_MONITORING:
				setAIMonitoring(AI_MONITORING_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmartFarmingPackage.AI__AI_MONITORING:
				return aiMonitoring != AI_MONITORING_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (AIMonitoring: ");
		result.append(aiMonitoring);
		result.append(')');
		return result.toString();
	}

} //AIImpl
